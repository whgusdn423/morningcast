# 모닝캐스트 (MorningCast)

전날 저녁에 AI가 **경제 · 교육(수학교육 연구) · 국제정세** 팟캐스트(약 30분)를 만들어 두고,
다음 날 아침 설정한 시간에 알람처럼 자동으로 틀어 주는 개인용 안드로이드 앱입니다.

## 동작 방식
1. **전날 저녁(기본 21:00)** — 앱이 뉴스 RSS(구글 뉴스·세계일보 등)와 수학교육 학술지 최신 논문(Crossref)을 모읍니다.
2. AI(Gemini 또는 Claude)가 모은 자료로 코너별 방송 대본을 씁니다. (2인 대화 / 1인 진행)
3. 휴대폰 음성(무료) 또는 Gemini 고품질 음성으로 오디오 파일(m4a)을 만듭니다.
4. **아침(기본 06:30, 월~금)** — 알람 볼륨으로 재생하고, 잠금화면에 재생 화면을 띄웁니다.

## APK 만들기 (PC에 아무것도 설치하지 않는 방법)
1. GitHub에 새 저장소를 만들고 이 폴더의 **모든 파일(숨김 폴더 `.github` 포함)** 을 올립니다.
2. 저장소의 **Actions** 탭에서 빌드가 끝나기를 기다립니다(약 5~10분).
3. **Releases** 에서 `MorningCast.apk` 를 휴대폰으로 내려받아 설치합니다.

`.github` 폴더가 안 올라갔다면: GitHub에서 **Add file → Create new file** 을 누르고
파일 이름에 `.github/workflows/build.yml` 을 입력한 뒤, `BUILD_WORKFLOW_COPY.yml` 내용을 붙여 넣어 저장하세요.

자세한 순서·첫 설정·문제 해결은 함께 드린 **사용 설명서**를 참고하세요.

## 구성
- 외부 라이브러리 없이 안드로이드 기본 기능 + Kotlin 만 사용 (minSdk 26 / targetSdk 35)
- `app/src/main/java/com/morningcast/app/`
  - `Materials.kt` 뉴스·논문 수집 · `ScriptWriter.kt` 프롬프트·대본 정리 · `Llm.kt` Gemini/Claude 연결
  - `Tts.kt` 음성 합성 · `AudioUtil.kt` 오디오 처리 · `PodcastGenerator.kt` 전체 생성 과정
  - `Scheduler.kt` 알람 예약 · `PlaybackService.kt` 재생 · `MainActivity.kt` 설정 화면
- API 키는 휴대폰 안(앱 전용 저장소)에만 저장되며 코드·저장소에는 들어가지 않습니다.
- `app/morningcast.jks` 는 업데이트 설치를 위한 개인용 서명 키입니다(비밀번호: morningcast).
