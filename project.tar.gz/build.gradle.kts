// 최상위 빌드 파일: 플러그인 버전만 선언합니다.
plugins {
    id("com.android.application") version "8.10.1" apply false
    id("org.jetbrains.kotlin.android") version "2.2.10" apply false
}
