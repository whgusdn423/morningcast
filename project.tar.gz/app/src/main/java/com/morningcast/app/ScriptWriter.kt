package com.morningcast.app

import android.content.Context

class SegmentScript(
    val segment: Segment,
    val text: String,
    val covered: List<String>,
    val sources: List<Source>,
    val note: String
)

/** 한 번 말하는 단위(TTS 단위). chime=true 면 코너 사이 효과음 */
class Utterance(
    val speaker: Int,
    val text: String,
    val segment: Int,
    val chime: Boolean = false,
    val pauseAfterMs: Int = 350
)

/** AI 에게 코너별 대본을 받아 정리합니다. */
class ScriptWriter(private val ctx: Context, private val s: Settings, private val client: LlmClient) {
    /** 웹 검색이 실제로 되는지(무료 등급이면 첫 시도 후 자동으로 꺼짐) */
    var searchAllowed = s.useWebSearch
        private set

    fun write(seg: Segment, pack: MaterialPack, dateLabel: String, recent: List<String>, index: Int, total: Int): SegmentScript {
        if (pack.isEmpty && !searchAllowed) {
            throw LlmException("${seg.title}: 수집된 뉴스·논문이 없습니다 (RSS 주소/검색어를 확인하세요)")
        }
        val target = seg.minutes * CHARS_PER_MIN
        val system = systemPrompt()
        val user = userPrompt(seg, pack, dateLabel, recent, index, total, target)
        var res = client.generate(system, user, searchAllowed)
        if (searchAllowed && !res.usedSearch) searchAllowed = false
        var parsed = parse(res.text)
        AppLog.log(ctx, "${seg.title} 대본 ${parsed.body.length}자 (목표 $target 자)${if (res.note.isNotEmpty()) " · " + res.note else ""}")
        if (parsed.body.length < target * 0.7) {
            try {
                val res2 = client.generate(system, expandPrompt(user, parsed.body, target), searchAllowed)
                val p2 = parse(res2.text)
                AppLog.log(ctx, "${seg.title} 보강 대본 ${p2.body.length}자")
                if (p2.body.length > parsed.body.length) {
                    parsed = p2
                    res = LlmResult(res2.text, res.sources + res2.sources, res2.usedSearch, res2.note)
                }
            } catch (e: AuthException) {
                throw e
            } catch (e: QuotaException) {
                AppLog.log(ctx, "보강 요청 생략(한도): ${e.message}")
            } catch (e: Exception) {
                AppLog.log(ctx, "보강 요청 실패(원래 대본 사용): ${e.message}")
            }
        }
        val clean = Speech.sanitize(parsed.body)
        if (clean.length < 150) throw LlmException("${seg.title}: AI가 만든 대본이 너무 짧습니다")
        return SegmentScript(seg, clean, parsed.covered, pack.sources + res.sources, res.note)
    }

    private fun systemPrompt(): String {
        val searchPart = if (searchAllowed) "와 웹 검색 결과" else ""
        return """
당신은 매일 아침 방송되는 한국어 오디오 브리핑 「모닝캐스트」의 전문 방송 작가입니다.
청취자: ${s.listener.ifBlank { "일반 직장인" }}. 출근 준비를 하며 귀로만 듣습니다.

반드시 지킬 원칙
1. 사실만 씁니다. 주어진 [자료]${searchPart}에 있는 내용만 근거로 삼고, 자료에 없는 수치·인용·연구 결과·날짜를 지어내지 않습니다. 자료가 헤드라인뿐이면 헤드라인 수준에서만 전하고, 확실하지 않은 내용은 단정하지 않습니다.
2. 귀로 듣는 글입니다. 문장은 짧게, 쉬운 단어로, 자연스러운 '합니다'체 구어로 씁니다.
3. 표, 목록 기호, 마크다운(#, *, - 등), 이모지, URL, 괄호 속 출처 표기를 쓰지 않습니다. 출처는 "○○일보 보도에 따르면"처럼 말로 밝힙니다.
4. 큰 숫자는 "1조 2천억 원"처럼 단위를 붙여 읽기 쉽게 씁니다. 퍼센트는 "3.5퍼센트"처럼 씁니다.
5. 영어 약어와 외국어는 한국어로 풀어 씁니다. 예: Fed → 미국 연방준비제도, GDP → 국내총생산.
6. 출력 형식: 대본 본문은 [대본시작] 줄과 [대본끝] 줄 사이에만 씁니다. 그 밖에는 인사말이나 설명을 붙이지 않습니다.
7. [대본끝] 다음 줄에 [다룬항목] 으로 시작하는 한 줄을 쓰고, 이번 대본에서 다룬 소식의 짧은 제목(논문은 DOI)을 " | "로 구분해 나열합니다.
""".trim()
    }

    private fun userPrompt(
        seg: Segment,
        pack: MaterialPack,
        dateLabel: String,
        recent: List<String>,
        index: Int,
        total: Int,
        target: Int
    ): String {
        val minC = (target * 0.95).toInt()
        val maxC = (target * 1.15).toInt()
        val styleDesc = if (s.style == "duo") {
            "두 진행자 '${s.host1}'(진행)와 '${s.host2}'(해설)의 자연스러운 대화로 씁니다. " +
                "모든 줄은 반드시 '${s.host1}: ' 또는 '${s.host2}: '로 시작합니다. " +
                "한 사람이 2~4문장씩 말하고 주고받으며, 서로 묻고 쉽게 풀어 설명합니다. 이름 외의 표시는 쓰지 않습니다."
        } else {
            "진행자 한 명이 혼자 이야기하듯 씁니다. 문단 사이는 빈 줄로 구분합니다."
        }
        val sb = StringBuilder()
        sb.append("이 대본은 ").append(dateLabel).append(" 아침에 방송됩니다. [자료]는 방송 전날까지 모은 소식입니다. ")
        sb.append("'어제', '오늘' 같은 말은 방송일을 기준으로 씁니다.\n\n")
        sb.append("코너: ").append(seg.title).append(" (전체 ").append(total).append("개 코너 중 ").append(index + 1).append("번째)\n")
        sb.append("분량: 약 ").append(seg.minutes).append("분. 공백 포함 ").append(minC).append("~").append(maxC)
            .append("자 분량을 꼭 채워 주세요.\n")
        sb.append("진행 방식: ").append(styleDesc).append('\n')
        sb.append("구성: 첫 문장은 \"").append(seg.title).append(" 소식입니다\"처럼 코너를 여는 말로 시작하고, ")
        sb.append("마지막은 핵심을 한두 문장으로 정리합니다. 방송 전체의 첫인사와 끝인사는 따로 있으니 쓰지 않습니다.\n")
        sb.append("코너 지침: ").append(seg.instruction.ifBlank { "중요한 최신 소식을 쉽게 전해 주세요." }).append('\n')
        if (recent.isNotEmpty()) {
            sb.append("최근 며칠 동안 이미 다룬 항목입니다. 새로운 진전이 없으면 다시 다루지 마세요: ")
            sb.append(recent.takeLast(25).joinToString(" | ")).append('\n')
        }
        if (searchAllowed) {
            sb.append("웹 검색을 쓸 수 있습니다. [자료]의 중요한 소식은 검색으로 세부 사실을 확인하고, ")
            sb.append("자료가 부족하면 최근 소식을 검색해 보충하세요. 검색으로 확인한 내용도 출처를 말로 밝혀 주세요.\n")
        }
        sb.append("\n[자료]\n").append(pack.text).append("\n[자료 끝]\n")
        return sb.toString()
    }

    private fun expandPrompt(original: String, current: String, target: Int): String {
        val minC = (target * 0.95).toInt()
        return original + "\n\n" +
            "아래 [기존 대본]은 목표 분량보다 짧습니다(현재 약 ${current.length}자, 목표 약 ${target}자). " +
            "같은 진행 방식과 형식으로 [자료]에서 아직 다루지 않은 소식을 추가하고 해설을 보강해서, " +
            "전체 대본을 처음부터 다시 써 주세요. 공백 포함 ${minC}자 이상이어야 합니다. " +
            "출력 형식([대본시작]~[대본끝], 다음 줄 [다룬항목])은 그대로 지켜 주세요.\n\n" +
            "[기존 대본]\n" + current + "\n[기존 대본 끝]\n"
    }

    class Parsed(val body: String, val covered: List<String>)

    companion object {
        /** 1분에 읽는 글자 수(공백 포함) 추정치 */
        const val CHARS_PER_MIN = 420

        fun parse(raw0: String): Parsed {
            val raw = raw0.replace("[대본 시작]", "[대본시작]").replace("[대본 끝]", "[대본끝]")
                .replace("[다룬 항목]", "[다룬항목]").replace("**[", "[").replace("]**", "]")
            val startTag = "[대본시작]"
            val endTag = "[대본끝]"
            val start = raw.indexOf(startTag)
            val end = raw.indexOf(endTag, if (start >= 0) start else 0)
            var body = when {
                start >= 0 && end > start -> raw.substring(start + startTag.length, end)
                start >= 0 -> raw.substring(start + startTag.length)
                end > 0 -> raw.substring(0, end)
                else -> raw
            }
            body = body.substringBefore("[다룬항목]")
            val covIdx = raw.indexOf("[다룬항목]")
            val covered = if (covIdx >= 0) {
                raw.substring(covIdx + "[다룬항목]".length)
                    .lineSequence().firstOrNull { it.isNotBlank() }
                    ?.split('|')
                    ?.map { it.trim().trimStart(':', ' ').trim() }
                    ?.filter { it.isNotEmpty() && it.length < 200 }
                    ?: emptyList()
            } else {
                emptyList()
            }
            return Parsed(body.trim(), covered)
        }
    }
}

/** 대본 텍스트 정리(TTS가 읽기 좋게) */
object Speech {
    private val URL_RE = Regex("https?://\\S+")
    private val CITE_RE = Regex("\\[(\\d+([,\\s]+\\d+)*)]|【[^】]*】")
    private val EMOJI_RE = Regex("[\\x{1F000}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{FE0F}\\x{200D}]")
    private val BULLET_RE = Regex("(?m)^[ \\t]*([-*•▶▷■□◆◇●○※]|#{1,6})[ \\t]*")
    private val RANGE_RE = Regex("(\\d)\\s*~\\s*(\\d)")

    fun sanitize(text: String): String {
        var t = text.replace("\r\n", "\n")
        t = t.replace("**", "").replace("__", "").replace("`", "")
        t = URL_RE.replace(t, "")
        t = CITE_RE.replace(t, "")
        t = EMOJI_RE.replace(t, "")
        t = BULLET_RE.replace(t, "")
        t = t.replace(Regex("[ \\t]+"), " ")
        t = t.replace(Regex(" +([.,!?])"), "$1")
        t = t.replace(Regex("(?m)[ \\t]+$"), "")
        t = t.replace(Regex("\\n{3,}"), "\n\n")
        return t.trim()
    }

    /** TTS 직전 정리: 읽기 어색한 기호 처리 */
    fun forTts(text: String): String {
        var t = RANGE_RE.replace(text, "$1에서 $2")
        t = t.replace("·", ", ").replace("ㆍ", ", ").replace("…", "… ")
        t = t.replace("\"", "").replace("“", "").replace("”", "").replace("‘", "").replace("’", "")
        t = t.replace(Regex("[ \\t]+"), " ")
        return t.trim()
    }

    /** 긴 문장을 TTS 한 번에 넣기 좋은 길이로 자릅니다. */
    fun split(text: String, maxLen: Int): List<String> {
        val t = text.trim()
        if (t.length <= maxLen) return if (t.isEmpty()) emptyList() else listOf(t)
        val sentences = t.split(Regex("(?<=[.!?。])\\s+"))
        val out = ArrayList<String>()
        val cur = StringBuilder()
        for (sen in sentences) {
            if (cur.isNotEmpty() && cur.length + sen.length + 1 > maxLen) {
                out.add(cur.toString().trim())
                cur.setLength(0)
            }
            if (sen.length > maxLen) {
                var rest = sen
                while (rest.length > maxLen) {
                    var cut = rest.lastIndexOf(' ', maxLen)
                    if (cut < maxLen / 2) cut = maxLen
                    out.add(rest.substring(0, cut).trim())
                    rest = rest.substring(cut)
                }
                cur.append(rest.trim()).append(' ')
            } else {
                cur.append(sen).append(' ')
            }
        }
        if (cur.isNotBlank()) out.add(cur.toString().trim())
        return out.filter { it.isNotEmpty() }
    }
}

/** 코너 대본들을 오프닝/효과음/클로징과 합쳐 말하기 단위 목록으로 만듭니다. */
object Assembler {
    fun build(s: Settings, dateLabel: String, scripts: List<SegmentScript>, failed: List<String>): List<Utterance> {
        val duo = s.style == "duo"
        val out = ArrayList<Utterance>()
        val titles = scripts.joinToString(", ") { it.segment.title }
        if (duo) {
            out.add(Utterance(0, "좋은 아침입니다! $dateLabel 모닝캐스트, 저는 ${s.host1}입니다.", -1))
            out.add(Utterance(1, "저는 ${s.host2}입니다. 오늘은 $titles 순서로 준비했습니다.", -1, pauseAfterMs = 500))
        } else {
            out.add(Utterance(0, "좋은 아침입니다. $dateLabel 모닝캐스트입니다. 오늘은 $titles 소식을 차례로 전해 드립니다.", -1, pauseAfterMs = 500))
        }
        for ((i, sc) in scripts.withIndex()) {
            out.add(Utterance(0, "", i, chime = true, pauseAfterMs = 0))
            out.addAll(toUtterances(s, sc.text, i))
        }
        out.add(Utterance(0, "", -1, chime = true, pauseAfterMs = 0))
        if (failed.isNotEmpty()) {
            out.add(Utterance(0, "오늘은 ${failed.joinToString(", ")} 코너를 준비하지 못했습니다. 양해 부탁드립니다.", -1))
        }
        if (duo) {
            out.add(Utterance(0, "오늘 모닝캐스트는 여기까지입니다.", -1))
            out.add(Utterance(1, "오늘도 좋은 하루 보내세요!", -1, pauseAfterMs = 800))
        } else {
            out.add(Utterance(0, "오늘 모닝캐스트는 여기까지입니다. 오늘도 좋은 하루 보내세요.", -1, pauseAfterMs = 800))
        }
        return out
    }

    fun toUtterances(s: Settings, text: String, seg: Int): List<Utterance> {
        val out = ArrayList<Utterance>()
        if (s.style == "duo") {
            val names = listOf(s.host1.trim(), s.host2.trim())
            val re = Regex("^\\s*(" + Regex.escape(names[0]) + "|" + Regex.escape(names[1]) + ")\\s*[:：]\\s*(.*)$")
            var speaker = 0
            val buf = StringBuilder()
            fun flush() {
                val t = buf.toString().trim()
                if (t.isNotEmpty()) for (p in Speech.split(t, 1200)) out.add(Utterance(speaker, p, seg, pauseAfterMs = 300))
                buf.setLength(0)
            }
            for (line in text.lines()) {
                if (line.isBlank()) continue
                val m = re.find(line)
                if (m != null) {
                    flush()
                    speaker = if (m.groupValues[1] == names[1]) 1 else 0
                    buf.append(m.groupValues[2])
                } else {
                    buf.append(' ').append(line.trim())
                }
            }
            flush()
        } else {
            for (para in text.split(Regex("\\n\\s*\\n"))) {
                val p = para.replace('\n', ' ').trim()
                if (p.isEmpty()) continue
                for (piece in Speech.split(p, 1200)) out.add(Utterance(0, piece, seg, pauseAfterMs = 450))
            }
        }
        return out
    }

    /** 저장용 전체 대본 텍스트 */
    fun scriptText(
        s: Settings,
        title: String,
        info: String,
        utts: List<Utterance>,
        scripts: List<SegmentScript>
    ): String {
        val sb = StringBuilder()
        sb.append(title).append('\n').append(info).append("\n\n")
        var lastSeg = -2
        for (u in utts) {
            if (u.chime) {
                sb.append('\n')
                if (u.segment >= 0 && u.segment < scripts.size) {
                    sb.append("━━━━ ").append(scripts[u.segment].segment.title).append(" ━━━━\n")
                } else {
                    sb.append("━━━━ 클로징 ━━━━\n")
                }
                lastSeg = u.segment
                continue
            }
            if (lastSeg == -2) {
                sb.append("━━━━ 오프닝 ━━━━\n")
                lastSeg = -1
            }
            if (s.style == "duo") sb.append(if (u.speaker == 1) s.host2 else s.host1).append(": ")
            sb.append(u.text).append('\n')
        }
        sb.append("\n━━━━ 출처 ━━━━\n")
        for (sc in scripts) {
            val uniq = sc.sources.distinctBy { it.url }
            if (uniq.isEmpty()) continue
            sb.append("[").append(sc.segment.title).append("]\n")
            for (src in uniq.take(40)) sb.append("- ").append(src.title).append("\n  ").append(src.url).append('\n')
        }
        return sb.toString()
    }
}
