package com.morningcast.app

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

class HttpResponse(val code: Int, val body: ByteArray, private val headers: Map<String, String>) {
    val text: String get() = String(body, Charsets.UTF_8)
    fun header(name: String): String? = headers[name.lowercase()]
}

/** 외부 라이브러리 없이 HttpURLConnection 으로 통신합니다. */
object Http {
    const val UA = "Mozilla/5.0 (Linux; Android) MorningCast/1.0"

    fun get(
        url: String,
        headers: Map<String, String> = emptyMap(),
        readTimeoutMs: Int = 25_000,
        maxBytes: Int = 6 * 1024 * 1024
    ): HttpResponse = request("GET", url, headers, null, 15_000, readTimeoutMs, maxBytes)

    fun postJson(
        url: String,
        headers: Map<String, String>,
        json: String,
        readTimeoutMs: Int,
        maxBytes: Int = 128 * 1024 * 1024
    ): HttpResponse {
        val h = HashMap(headers)
        h["Content-Type"] = "application/json; charset=utf-8"
        return request("POST", url, h, json.toByteArray(Charsets.UTF_8), 20_000, readTimeoutMs, maxBytes)
    }

    fun request(
        method: String,
        url: String,
        headers: Map<String, String>,
        body: ByteArray?,
        connectTimeoutMs: Int,
        readTimeoutMs: Int,
        maxBytes: Int
    ): HttpResponse {
        var current = safeUrl(url)
        for (hop in 0 until 6) {
            val conn = URL(current).openConnection() as HttpURLConnection
            try {
                conn.requestMethod = method
                conn.connectTimeout = connectTimeoutMs
                conn.readTimeout = readTimeoutMs
                conn.instanceFollowRedirects = false
                conn.setRequestProperty("User-Agent", UA)
                for ((k, v) in headers) conn.setRequestProperty(k, v)
                if (body != null) {
                    conn.doOutput = true
                    conn.setFixedLengthStreamingMode(body.size)
                    conn.outputStream.use { it.write(body) }
                }
                val code = conn.responseCode
                if (code in 300..399 && body == null) {
                    val loc = conn.getHeaderField("Location")
                    if (loc != null) {
                        current = URL(URL(current), loc).toString()
                        continue
                    }
                }
                val stream: InputStream? = if (code >= 400) conn.errorStream else conn.inputStream
                val bytes = stream?.use { readAll(it, maxBytes) } ?: ByteArray(0)
                val hdrs = HashMap<String, String>()
                val fields = conn.headerFields
                if (fields != null) {
                    for ((k, v) in fields) {
                        if (k != null && v != null && v.isNotEmpty()) hdrs[k.lowercase()] = v[0]
                    }
                }
                return HttpResponse(code, bytes, hdrs)
            } finally {
                conn.disconnect()
            }
        }
        throw IOException("리다이렉트가 너무 많습니다: $url")
    }

    /** 한글·공백이 섞인 주소를 안전한 형태(퍼센트 인코딩)로 바꿉니다. */
    fun safeUrl(url: String): String {
        val s = url.trim()
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            if (cp > 0x7E || cp == ' '.code) {
                val bytes = String(Character.toChars(cp)).toByteArray(Charsets.UTF_8)
                for (b in bytes) sb.append('%').append(String.format("%02X", b.toInt() and 0xFF))
            } else {
                sb.appendCodePoint(cp)
            }
            i += Character.charCount(cp)
        }
        return sb.toString()
    }

    private fun readAll(input: InputStream, maxBytes: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(64 * 1024)
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            if (out.size() > maxBytes) throw IOException("응답이 너무 큽니다")
        }
        return out.toByteArray()
    }
}
