package com.morningcast.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 지난 에피소드 목록 */
class EpisodesActivity : Activity() {
    private var episodes: List<Episode> = emptyList()
    private lateinit var list: ListView
    private lateinit var tvEmpty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_episodes)
        Ui.applyInsets(findViewById(R.id.root))
        list = findViewById(R.id.list)
        tvEmpty = findViewById(R.id.tvEmpty)
        list.setOnItemClickListener { _, _, position, _ ->
            episodes.getOrNull(position)?.let { showOptions(it) }
        }
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun reload() {
        episodes = EpisodeStore.list(this)
        tvEmpty.visibility = if (episodes.isEmpty()) View.VISIBLE else View.GONE
        list.adapter = object : BaseAdapter() {
            override fun getCount(): Int = episodes.size
            override fun getItem(position: Int): Any = episodes[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val v = convertView ?: layoutInflater.inflate(R.layout.item_episode, parent, false)
                val ep = episodes[position]
                val mins = (ep.durationMs + 30_000) / 60_000
                val created = SimpleDateFormat("M/d HH:mm", Locale.KOREA).format(Date(ep.createdAt))
                val fail = if (ep.failed.isEmpty()) "" else " · 빠진 코너: ${ep.failed.joinToString(", ")}"
                v.findViewById<TextView>(R.id.tvItemTitle).text = ep.title
                v.findViewById<TextView>(R.id.tvItemSub).text =
                    "약 ${mins}분 · ${ep.segmentTitles.joinToString("·")} · $created 만듦$fail"
                return v
            }
        }
    }

    private fun showOptions(ep: Episode) {
        AlertDialog.Builder(this)
            .setTitle(ep.title)
            .setItems(arrayOf("재생", "대본·출처 보기", "삭제")) { _, which ->
                when (which) {
                    0 -> {
                        PlaybackService.playEpisode(this, ep.id)
                        startActivity(Intent(this, PlayerActivity::class.java))
                    }
                    1 -> TextViewerActivity.open(this, ep.title, ep.scriptFile.absolutePath)
                    2 -> AlertDialog.Builder(this)
                        .setMessage("이 에피소드를 지울까요?")
                        .setPositiveButton("삭제") { _, _ ->
                            EpisodeStore.delete(ep)
                            reload()
                        }
                        .setNegativeButton("취소", null)
                        .show()
                }
            }
            .show()
    }
}
