package com.morningcast.app

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 재생 화면 (알람 때 잠금화면 위에 표시) */
class PlayerActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var userSeeking = false
    private val speeds = listOf(0.8f, 0.9f, 1.0f, 1.1f, 1.2f, 1.3f, 1.5f)

    private lateinit var tvClock: TextView
    private lateinit var tvTitle: TextView
    private lateinit var tvSegment: TextView
    private lateinit var tvTime: TextView
    private lateinit var seek: SeekBar
    private lateinit var btnToggle: Button
    private lateinit var btnSpeed: Button
    private lateinit var btnPlayLatest: Button

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)
        Ui.applyInsets(findViewById(R.id.root))

        tvClock = findViewById(R.id.tvClock)
        tvTitle = findViewById(R.id.tvTitle)
        tvSegment = findViewById(R.id.tvSegment)
        tvTime = findViewById(R.id.tvTime)
        seek = findViewById(R.id.seek)
        btnToggle = findViewById(R.id.btnToggle)
        btnSpeed = findViewById(R.id.btnSpeed)
        btnPlayLatest = findViewById(R.id.btnPlayLatest)

        btnToggle.setOnClickListener {
            val svc = PlaybackService.instance
            if (svc != null) svc.toggle() else PlaybackService.playEpisode(this, null)
        }
        findViewById<Button>(R.id.btnBack).setOnClickListener { PlaybackService.instance?.seekBy(-15_000) }
        findViewById<Button>(R.id.btnFwd).setOnClickListener { PlaybackService.instance?.seekBy(30_000) }
        findViewById<Button>(R.id.btnNext).setOnClickListener { PlaybackService.instance?.nextSegment() }
        btnSpeed.setOnClickListener {
            val svc = PlaybackService.instance ?: return@setOnClickListener
            val cur = speeds.indexOfFirst { Math.abs(it - svc.speed) < 0.01f }
            val next = speeds[(cur + 1) % speeds.size]
            svc.setSpeed(next)
            refresh()
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            PlaybackService.instance?.stopAll()
            finish()
        }
        btnPlayLatest.setOnClickListener {
            if (EpisodeStore.latest(this) == null) {
                Ui.toast(this, "아직 만든 에피소드가 없습니다.")
            } else {
                PlaybackService.playEpisode(this, null)
            }
        }
        findViewById<Button>(R.id.btnScript).setOnClickListener {
            val ep = PlaybackService.instance?.episode ?: EpisodeStore.latest(this)
            if (ep == null) Ui.toast(this, "대본이 없습니다.") else TextViewerActivity.open(this, ep.title, ep.scriptFile.absolutePath)
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) tvTime.text = PlaybackService.fmtTime(progress * 1000L)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                userSeeking = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                userSeeking = false
                PlaybackService.instance?.seekTo((sb?.progress ?: 0) * 1000)
            }
        })
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun refresh() {
        tvClock.text = SimpleDateFormat("HH:mm", Locale.KOREA).format(Date())
        val svc = PlaybackService.instance
        if (svc == null) {
            tvTitle.text = "지금은 재생 중이 아닙니다"
            tvSegment.text = ""
            tvTime.text = ""
            seek.isEnabled = false
            seek.progress = 0
            btnToggle.text = "재생"
            btnPlayLatest.visibility = View.VISIBLE
            return
        }
        val fb = svc.fallbackMessage
        if (fb != null) {
            tvTitle.text = "오늘 브리핑을 준비하지 못했어요"
            tvSegment.text = fb
            tvTime.text = "앱의 '로그 보기'에서 원인을 확인할 수 있어요"
            seek.isEnabled = false
            btnToggle.text = "끄기"
            btnPlayLatest.visibility = View.VISIBLE
            return
        }
        btnPlayLatest.visibility = View.GONE
        val ep = svc.episode
        tvTitle.text = ep?.title ?: "모닝캐스트"
        val pos = svc.positionMs
        val dur = svc.durationMs
        tvSegment.text = ep?.segmentLabel(pos) ?: ""
        seek.isEnabled = dur > 0
        seek.max = (dur / 1000).toInt().coerceAtLeast(1)
        if (!userSeeking) {
            seek.progress = (pos / 1000).toInt()
            tvTime.text = "${PlaybackService.fmtTime(pos)} / ${PlaybackService.fmtTime(dur)}"
        }
        btnToggle.text = if (svc.isPlaying) "일시정지" else "재생"
        btnSpeed.text = "속도 ${svc.speed}x"
    }
}
