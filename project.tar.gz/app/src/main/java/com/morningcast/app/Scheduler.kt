package com.morningcast.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * 알람 예약 담당.
 *  - 재생: AlarmManager.setAlarmClock (정확, 절전 모드에서도 울림)
 *  - 생성: setExactAndAllowWhileIdle (전날 저녁)
 */
object Scheduler {
    const val ACTION_PLAY = "com.morningcast.app.PLAY"
    const val ACTION_PLAY_TEST = "com.morningcast.app.PLAY_TEST"
    const val ACTION_GENERATE = "com.morningcast.app.GENERATE"

    private const val RC_PLAY = 101
    private const val RC_GEN = 102
    private const val RC_TEST = 103
    private const val RC_SHOW = 104

    const val MAX_ATTEMPTS = 4
    const val RETRY_GAP_MS = 30 * 60_000L

    fun isDayEnabled(s: Settings, calDay: Int): Boolean = ((s.days shr (calDay - 1)) and 1) == 1

    /** from 이후 가장 가까운 재생 시각 (요일 반영). 없으면 null */
    fun nextPlaybackTime(s: Settings, from: Long): Long? {
        if ((s.days and 0x7F) == 0) return null
        val cal = Calendar.getInstance()
        cal.timeInMillis = from
        for (i in 0..7) {
            if (i > 0) cal.add(Calendar.DAY_OF_YEAR, 1)
            cal.set(Calendar.HOUR_OF_DAY, s.wakeHour)
            cal.set(Calendar.MINUTE, s.wakeMinute)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            if (cal.timeInMillis > from && isDayEnabled(s, cal.get(Calendar.DAY_OF_WEEK))) {
                return cal.timeInMillis
            }
        }
        return null
    }

    /** 재생 시각 playAt 에 맞춘 생성 시각 (보통 전날 저녁) */
    fun generationTimeFor(s: Settings, playAt: Long): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = playAt
        cal.set(Calendar.HOUR_OF_DAY, s.genHour)
        cal.set(Calendar.MINUTE, s.genMinute)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis > playAt - 15 * 60_000L) cal.add(Calendar.DAY_OF_YEAR, -1)
        return cal.timeInMillis
    }

    /** 지금 생성하면 어느 재생 시각을 위한 것인지 */
    fun targetPlayTime(s: Settings, now: Long = System.currentTimeMillis()): Long {
        if (!s.enabled) return now
        return nextPlaybackTime(s, now) ?: now
    }

    fun dateKey(t: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(t))

    fun fmt(t: Long): String =
        if (t <= 0L) "-" else SimpleDateFormat("M/d(E) HH:mm", Locale.KOREAN).format(Date(t))

    fun rescheduleAll(ctx: Context) {
        try {
            doReschedule(ctx.applicationContext)
        } catch (e: Exception) {
            AppLog.error(ctx, "알람 예약 실패", e)
        }
    }

    private fun doReschedule(ctx: Context) {
        val s = Settings.load(ctx)
        val st = AppState(ctx)
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val playPi = broadcastPi(ctx, ACTION_PLAY, RC_PLAY)
        val genPi = broadcastPi(ctx, ACTION_GENERATE, RC_GEN)
        am.cancel(playPi)
        am.cancel(genPi)
        st.nextPlayAt = 0L
        st.nextGenAt = 0L
        if (!s.enabled) {
            AppLog.log(ctx, "자동 재생이 꺼져 있어 알람을 예약하지 않았습니다")
            return
        }
        val now = System.currentTimeMillis()
        val playAt = nextPlaybackTime(s, now)
        if (playAt == null) {
            AppLog.log(ctx, "선택된 요일이 없어 알람을 예약하지 않았습니다")
            return
        }
        setAlarmClock(ctx, am, playAt, playPi)
        st.nextPlayAt = playAt

        val keyMissing = if (s.scriptProvider == "claude") s.claudeKey.isBlank() else s.geminiKey.isBlank()
        if (keyMissing) {
            AppLog.log(ctx, "API 키가 없어 생성은 예약하지 않았습니다 (재생 ${fmt(playAt)})")
            return
        }
        val genAt = generationTimeFor(s, playAt)
        if (EpisodeStore.hasFreshEpisodeFor(ctx, playAt, genAt)) {
            AppLog.log(ctx, "다음 재생 ${fmt(playAt)} (에피소드 준비 완료)")
            return
        }
        var genTime = genAt
        if (genAt <= now) {
            // 생성 시각을 이미 지났는데 아직 에피소드가 없음 → 곧바로(또는 재시도 간격 후) 생성
            val target = dateKey(playAt)
            val attempts = if (st.attemptTarget == target) st.attempts else 0
            if (attempts >= MAX_ATTEMPTS) {
                AppLog.log(ctx, "생성 재시도 한도(${MAX_ATTEMPTS}회)에 도달해 더 시도하지 않습니다")
                return
            }
            if (GenerationService.isRunning) return
            var earliest = now + 60_000L
            if (attempts > 0) earliest = maxOf(earliest, st.lastAttemptAt + RETRY_GAP_MS)
            if (playAt - earliest < 15 * 60_000L) {
                AppLog.log(ctx, "재생 시각까지 여유가 없어 생성을 건너뜁니다")
                return
            }
            genTime = earliest
        }
        setExact(ctx, am, genTime, genPi)
        st.nextGenAt = genTime
        AppLog.log(ctx, "예약 완료 → 생성 ${fmt(genTime)}, 재생 ${fmt(playAt)}")
    }

    fun scheduleTestPlayback(ctx: Context, delayMs: Long): Long {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val at = System.currentTimeMillis() + delayMs
        if (am != null) setAlarmClock(ctx, am, at, broadcastPi(ctx, ACTION_PLAY_TEST, RC_TEST))
        return at
    }

    fun canExact(am: AlarmManager): Boolean = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()

    private fun setAlarmClock(ctx: Context, am: AlarmManager, at: Long, op: PendingIntent) {
        val show = PendingIntent.getActivity(
            ctx, RC_SHOW,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        try {
            if (canExact(am)) {
                am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), op)
            } else {
                AppLog.log(ctx, "정확한 알람 권한이 없어 대략적인 알람으로 예약합니다")
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, op)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, op)
        }
    }

    private fun setExact(ctx: Context, am: AlarmManager, at: Long, op: PendingIntent) {
        try {
            if (canExact(am)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, op)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, op)
            }
        } catch (e: SecurityException) {
            AppLog.log(ctx, "정확한 알람 예약 실패 → 대략적인 알람 사용")
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, op)
        }
    }

    private fun broadcastPi(ctx: Context, action: String, rc: Int): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).setAction(action)
        return PendingIntent.getBroadcast(
            ctx, rc, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
}
