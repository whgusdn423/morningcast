package com.morningcast.app

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object TtsHelper {
    const val GOOGLE_TTS = "com.google.android.tts"

    fun isInstalled(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    fun pickEngine(ctx: Context, pref: String): String? = when {
        pref.isNotEmpty() -> pref
        isInstalled(ctx, GOOGLE_TTS) -> GOOGLE_TTS
        else -> null
    }

    /** 백그라운드 스레드에서 호출: 초기화가 끝날 때까지 기다립니다. (메인 스레드에서 호출 금지) */
    fun createBlocking(ctx: Context, engine: String?, timeoutSec: Long = 25): TextToSpeech? {
        val latch = CountDownLatch(1)
        var status = TextToSpeech.ERROR
        val listener = TextToSpeech.OnInitListener { st ->
            status = st
            latch.countDown()
        }
        val t = if (engine != null) TextToSpeech(ctx, listener, engine) else TextToSpeech(ctx, listener)
        latch.await(timeoutSec, TimeUnit.SECONDS)
        if (status == TextToSpeech.SUCCESS) return t
        try {
            t.shutdown()
        } catch (_: Exception) {
        }
        return if (engine != null) createBlocking(ctx, null, timeoutSec) else null
    }

    fun koreanVoices(t: TextToSpeech): List<Voice> = try {
        (t.voices ?: emptySet()).filter { it.locale.language == "ko" }.sortedBy { it.name }
    } catch (e: Exception) {
        emptyList()
    }

    fun voiceLabel(v: Voice): String {
        val net = if (v.isNetworkConnectionRequired) " (인터넷 필요)" else ""
        return v.name + net
    }
}

/** 휴대폰에 설치된 음성 엔진(Google/삼성 TTS)으로 음성 파일을 만듭니다. 무료·무제한. */
class AndroidTtsSynth(private val ctx: Context, private val s: Settings) {
    private val latches = ConcurrentHashMap<String, CountDownLatch>()
    private val errors = ConcurrentHashMap<String, String>()

    fun synthesize(utts: List<Utterance>, w: PcmWriter, starts: MutableMap<Int, Long>, progress: (String) -> Unit) {
        val engine = TtsHelper.pickEngine(ctx, s.androidEngine)
        val t = TtsHelper.createBlocking(ctx, engine)
            ?: throw IOException("휴대폰 음성 엔진(TTS)을 시작하지 못했습니다. 설정 > 텍스트 음성 변환에서 엔진을 확인해 주세요.")
        try {
            val lr = t.setLanguage(Locale.KOREAN)
            if (lr == TextToSpeech.LANG_MISSING_DATA || lr == TextToSpeech.LANG_NOT_SUPPORTED) {
                throw IOException("한국어 음성 데이터가 없습니다. 설정 > 텍스트 음성 변환에서 한국어 음성을 내려받아 주세요.")
            }
            val voices = TtsHelper.koreanVoices(t)
            val base: Voice? = voices.firstOrNull { it.name == s.androidVoice1 } ?: t.voice
            var second: Voice? = voices.firstOrNull { it.name == s.androidVoice2 }
            if (second == null && s.style == "duo") {
                second = voices.firstOrNull { it.name != base?.name && !it.isNetworkConnectionRequired }
                    ?: voices.firstOrNull { it.name != base?.name }
            }
            t.setSpeechRate(s.speechRate)
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId != null) latches[utteranceId]?.countDown()
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (utteranceId == null) return
                    errors[utteranceId] = "error"
                    latches[utteranceId]?.countDown()
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    if (utteranceId == null) return
                    errors[utteranceId] = "code $errorCode"
                    latches[utteranceId]?.countDown()
                }
            })
            val tmpDir = File(ctx.cacheDir, "tts")
            tmpDir.mkdirs()
            val speechCount = utts.count { !it.chime }.coerceAtLeast(1)
            var done = 0
            for ((i, u) in utts.withIndex()) {
                if (u.chime) {
                    if (u.segment >= 0) starts[u.segment] = w.positionMs
                    w.writeChime()
                    continue
                }
                val pieces = Speech.split(Speech.forTts(u.text), 1500)
                for ((k, piece) in pieces.withIndex()) {
                    val voice = if (u.speaker == 1) second else base
                    if (voice != null) {
                        try {
                            t.setVoice(voice)
                        } catch (_: Exception) {
                        }
                    }
                    t.setPitch(if (u.speaker == 1 && second == null) 0.82f else 1.0f)
                    val f = File(tmpDir, "u${i}_$k.wav")
                    synthToFile(t, piece, f, "u${i}_${k}_${System.nanoTime()}")
                    w.appendPcm(Wav.readFile(f))
                    f.delete()
                }
                w.writeSilence(u.pauseAfterMs)
                done++
                if (done % 4 == 0) progress("음성 만드는 중 ${done * 100 / speechCount}%")
            }
        } finally {
            try {
                t.stop()
                t.shutdown()
            } catch (_: Exception) {
            }
        }
    }

    private fun synthToFile(t: TextToSpeech, text: String, f: File, id: String) {
        f.delete()
        val latch = CountDownLatch(1)
        latches[id] = latch
        errors.remove(id)
        val r = t.synthesizeToFile(text, Bundle(), f, id)
        if (r != TextToSpeech.SUCCESS) {
            latches.remove(id)
            throw IOException("음성 합성 요청이 거부되었습니다")
        }
        val ok = latch.await(180, TimeUnit.SECONDS)
        latches.remove(id)
        if (!ok) throw IOException("음성 합성이 너무 오래 걸립니다")
        val err = errors.remove(id)
        if (err != null) throw IOException("음성 합성 오류($err)")
        var waited = 0
        while ((!f.exists() || f.length() <= 44) && waited < 3000) {
            Thread.sleep(100)
            waited += 100
        }
        if (!f.exists() || f.length() <= 44) throw IOException("음성 파일이 비어 있습니다")
    }
}

/** Gemini TTS: 자연스러운 2인 대화 음성 (무료 등급 한도 내 무료, 결제 등록 시 유료) */
class GeminiTtsSynth(private val ctx: Context, private val s: Settings) {
    private val model = s.geminiTtsModel.trim().ifEmpty { Settings.DEFAULT_GEMINI_TTS_MODEL }.removePrefix("models/")
    private var legacy = isLegacyModel(model)
    private val names = arrayOf("Jisoo", "Minho")

    private class Chunk(val chime: Boolean, val segment: Int, val turns: List<Utterance>, val pauseAfterMs: Int)

    fun synthesize(utts: List<Utterance>, w: PcmWriter, starts: MutableMap<Int, Long>, progress: (String) -> Unit) {
        val chunks = makeChunks(utts, 1300)
        val total = chunks.count { !it.chime }.coerceAtLeast(1)
        var done = 0
        for (c in chunks) {
            if (c.chime) {
                if (c.segment >= 0) starts[c.segment] = w.positionMs
                w.writeChime()
                continue
            }
            val pcm = requestAudio(c.turns)
            w.appendPcm(pcm)
            w.writeSilence(c.pauseAfterMs)
            done++
            progress("고품질 음성 만드는 중 $done/$total")
            Llm.sleep(1500)
        }
    }

    private fun makeChunks(utts: List<Utterance>, maxChars: Int): List<Chunk> {
        val out = ArrayList<Chunk>()
        val cur = ArrayList<Utterance>()
        var chars = 0
        fun flush() {
            if (cur.isNotEmpty()) {
                out.add(Chunk(false, cur[0].segment, ArrayList(cur), cur.last().pauseAfterMs))
                cur.clear()
                chars = 0
            }
        }
        for (u in utts) {
            if (u.chime) {
                flush()
                out.add(Chunk(true, u.segment, emptyList(), 0))
                continue
            }
            for (piece in Speech.split(Speech.forTts(u.text), maxChars)) {
                if (chars + piece.length > maxChars) flush()
                cur.add(Utterance(u.speaker, piece, u.segment, false, u.pauseAfterMs))
                chars += piece.length
            }
        }
        flush()
        return out
    }

    internal fun buildBody(turns: List<Utterance>): JSONObject {
        val duo = s.style == "duo"
        val parts = JSONArray()
        if (!legacy) {
            for (t in turns) {
                val meta = JSONObject()
                if (duo) meta.put("speaker", names[t.speaker.coerceIn(0, 1)])
                meta.put("style", if (!duo) STYLE_SOLO else if (t.speaker == 0) STYLE_HOST else STYLE_GUEST)
                parts.put(JSONObject().put("text", t.text).put("speech_metadata", meta))
            }
        } else {
            val sb = StringBuilder()
            if (duo) {
                sb.append("TTS the following conversation between ${names[0]} and ${names[1]}:\n")
                for (t in turns) sb.append(names[t.speaker.coerceIn(0, 1)]).append(": ").append(t.text).append('\n')
            } else {
                for (t in turns) sb.append(t.text).append("\n\n")
            }
            parts.put(JSONObject().put("text", sb.toString().trim()))
        }
        val speechConfig = JSONObject()
        if (duo) {
            val cfgs = JSONArray()
            cfgs.put(voiceFor(names[0], s.geminiVoice1))
            cfgs.put(voiceFor(names[1], s.geminiVoice2))
            speechConfig.put("multiSpeakerVoiceConfig", JSONObject().put("speakerVoiceConfigs", cfgs))
        } else {
            speechConfig.put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", s.geminiVoice1)))
        }
        return JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put(
                "generationConfig",
                JSONObject().put("responseModalities", JSONArray().put("AUDIO")).put("speechConfig", speechConfig)
            )
    }

    private fun voiceFor(speaker: String, voice: String): JSONObject = JSONObject()
        .put("speaker", speaker)
        .put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))

    fun requestAudio(turns: List<Utterance>): Pcm {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        var attempt = 0
        while (true) {
            attempt++
            val resp = try {
                Http.postJson(url, mapOf("x-goog-api-key" to s.geminiKey.trim()), buildBody(turns).toString(), 240_000)
            } catch (e: IOException) {
                if (attempt < 4) {
                    Llm.sleep(15_000L * attempt)
                    continue
                }
                throw LlmException("네트워크 오류: ${e.message}")
            }
            if (resp.code == 200) {
                val pcm = extractAudio(resp.body)
                if (pcm != null && pcm.samples.size > pcm.sampleRate / 2) return pcm
                if (attempt < 3) {
                    AppLog.log(ctx, "Gemini 음성 응답에 오디오가 없어 다시 요청합니다")
                    Llm.sleep(3000)
                    continue
                }
                throw LlmException("Gemini 음성 응답에 오디오가 없습니다")
            }
            val err = Llm.parseGeminiError(resp)
            AppLog.log(ctx, "Gemini 음성 오류: ${err.summary}")
            if (!legacy && resp.code == 400 &&
                (err.message.contains("speech_metadata", true) || err.message.contains("Unknown name", true) ||
                    err.message.contains("Invalid JSON payload", true))
            ) {
                legacy = true
                AppLog.log(ctx, "이전 방식의 음성 요청 형식으로 다시 시도합니다")
                continue
            }
            when {
                resp.code == 401 || resp.code == 403 || err.message.contains("API key not valid", true) ->
                    throw AuthException("Gemini API 키 오류: ${err.message.take(120)}")
                resp.code == 404 -> throw ConfigException("Gemini 음성 모델 '$model'을 찾을 수 없습니다")
                resp.code == 429 -> {
                    if (err.perDay) throw QuotaException("Gemini 음성 하루 한도를 넘었습니다")
                    if (attempt < 7) {
                        Llm.sleep(((err.retryDelaySec ?: 30) + 2) * 1000L)
                        continue
                    }
                    throw QuotaException("Gemini 음성 요청 한도 초과")
                }
                resp.code >= 500 && attempt < 4 -> {
                    Llm.sleep(15_000L * attempt)
                    continue
                }
                else -> throw LlmException("Gemini 음성 오류 ${err.summary}")
            }
        }
    }

    companion object {
        const val STYLE_SOLO = "warm, clear and friendly Korean morning news anchor; calm, steady pace"
        const val STYLE_HOST = "bright, warm Korean morning radio host; natural conversational pace"
        const val STYLE_GUEST = "calm, thoughtful Korean commentator; clear and friendly explanations"

        /** 화면에 보여 줄 Gemini 기본 음성 목록 (이름 — 느낌) */
        val VOICES = listOf(
            "Kore" to "단단한", "Charon" to "정보 전달형", "Puck" to "경쾌한", "Aoede" to "산뜻한",
            "Leda" to "젊은", "Orus" to "단단한", "Zephyr" to "밝은", "Fenrir" to "활기찬",
            "Callirrhoe" to "편안한", "Autonoe" to "밝은", "Enceladus" to "숨결 섞인", "Iapetus" to "또렷한",
            "Umbriel" to "편안한", "Algieba" to "부드러운", "Despina" to "부드러운", "Erinome" to "또렷한",
            "Algenib" to "거친", "Rasalgethi" to "정보 전달형", "Laomedeia" to "경쾌한", "Achernar" to "부드러운",
            "Alnilam" to "단단한", "Schedar" to "차분한", "Gacrux" to "성숙한", "Pulcherrima" to "적극적인",
            "Achird" to "친근한", "Zubenelgenubi" to "캐주얼한", "Vindemiatrix" to "온화한", "Sadachbia" to "생기 있는",
            "Sadaltager" to "박식한", "Sulafat" to "따뜻한"
        )

        fun isLegacyModel(m: String): Boolean =
            m.contains("2.5") || m.contains("3.1-flash-tts") || m.contains("preview-tts")

        private fun indexOf(hay: ByteArray, needle: ByteArray, from: Int): Int {
            var i = maxOf(0, from)
            val last = hay.size - needle.size
            outer@ while (i <= last) {
                for (j in needle.indices) {
                    if (hay[i + j] != needle[j]) {
                        i++
                        continue@outer
                    }
                }
                return i
            }
            return -1
        }

        /** "key": "value" 의 value 범위(시작, 끝) — 이스케이프 없는 짧은 문자열/base64 용 */
        private fun stringValueRange(b: ByteArray, keyPos: Int, keyLen: Int): IntArray? {
            var i = keyPos + keyLen
            while (i < b.size && b[i] != ':'.code.toByte()) i++
            while (i < b.size && b[i] != '"'.code.toByte()) i++
            if (i >= b.size) return null
            val start = i + 1
            var end = start
            while (end < b.size && b[end] != '"'.code.toByte()) end++
            if (end >= b.size) return null
            return intArrayOf(start, end)
        }

        /** 응답 JSON 에서 inlineData.data(base64 오디오)를 메모리 효율적으로 꺼냅니다. */
        fun extractAudio(body: ByteArray): Pcm? {
            var idx = indexOf(body, "\"inlineData\"".toByteArray(), 0)
            if (idx < 0) idx = indexOf(body, "\"inline_data\"".toByteArray(), 0)
            if (idx < 0) return null
            val dataKey = "\"data\"".toByteArray()
            val dk = indexOf(body, dataKey, idx)
            if (dk < 0) return null
            val r = stringValueRange(body, dk, dataKey.size) ?: return null
            var mime = ""
            for (k in listOf("\"mimeType\"", "\"mime_type\"")) {
                val kb = k.toByteArray()
                val mk = indexOf(body, kb, idx)
                if (mk >= 0) {
                    val mr = stringValueRange(body, mk, kb.size)
                    if (mr != null && mr[1] - mr[0] < 200) {
                        mime = String(body, mr[0], mr[1] - mr[0], Charsets.US_ASCII)
                        break
                    }
                }
            }
            for (p in r[0] until r[1]) {
                if (body[p] == '\\'.code.toByte()) return extractWithJson(body)
            }
            val audio = Base64.decode(body, r[0], r[1] - r[0], Base64.DEFAULT)
            return toPcm(audio, mime)
        }

        private fun extractWithJson(body: ByteArray): Pcm? {
            val o = JSONObject(String(body, Charsets.UTF_8))
            val parts = o.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: return null
            for (i in 0 until parts.length()) {
                val inline = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                val data = inline.optString("data")
                if (data.isEmpty()) continue
                return toPcm(Base64.decode(data, Base64.DEFAULT), inline.optString("mimeType"))
            }
            return null
        }

        private fun toPcm(audio: ByteArray, mime: String): Pcm {
            if (Wav.isWav(audio)) return Wav.parse(audio)
            val rate = Regex("rate=(\\d+)").find(mime)?.groupValues?.get(1)?.toIntOrNull() ?: 24000
            return Wav.rawL16(audio, 0, audio.size, rate)
        }
    }
}
