package com.morningcast.app

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 앱 내부 로그(설정 화면의 '로그 보기'에서 확인). 문제 해결용입니다. */
object AppLog {
    private const val TAG = "MorningCast"
    private const val MAX_BYTES = 300_000L

    fun file(ctx: Context): File = File(ctx.filesDir, "log.txt")

    @Synchronized
    fun log(ctx: Context, msg: String) {
        Log.i(TAG, msg)
        try {
            val f = file(ctx)
            val ts = SimpleDateFormat("MM-dd HH:mm:ss", Locale.KOREA).format(Date())
            f.appendText("[$ts] $msg\n")
            if (f.length() > MAX_BYTES) {
                val text = f.readText()
                f.writeText(text.substring(text.length / 2))
            }
        } catch (e: Exception) {
            Log.w(TAG, "log write failed", e)
        }
    }

    fun error(ctx: Context, msg: String, t: Throwable) {
        log(ctx, "$msg: ${t.javaClass.simpleName}: ${t.message}")
        Log.e(TAG, msg, t)
    }

    fun read(ctx: Context): String = try {
        file(ctx).readText()
    } catch (e: Exception) {
        ""
    }

    fun clear(ctx: Context) {
        try {
            file(ctx).delete()
        } catch (_: Exception) {
        }
    }
}
