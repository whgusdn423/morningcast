package com.morningcast.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.util.Linkify
import android.view.View
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/** 대본·출처·로그 보기 */
class TextViewerActivity : Activity() {

    companion object {
        private const val EXTRA_TITLE = "title"
        private const val EXTRA_PATH = "path"
        private const val EXTRA_LOG = "log"

        fun open(ctx: Context, title: String, path: String) {
            ctx.startActivity(
                Intent(ctx, TextViewerActivity::class.java).putExtra(EXTRA_TITLE, title).putExtra(EXTRA_PATH, path)
            )
        }

        fun openLog(ctx: Context) {
            ctx.startActivity(
                Intent(ctx, TextViewerActivity::class.java).putExtra(EXTRA_TITLE, "로그").putExtra(EXTRA_LOG, true)
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_text)
        Ui.applyInsets(findViewById(R.id.root))
        val isLog = intent.getBooleanExtra(EXTRA_LOG, false)
        val tvBody = findViewById<TextView>(R.id.tvBody)
        val scroll = findViewById<ScrollView>(R.id.scroll)
        findViewById<TextView>(R.id.tvTitle).text = intent.getStringExtra(EXTRA_TITLE) ?: ""
        val text = if (isLog) {
            AppLog.read(this).ifEmpty { "(로그가 없습니다)" }
        } else {
            val p = intent.getStringExtra(EXTRA_PATH)
            try {
                if (p == null) "" else File(p).readText()
            } catch (e: Exception) {
                "파일을 열 수 없습니다: ${e.message}"
            }
        }
        tvBody.text = text
        Linkify.addLinks(tvBody, Linkify.WEB_URLS)
        findViewById<Button>(R.id.btnCopy).setOnClickListener {
            val cm = getSystemService(ClipboardManager::class.java)
            cm?.setPrimaryClip(ClipData.newPlainText("MorningCast", text))
            Ui.toast(this, "복사했습니다")
        }
        if (isLog) {
            val clear = findViewById<Button>(R.id.btnClear)
            clear.visibility = View.VISIBLE
            clear.setOnClickListener {
                AppLog.clear(this)
                tvBody.text = ""
            }
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
    }
}
