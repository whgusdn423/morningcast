package com.morningcast.app

import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/** 팟캐스트를 만드는 포그라운드 서비스 (화면이 꺼져 있어도 끝까지 진행) */
class GenerationService : Service() {

    companion object {
        private const val EXTRA_MANUAL = "manual"
        private const val EXTRA_SCRIPT_PATH = "scriptPath"
        private const val EXTRA_TITLE = "title"
        private const val EXTRA_VOICE = "voice"

        /** 지금 하는 작업이 '대본 읽어 주기'인지 */
        @Volatile
        var scriptMode = false
            private set

        /** 마지막 읽어 주기 결과 (화면에서 확인) */
        @Volatile
        var lastScriptEpisodeId: String? = null
        @Volatile
        var lastScriptError: String? = null
        @Volatile
        var lastScriptNote: String = ""

        /** 붙여 넣은 대본을 음성 파일로 만들기 시작 */
        fun startScript(ctx: Context, scriptPath: String, title: String, voice: String): Boolean {
            if (isRunning) return false
            lastScriptEpisodeId = null
            lastScriptError = null
            lastScriptNote = ""
            val i = Intent(ctx, GenerationService::class.java)
                .putExtra(EXTRA_SCRIPT_PATH, scriptPath)
                .putExtra(EXTRA_TITLE, title)
                .putExtra(EXTRA_VOICE, voice)
            return try {
                ctx.startForegroundService(i)
                true
            } catch (e: Exception) {
                AppLog.error(ctx, "읽어 주기 서비스를 시작하지 못했습니다", e)
                lastScriptError = "휴대폰이 백그라운드 작업을 막았습니다. '배터리 최적화 제외'를 설정해 주세요."
                false
            }
        }

        @Volatile
        var isRunning = false
            private set

        @Volatile
        var progress: String = ""
            private set

        fun start(ctx: Context, manual: Boolean) {
            val i = Intent(ctx, GenerationService::class.java).putExtra(EXTRA_MANUAL, manual)
            try {
                ctx.startForegroundService(i)
            } catch (e: Exception) {
                AppLog.error(ctx, "생성 서비스를 시작하지 못했습니다", e)
                Notifs.showStatus(
                    ctx, "팟캐스트를 만들지 못했어요",
                    "휴대폰이 백그라운드 작업을 막았습니다. 앱 설정에서 '배터리 최적화 제외'를 해 주시고, 앱을 열어 '지금 만들기'를 눌러 주세요."
                )
            }
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = Notifs.progressNotification(this, "준비 중…")
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(Notifs.ID_GEN, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(Notifs.ID_GEN, n)
            }
        } catch (e: Exception) {
            AppLog.error(this, "생성 서비스 포그라운드 전환 실패", e)
            Notifs.showStatus(
                this, "팟캐스트를 만들지 못했어요",
                "휴대폰이 백그라운드 작업을 막았습니다. '배터리 최적화 제외'를 설정해 주세요."
            )
            stopSelf()
            return START_NOT_STICKY
        }
        if (isRunning) return START_NOT_STICKY
        isRunning = true
        val scriptPath = intent?.getStringExtra(EXTRA_SCRIPT_PATH)
        scriptMode = scriptPath != null
        val manual = intent?.getBooleanExtra(EXTRA_MANUAL, false) ?: false
        if (!scriptMode) recordAttempt()
        val pm = getSystemService(PowerManager::class.java)
        if (pm != null) {
            val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MorningCast:generate")
            wl.setReferenceCounted(false)
            wl.acquire(60 * 60 * 1000L)
            wakeLock = wl
        }
        if (scriptPath != null) {
            val title = intent.getStringExtra(EXTRA_TITLE) ?: ""
            val voice = intent.getStringExtra(EXTRA_VOICE) ?: "android"
            Thread({ runScriptJob(scriptPath, title, voice) }, "morningcast-script").start()
        } else {
            Thread({ runJob(manual) }, "morningcast-generator").start()
        }
        return START_NOT_STICKY
    }

    private fun recordAttempt() {
        val st = AppState(this)
        val s = Settings.load(this)
        val target = Scheduler.dateKey(Scheduler.targetPlayTime(s))
        if (st.attemptTarget != target) {
            st.attemptTarget = target
            st.attempts = 0
        }
        st.attempts = st.attempts + 1
        st.lastAttemptAt = System.currentTimeMillis()
    }

    private fun runJob(manual: Boolean) {
        val ctx = applicationContext
        val st = AppState(ctx)
        AppLog.log(ctx, if (manual) "수동 생성 시작" else "예약 생성 시작")
        try {
            val result = PodcastGenerator(ctx, manual) { msg -> updateProgress(msg) }.run()
            val mins = (result.episode.durationMs + 30_000) / 60_000
            val warn = if (result.warnings.isEmpty()) "" else "\n참고: " + result.warnings.joinToString(" / ")
            st.lastGenOk = true
            st.lastGenAt = System.currentTimeMillis()
            st.lastGenMsg = "완료 · ${result.episode.title} (약 ${mins}분)$warn"
            Notifs.showStatus(ctx, "모닝캐스트 준비 완료", "${result.episode.title} · 약 ${mins}분$warn")
        } catch (e: Throwable) {
            AppLog.error(ctx, "생성 실패", e)
            st.lastGenOk = false
            st.lastGenAt = System.currentTimeMillis()
            st.lastGenMsg = "실패 · ${e.message ?: e.javaClass.simpleName}"
            if (e is ConfigException || e is AuthException) st.attempts = Scheduler.MAX_ATTEMPTS
            Notifs.showStatus(ctx, "모닝캐스트 생성 실패", "${e.message ?: e.javaClass.simpleName}\n앱을 열어 설정과 로그를 확인해 주세요.")
        } finally {
            isRunning = false
            progress = ""
            try {
                wakeLock?.let { if (it.isHeld) it.release() }
            } catch (_: Exception) {
            }
            Scheduler.rescheduleAll(ctx)
            Handler(Looper.getMainLooper()).post {
                try {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                } catch (_: Exception) {
                }
                stopSelf()
            }
        }
    }

    private fun runScriptJob(path: String, title: String, voice: String) {
        val ctx = applicationContext
        try {
            val text = java.io.File(path).readText()
            val r = ScriptEpisodeBuilder(ctx, text, title, voice) { msg -> updateProgress(msg) }.run()
            val mins = (r.episode.durationMs + 30_000) / 60_000
            lastScriptNote = if (r.warnings.isEmpty()) "" else r.warnings.joinToString(" / ")
            lastScriptEpisodeId = r.episode.id
            Notifs.showStatus(
                ctx, "읽어 주기 준비 완료",
                "${r.episode.title} · 약 ${mins}분\n에피소드 목록에서 들을 수 있어요." + if (lastScriptNote.isEmpty()) "" else "\n참고: $lastScriptNote",
                EpisodesActivity::class.java
            )
        } catch (e: Throwable) {
            AppLog.error(ctx, "읽어 주기 실패", e)
            lastScriptError = e.message ?: e.javaClass.simpleName
            Notifs.showStatus(ctx, "읽어 주기를 만들지 못했어요", lastScriptError ?: "")
        } finally {
            isRunning = false
            scriptMode = false
            progress = ""
            try {
                wakeLock?.let { if (it.isHeld) it.release() }
            } catch (_: Exception) {
            }
            // 만드는 동안 밤 예약 생성이 밀렸을 수 있으므로 다시 예약
            Scheduler.rescheduleAll(ctx)
            Handler(Looper.getMainLooper()).post {
                try {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                } catch (_: Exception) {
                }
                stopSelf()
            }
        }
    }

    private fun updateProgress(msg: String) {
        progress = msg
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm?.notify(
                Notifs.ID_GEN,
                Notifs.progressNotification(this, msg, if (scriptMode) "대본 읽어 주기 만드는 중" else "모닝캐스트 만드는 중")
            )
        } catch (_: Exception) {
        }
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        AppLog.log(this, "시스템이 생성 서비스 시간 제한을 알렸습니다")
        stopSelf()
    }
}
