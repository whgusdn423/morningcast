package com.morningcast.app

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/**
 * 재생 포그라운드 서비스.
 * 예약(알람) 재생은 '알람 볼륨(USAGE_ALARM)'으로 재생합니다.
 * → 안드로이드 17부터 백그라운드 오디오는 알람 용도+정확한 알람 권한일 때만 확실히 허용됩니다.
 */
class PlaybackService : Service(), MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener {

    companion object {
        const val ACTION_SCHEDULED = "com.morningcast.app.play.SCHEDULED"
        const val ACTION_EPISODE = "com.morningcast.app.play.EPISODE"
        const val ACTION_TOGGLE = "com.morningcast.app.play.TOGGLE"
        const val ACTION_STOP = "com.morningcast.app.play.STOP"
        const val ACTION_BACK = "com.morningcast.app.play.BACK"
        const val ACTION_FWD = "com.morningcast.app.play.FWD"
        const val ACTION_NEXT = "com.morningcast.app.play.NEXT"
        private const val EXTRA_ID = "id"
        private const val EXTRA_START = "startMs"
        private const val EXTRA_TEST = "test"

        @Volatile
        var instance: PlaybackService? = null
            private set

        fun startScheduled(ctx: Context, test: Boolean) {
            val i = Intent(ctx, PlaybackService::class.java).setAction(ACTION_SCHEDULED).putExtra(EXTRA_TEST, test)
            try {
                ctx.startForegroundService(i)
            } catch (e: Exception) {
                AppLog.error(ctx, "재생 서비스를 시작하지 못했습니다", e)
                Notifs.showStatus(
                    ctx, "모닝캐스트를 재생하지 못했어요",
                    "휴대폰이 백그라운드 재생을 막았습니다. 앱에서 '배터리 최적화 제외'를 설정해 주세요."
                )
            }
        }

        /** id 가 null 이면 가장 최근 아침 방송. startMs < 0 이면 읽어 주기 에피소드는 들던 곳부터 */
        fun playEpisode(ctx: Context, id: String?, startMs: Long = -1L) {
            val i = Intent(ctx, PlaybackService::class.java).setAction(ACTION_EPISODE)
            if (id != null) i.putExtra(EXTRA_ID, id)
            i.putExtra(EXTRA_START, startMs)
            try {
                ctx.startForegroundService(i)
            } catch (e: Exception) {
                AppLog.error(ctx, "재생 시작 실패", e)
            }
        }

        fun command(ctx: Context, action: String) {
            if (instance == null) return
            try {
                ctx.startService(Intent(ctx, PlaybackService::class.java).setAction(action))
            } catch (e: Exception) {
                AppLog.error(ctx, "재생 명령 실패", e)
            }
        }

        fun fmtTime(ms: Long): String {
            val sec = (ms / 1000).coerceAtLeast(0)
            return String.format("%d:%02d", sec / 60, sec % 60)
        }
    }

    private var player: MediaPlayer? = null
    private var prepared = false
    private var session: MediaSession? = null
    private val handler = Handler(Looper.getMainLooper())
    private var focusRequest: AudioFocusRequest? = null
    private var currentAttrs: AudioAttributes? = null
    private var pausedByFocus = false
    private var fullScreenShown = false
    private var settings = Settings()
    private var fadeVol = 1f

    var episode: Episode? = null
        private set
    var scheduled = false
        private set
    var fallbackMessage: String? = null
        private set

    val isPlaying: Boolean
        get() = try {
            prepared && player?.isPlaying == true
        } catch (e: Exception) {
            false
        }

    val positionMs: Long
        get() = try {
            if (prepared) (player?.currentPosition ?: 0).toLong() else 0L
        } catch (e: Exception) {
            0L
        }

    val durationMs: Long
        get() = try {
            val d = if (prepared && fallbackMessage == null) (player?.duration ?: 0).toLong() else 0L
            if (d > 0) d else (episode?.durationMs ?: 0L)
        } catch (e: Exception) {
            episode?.durationMs ?: 0L
        }

    val speed: Float get() = settings.playbackSpeed

    private val fadeRunnable = object : Runnable {
        override fun run() {
            val p = player ?: return
            fadeVol = minOf(1f, fadeVol + 0.035f)
            try {
                p.setVolume(fadeVol, fadeVol)
            } catch (_: Exception) {
            }
            if (fadeVol < 1f) handler.postDelayed(this, 500)
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (player != null && isPlaying) {
                updateSession()
                updateNotification()
            }
            handler.postDelayed(this, 10_000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        Notifs.ensureChannels(this)
        settings = Settings.load(this)
        initSession()
        handler.postDelayed(ticker, 10_000)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_TOGGLE
        if (action == ACTION_SCHEDULED) {
            scheduled = true
            fullScreenShown = false
        } else if (action == ACTION_EPISODE) {
            scheduled = false
        }
        startFg()
        when (action) {
            ACTION_SCHEDULED -> startScheduledPlayback(intent?.getBooleanExtra(EXTRA_TEST, false) ?: false)
            ACTION_EPISODE -> {
                val id = intent?.getStringExtra(EXTRA_ID)
                val ep = if (id != null) EpisodeStore.get(this, id) else EpisodeStore.latest(this)
                if (ep == null || !ep.audioFile.exists()) {
                    stopAll()
                } else {
                    val req = intent?.getLongExtra(EXTRA_START, -1L) ?: -1L
                    val start = if (req >= 0) req else if (ep.isScript) EpisodeStore.resumePosition(this, ep) else 0L
                    play(ep, start.toInt())
                }
            }
            ACTION_TOGGLE -> toggle()
            ACTION_STOP -> stopAll()
            ACTION_BACK -> seekBy(-15_000)
            ACTION_FWD -> seekBy(30_000)
            ACTION_NEXT -> nextSegment()
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val n = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(Notifs.ID_PLAY, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(Notifs.ID_PLAY, n)
            }
        } catch (e: Exception) {
            AppLog.error(this, "재생 서비스 포그라운드 전환 실패", e)
        }
    }

    private fun startScheduledPlayback(test: Boolean) {
        settings = Settings.load(this)
        val now = System.currentTimeMillis()
        val ep = if (test) EpisodeStore.latest(this) else EpisodeStore.pickForPlayback(this, now)
        if (ep == null) {
            val st = AppState(this)
            val reason = if (!st.lastGenOk && st.lastGenMsg.isNotEmpty()) st.lastGenMsg else "준비된 에피소드가 없습니다."
            AppState(this).lastPlayMsg = "${Scheduler.fmt(now)} 재생 실패: $reason"
            playFallbackAlarm(reason)
        } else {
            AppState(this).lastPlayMsg = "${Scheduler.fmt(now)} 재생: ${ep.title}"
            play(ep, 0)
        }
    }

    private val posSaver = object : Runnable {
        override fun run() {
            savePosition()
            handler.postDelayed(this, 15_000)
        }
    }

    /** 읽어 주기 에피소드는 들은 위치를 기억해 다음에 이어서 재생 */
    private fun savePosition() {
        val ep = episode ?: return
        val p = player ?: return
        if (!ep.isScript || !prepared) return
        try {
            EpisodeStore.savePosition(this, ep.id, p.currentPosition.toLong())
        } catch (_: Exception) {
        }
    }

    private fun play(ep: Episode, startMs: Int) {
        releasePlayer()
        fallbackMessage = null
        episode = ep
        settings = Settings.load(this)
        val useAlarm = scheduled && (settings.useAlarmStream || Build.VERSION.SDK_INT >= 37)
        val attrs = AudioAttributes.Builder()
            .setUsage(if (useAlarm) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        requestFocus(attrs)
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(attrs)
            mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setDataSource(ep.audioFile.absolutePath)
            mp.setOnCompletionListener(this)
            mp.setOnErrorListener(this)
            mp.setOnPreparedListener { p ->
                prepared = true
                if (startMs > 0) p.seekTo(startMs)
                if (settings.fadeIn && scheduled) {
                    fadeVol = 0.15f
                    p.setVolume(fadeVol, fadeVol)
                    handler.removeCallbacks(fadeRunnable)
                    handler.postDelayed(fadeRunnable, 500)
                } else {
                    p.setVolume(1f, 1f)
                }
                p.start()
                applySpeed(p)
                updateSession()
                updateNotification()
                if (ep.isScript) {
                    handler.removeCallbacks(posSaver)
                    handler.postDelayed(posSaver, 15_000)
                }
            }
            player = mp
            prepared = false
            mp.prepareAsync()
            AppLog.log(this, "재생 시작: ${ep.title} (${if (useAlarm) "알람" else "미디어"} 볼륨)")
        } catch (e: Exception) {
            AppLog.error(this, "재생 실패", e)
            try {
                mp.release()
            } catch (_: Exception) {
            }
            player = null
            if (scheduled) playFallbackAlarm("오디오 파일을 열 수 없습니다: ${e.message}") else stopAll()
        }
        updateNotification()
    }

    /** 오늘 에피소드가 없을 때: 기본 알람음을 최대 1분 울리고 이유를 알려 줍니다. */
    private fun playFallbackAlarm(reason: String) {
        releasePlayer()
        episode = null
        fallbackMessage = reason
        AppLog.log(this, "대체 알람음 재생: $reason")
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        requestFocus(attrs)
        try {
            val uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            if (uri == null) throw java.io.IOException("기본 알람음이 없습니다")
            val mp = MediaPlayer()
            mp.setAudioAttributes(attrs)
            mp.setDataSource(this, uri)
            mp.isLooping = true
            mp.setOnErrorListener(this)
            mp.prepare()
            mp.start()
            player = mp
            prepared = true
            handler.postDelayed({ if (fallbackMessage != null) stopAll() }, 60_000)
        } catch (e: Exception) {
            AppLog.error(this, "알람음 재생 실패", e)
        }
        Notifs.showStatus(this, "오늘 모닝캐스트를 준비하지 못했어요", reason)
        updateNotification()
    }

    fun toggle() {
        val p = player
        if (p == null || fallbackMessage != null) {
            stopAll()
            return
        }
        if (!prepared) return
        try {
            if (p.isPlaying) {
                p.pause()
                savePosition()
            } else {
                requestFocus(currentAttrs)
                p.start()
                applySpeed(p)
            }
        } catch (e: Exception) {
            AppLog.error(this, "재생/일시정지 실패", e)
        }
        updateSession()
        updateNotification()
    }

    fun seekBy(deltaMs: Int) {
        val p = player ?: return
        if (!prepared || fallbackMessage != null) return
        try {
            val pos = (p.currentPosition + deltaMs).coerceIn(0, maxOf(0, p.duration - 1000))
            p.seekTo(pos)
        } catch (_: Exception) {
        }
        updateSession()
        updateNotification()
    }

    fun seekTo(posMs: Int) {
        val p = player ?: return
        if (!prepared || fallbackMessage != null) return
        try {
            p.seekTo(posMs.coerceIn(0, maxOf(0, p.duration - 500)))
        } catch (_: Exception) {
        }
        updateSession()
    }

    fun nextSegment() {
        val p = player ?: return
        val ep = episode ?: return
        if (!prepared) return
        try {
            val pos = p.currentPosition.toLong()
            val next = ep.segmentStarts.firstOrNull { it > pos + 1500 }
            p.seekTo(if (next != null) next.toInt() else maxOf(0, p.duration - 15_000))
        } catch (_: Exception) {
        }
        updateSession()
        updateNotification()
    }

    fun setSpeed(sp: Float) {
        settings.playbackSpeed = sp
        val saved = Settings.load(this)
        saved.playbackSpeed = sp
        Settings.save(this, saved)
        val p = player ?: return
        if (isPlaying) applySpeed(p)
    }

    private fun applySpeed(p: MediaPlayer) {
        val sp = settings.playbackSpeed
        try {
            if (sp != 1.0f || p.playbackParams.speed != 1.0f) p.playbackParams = p.playbackParams.setSpeed(sp)
        } catch (e: Exception) {
            AppLog.log(this, "재생 속도를 바꿀 수 없습니다: ${e.message}")
        }
    }

    fun stopAll() {
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        abandonFocus()
        try {
            session?.isActive = false
        } catch (_: Exception) {
        }
        try {
            stopForeground(Service.STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {
        }
        stopSelf()
    }

    private fun releasePlayer() {
        savePosition()
        handler.removeCallbacks(posSaver)
        handler.removeCallbacks(fadeRunnable)
        val p = player
        player = null
        prepared = false
        if (p != null) {
            try {
                p.stop()
            } catch (_: Exception) {
            }
            try {
                p.release()
            } catch (_: Exception) {
            }
        }
    }

    override fun onCompletion(mp: MediaPlayer?) {
        AppLog.log(this, "재생 완료")
        stopAll()
    }

    override fun onError(mp: MediaPlayer?, what: Int, extra: Int): Boolean {
        AppLog.log(this, "재생 오류 what=$what extra=$extra")
        if (scheduled && fallbackMessage == null && episode != null) {
            playFallbackAlarm("재생 중 오류가 났습니다 ($what/$extra)")
        } else {
            stopAll()
        }
        return true
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        abandonFocus()
        try {
            session?.release()
        } catch (_: Exception) {
        }
        session = null
        instance = null
        super.onDestroy()
    }

    // ── 오디오 포커스 ───────────────────────────────────────────────

    private fun requestFocus(attrs: AudioAttributes?) {
        if (attrs == null) return
        currentAttrs = attrs
        val am = getSystemService(AudioManager::class.java) ?: return
        try {
            focusRequest?.let { am.abandonAudioFocusRequest(it) }
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener { change -> onFocusChange(change) }
                .build()
            focusRequest = req
            val r = am.requestAudioFocus(req)
            if (r != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) AppLog.log(this, "오디오 포커스를 받지 못했지만 재생을 계속합니다 ($r)")
        } catch (e: Exception) {
            AppLog.log(this, "오디오 포커스 요청 실패: ${e.message}")
        }
    }

    private fun abandonFocus() {
        val am = getSystemService(AudioManager::class.java) ?: return
        val req = focusRequest ?: return
        try {
            am.abandonAudioFocusRequest(req)
        } catch (_: Exception) {
        }
        focusRequest = null
    }

    private fun onFocusChange(change: Int) {
        val p = player ?: return
        if (!prepared || fallbackMessage != null) return
        try {
            when (change) {
                AudioManager.AUDIOFOCUS_LOSS, AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                    if (p.isPlaying) {
                        p.pause()
                        pausedByFocus = change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT
                    }
                }
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> p.setVolume(0.3f, 0.3f)
                AudioManager.AUDIOFOCUS_GAIN -> {
                    p.setVolume(fadeVol, fadeVol)
                    if (pausedByFocus) {
                        p.start()
                        pausedByFocus = false
                    }
                }
            }
        } catch (_: Exception) {
        }
        updateSession()
        updateNotification()
    }

    // ── 미디어 세션(잠금화면·블루투스 버튼) ─────────────────────────────

    private fun initSession() {
        try {
            val ms = MediaSession(this, "MorningCast")
            ms.setCallback(object : MediaSession.Callback() {
                override fun onPlay() {
                    if (!isPlaying) toggle()
                }

                override fun onPause() {
                    if (isPlaying) toggle()
                }

                override fun onStop() = stopAll()
                override fun onSkipToNext() = nextSegment()
                override fun onSkipToPrevious() = seekBy(-15_000)
                override fun onFastForward() = seekBy(30_000)
                override fun onRewind() = seekBy(-15_000)
                override fun onSeekTo(pos: Long) = seekTo(pos.toInt())
            })
            ms.isActive = true
            session = ms
        } catch (e: Exception) {
            AppLog.error(this, "미디어 세션 생성 실패", e)
        }
    }

    private fun updateSession() {
        val ms = session ?: return
        try {
            val state = if (isPlaying) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED
            val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                PlaybackState.ACTION_STOP or PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or
                PlaybackState.ACTION_FAST_FORWARD or PlaybackState.ACTION_REWIND or PlaybackState.ACTION_SEEK_TO
            ms.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(actions)
                    .setState(state, positionMs, if (isPlaying) settings.playbackSpeed else 0f)
                    .build()
            )
            val ep = episode
            if (ep != null) {
                ms.setMetadata(
                    MediaMetadata.Builder()
                        .putString(MediaMetadata.METADATA_KEY_TITLE, ep.title)
                        .putString(MediaMetadata.METADATA_KEY_ARTIST, "모닝캐스트")
                        .putLong(MediaMetadata.METADATA_KEY_DURATION, durationMs)
                        .build()
                )
            }
        } catch (_: Exception) {
        }
    }

    // ── 알림 ───────────────────────────────────────────────────────

    private fun updateNotification() {
        try {
            getSystemService(NotificationManager::class.java)?.notify(Notifs.ID_PLAY, buildNotification())
        } catch (_: Exception) {
        }
    }

    private fun buildNotification(): Notification {
        val ep = episode
        val fb = fallbackMessage
        val channel = if (scheduled) Notifs.CH_ALARM else Notifs.CH_PLAYBACK
        val title = when {
            fb != null -> "오늘 모닝캐스트를 준비하지 못했어요"
            ep != null -> ep.title
            else -> "모닝캐스트"
        }
        val text = when {
            fb != null -> fb
            ep != null && prepared -> "${ep.segmentLabel(positionMs)} · ${fmtTime(positionMs)} / ${fmtTime(durationMs)}"
            else -> "재생 준비 중…"
        }
        val openPi = PendingIntent.getActivity(
            this, 1,
            Intent(this, PlayerActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = Notification.Builder(this, channel)
            .setSmallIcon(R.drawable.ic_stat_podcast)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openPi)
            .setOngoing(isPlaying || fb != null)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setCategory(if (scheduled) Notification.CATEGORY_ALARM else Notification.CATEGORY_TRANSPORT)
        if (fb == null) {
            b.addAction(action(R.drawable.ic_replay, "15초 뒤로", ACTION_BACK, 21))
            if (isPlaying) {
                b.addAction(action(R.drawable.ic_pause, "일시정지", ACTION_TOGGLE, 22))
            } else {
                b.addAction(action(R.drawable.ic_play, "재생", ACTION_TOGGLE, 22))
            }
            b.addAction(action(R.drawable.ic_skip, "다음 코너", ACTION_NEXT, 23))
            b.addAction(action(R.drawable.ic_stop, "정지", ACTION_STOP, 24))
            val style = Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2)
            val ms = session
            if (ms != null) style.setMediaSession(ms.sessionToken)
            b.setStyle(style)
        } else {
            b.addAction(action(R.drawable.ic_stop, "알람 끄기", ACTION_STOP, 24))
            b.setStyle(Notification.BigTextStyle().bigText(text))
        }
        if (scheduled && !fullScreenShown) {
            fullScreenShown = true
            b.setFullScreenIntent(openPi, true)
        }
        return b.build()
    }

    private fun action(icon: Int, title: String, act: String, rc: Int): Notification.Action {
        val pi = PendingIntent.getService(
            this, rc,
            Intent(this, PlaybackService::class.java).setAction(act),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Action.Builder(Icon.createWithResource(this, icon), title, pi).build()
    }
}
