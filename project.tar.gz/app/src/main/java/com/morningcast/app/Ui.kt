package com.morningcast.app

import android.content.Context
import android.os.Build
import android.view.View
import android.view.WindowInsets
import android.widget.Toast

object Ui {
    /** 안드로이드 15+ (화면 가장자리까지 그리기) 에서 상태바·내비게이션바·키보드에 가리지 않도록 여백 적용 */
    fun applyInsets(v: View) {
        if (Build.VERSION.SDK_INT < 35) return
        val l = v.paddingLeft
        val t = v.paddingTop
        val r = v.paddingRight
        val b = v.paddingBottom
        v.setOnApplyWindowInsetsListener { view, insets ->
            val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
            view.setPadding(l + bars.left, t + bars.top, r + bars.right, b + bars.bottom)
            WindowInsets.CONSUMED
        }
        v.requestApplyInsets()
    }

    fun toast(ctx: Context, msg: String) {
        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
    }
}
