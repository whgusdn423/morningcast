package com.morningcast.app

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** 16비트 모노 PCM 샘플 */
class Pcm(val samples: ShortArray, val sampleRate: Int)

/** 에피소드 전체를 24kHz 16비트 모노 PCM 파일로 이어 붙입니다. */
class PcmWriter(file: File, val sampleRate: Int = 24000) : Closeable {
    private val out = BufferedOutputStream(FileOutputStream(file), 1 shl 16)
    var bytes: Long = 0L
        private set
    val positionMs: Long get() = bytes * 1000L / (sampleRate * 2L)

    fun writeSamples(samples: ShortArray) {
        val buf = ByteArray(samples.size * 2)
        for (i in samples.indices) {
            val v = samples[i].toInt()
            buf[2 * i] = (v and 0xFF).toByte()
            buf[2 * i + 1] = ((v shr 8) and 0xFF).toByte()
        }
        out.write(buf)
        bytes += buf.size
    }

    fun appendPcm(pcm: Pcm) {
        val mono = if (pcm.sampleRate == sampleRate) pcm.samples else Resampler.linear(pcm.samples, pcm.sampleRate, sampleRate)
        writeSamples(mono)
    }

    fun writeSilence(ms: Int) {
        if (ms <= 0) return
        writeSamples(ShortArray(sampleRate * ms / 1000))
    }

    fun writeChime() = writeSamples(Chime.make(sampleRate))

    override fun close() {
        out.close()
    }
}

object Wav {
    private fun le16(b: ByteArray, o: Int): Int = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
    private fun le32(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or
            ((b[o + 2].toInt() and 0xFF) shl 16) or ((b[o + 3].toInt() and 0xFF) shl 24)

    fun isWav(b: ByteArray, offset: Int = 0): Boolean =
        b.size >= offset + 12 && b[offset] == 'R'.code.toByte() && b[offset + 1] == 'I'.code.toByte() &&
            b[offset + 2] == 'F'.code.toByte() && b[offset + 3] == 'F'.code.toByte()

    fun readFile(f: File): Pcm = parse(f.readBytes())

    /** WAV(PCM 8/16/24/32비트, float32, 모노/스테레오) → 16비트 모노 */
    fun parse(b: ByteArray): Pcm {
        if (!isWav(b) || String(b, 8, 4, Charsets.US_ASCII) != "WAVE") throw IOException("WAV 형식이 아닙니다")
        var pos = 12
        var fmt = 1
        var channels = 1
        var rate = 24000
        var bits = 16
        var dataOff = -1
        var dataLen = 0
        while (pos + 8 <= b.size) {
            val id = String(b, pos, 4, Charsets.US_ASCII)
            val size = le32(b, pos + 4)
            val body = pos + 8
            if (id == "fmt " && body + 16 <= b.size) {
                fmt = le16(b, body)
                channels = maxOf(1, le16(b, body + 2))
                rate = le32(b, body + 4)
                bits = le16(b, body + 14)
                if (fmt == 0xFFFE && size >= 26 && body + 26 <= b.size) fmt = le16(b, body + 24)
            } else if (id == "data") {
                dataOff = body
                dataLen = if (size <= 0 || body.toLong() + size > b.size) b.size - body else size
                break
            }
            if (size < 0) break
            pos = body + size + (size and 1)
        }
        if (dataOff < 0) throw IOException("WAV data 청크가 없습니다")
        if (rate <= 0) rate = 24000
        val bytesPerSample = bits / 8
        if (bytesPerSample <= 0) throw IOException("지원하지 않는 WAV 비트 수: $bits")
        val frameSize = bytesPerSample * channels
        val frames = dataLen / frameSize
        val out = ShortArray(frames)
        for (f in 0 until frames) {
            var acc = 0.0
            for (c in 0 until channels) {
                val o = dataOff + f * frameSize + c * bytesPerSample
                val v: Double = when {
                    fmt == 3 && bits == 32 -> java.lang.Float.intBitsToFloat(le32(b, o)).toDouble() * 32767.0
                    bits == 16 -> le16(b, o).toShort().toDouble()
                    bits == 8 -> ((b[o].toInt() and 0xFF) - 128) * 256.0
                    bits == 24 -> le16(b, o + 1).toShort().toDouble()
                    bits == 32 -> le16(b, o + 2).toShort().toDouble()
                    else -> throw IOException("지원하지 않는 WAV 형식: fmt=$fmt bits=$bits")
                }
                acc += v
            }
            out[f] = (acc / channels).roundToInt().coerceIn(-32768, 32767).toShort()
        }
        return Pcm(out, rate)
    }

    /** 헤더 없는 16비트 리틀엔디언 PCM */
    fun rawL16(b: ByteArray, offset: Int, len: Int, rate: Int): Pcm {
        val n = len / 2
        val out = ShortArray(n)
        for (i in 0 until n) out[i] = le16(b, offset + 2 * i).toShort()
        return Pcm(out, rate)
    }

    fun header(dataLen: Long, sampleRate: Int, channels: Int = 1, bits: Int = 16): ByteArray {
        val h = ByteArray(44)
        fun put32(o: Int, v: Long) {
            h[o] = (v and 0xFF).toByte(); h[o + 1] = ((v shr 8) and 0xFF).toByte()
            h[o + 2] = ((v shr 16) and 0xFF).toByte(); h[o + 3] = ((v shr 24) and 0xFF).toByte()
        }
        fun put16(o: Int, v: Int) {
            h[o] = (v and 0xFF).toByte(); h[o + 1] = ((v shr 8) and 0xFF).toByte()
        }
        "RIFF".toByteArray(Charsets.US_ASCII).copyInto(h, 0)
        put32(4, 36 + dataLen)
        "WAVE".toByteArray(Charsets.US_ASCII).copyInto(h, 8)
        "fmt ".toByteArray(Charsets.US_ASCII).copyInto(h, 12)
        put32(16, 16)
        put16(20, 1)
        put16(22, channels)
        put32(24, sampleRate.toLong())
        put32(28, sampleRate.toLong() * channels * bits / 8)
        put16(32, channels * bits / 8)
        put16(34, bits)
        "data".toByteArray(Charsets.US_ASCII).copyInto(h, 36)
        put32(40, dataLen)
        return h
    }

    fun toWavBytes(p: Pcm): ByteArray {
        val data = ByteArray(p.samples.size * 2)
        for (i in p.samples.indices) {
            val v = p.samples[i].toInt()
            data[2 * i] = (v and 0xFF).toByte()
            data[2 * i + 1] = ((v shr 8) and 0xFF).toByte()
        }
        return header(data.size.toLong(), p.sampleRate) + data
    }

    fun writeWavFromPcmFile(pcmFile: File, out: File, sampleRate: Int) {
        val len = pcmFile.length()
        BufferedOutputStream(FileOutputStream(out), 1 shl 16).use { o ->
            o.write(header(len, sampleRate))
            FileInputStream(pcmFile).use { i -> i.copyTo(o, 1 shl 16) }
        }
    }
}

object Resampler {
    /** 선형 보간 리샘플링 (음성용으로 충분) */
    fun linear(src: ShortArray, from: Int, to: Int): ShortArray {
        if (from == to || src.isEmpty()) return src
        val outLen = (src.size.toLong() * to / from).toInt()
        val out = ShortArray(outLen)
        val step = from.toDouble() / to
        val last = src.size - 1
        for (i in 0 until outLen) {
            val p = i * step
            val i0 = min(p.toInt(), last)
            val i1 = min(i0 + 1, last)
            val frac = p - i0
            out[i] = (src[i0] + (src[i1] - src[i0]) * frac).roundToInt().coerceIn(-32768, 32767).toShort()
        }
        return out
    }
}

/** 코너 사이에 넣는 짧은 '딩-동' 효과음 (직접 합성) */
object Chime {
    fun make(rate: Int): ShortArray {
        val pre = (rate * 0.35).toInt()
        val notes = listOf(Pair(880.0, 0.22), Pair(1318.5, 0.42))
        val gap = (rate * 0.04).toInt()
        val post = (rate * 0.45).toInt()
        var total = pre + post
        for (n in notes) total += (rate * n.second).toInt() + gap
        val out = ShortArray(total)
        var pos = pre
        for (n in notes) {
            val len = (rate * n.second).toInt()
            for (i in 0 until len) {
                val t = i.toDouble() / rate
                val attack = min(1.0, t / 0.008)
                val env = attack * exp(-t * 6.0)
                val v = sin(2 * PI * n.first * t) * 0.6 + sin(2 * PI * n.first * 2 * t) * 0.15
                out[pos + i] = (v * env * 0.28 * 32767).roundToInt().coerceIn(-32768, 32767).toShort()
            }
            pos += len + gap
        }
        return out
    }
}

/** PCM → AAC(.m4a) 인코딩 (안드로이드 내장 MediaCodec 사용) */
object AacEncoder {
    fun encode(pcmFile: File, sampleRate: Int, outFile: File, bitRate: Int = 64000) {
        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, 1)
        format.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        format.setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
        format.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            val mux = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mux
            BufferedInputStream(FileInputStream(pcmFile), 1 shl 16).use { input ->
                val info = MediaCodec.BufferInfo()
                val tmp = ByteArray(16384)
                var track = -1
                var inputDone = false
                var outputDone = false
                var totalRead = 0L
                val bytesPerSec = sampleRate * 2L
                var idleSince = 0L
                while (!outputDone) {
                    if (!inputDone) {
                        val inIdx = codec.dequeueInputBuffer(10_000)
                        if (inIdx >= 0) {
                            val buf = codec.getInputBuffer(inIdx) ?: throw IOException("입력 버퍼 없음")
                            buf.clear()
                            val want = (min(buf.remaining(), tmp.size) / 2) * 2
                            val n = readUpTo(input, tmp, want)
                            val pts = totalRead * 1_000_000L / bytesPerSec
                            if (n <= 0) {
                                codec.queueInputBuffer(inIdx, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                val even = (n / 2) * 2
                                buf.put(tmp, 0, even)
                                codec.queueInputBuffer(inIdx, 0, even, pts, 0)
                                totalRead += even
                            }
                        }
                    }
                    val outIdx = codec.dequeueOutputBuffer(info, 10_000)
                    if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        track = mux.addTrack(codec.outputFormat)
                        mux.start()
                        muxerStarted = true
                        idleSince = 0L
                    } else if (outIdx >= 0) {
                        idleSince = 0L
                        val ob = codec.getOutputBuffer(outIdx)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                        if (info.size > 0 && muxerStarted && ob != null) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            mux.writeSampleData(track, ob, info)
                        }
                        codec.releaseOutputBuffer(outIdx, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                    } else if (inputDone) {
                        val now = System.currentTimeMillis()
                        if (idleSince == 0L) idleSince = now
                        if (now - idleSince > 8000) throw IOException("인코더가 응답하지 않습니다")
                    }
                }
            }
        } finally {
            try {
                codec.stop()
            } catch (_: Exception) {
            }
            try {
                codec.release()
            } catch (_: Exception) {
            }
            try {
                if (muxerStarted) muxer?.stop()
            } catch (_: Exception) {
            }
            try {
                muxer?.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun readUpTo(input: InputStream, buf: ByteArray, want: Int): Int {
        var total = 0
        while (total < want) {
            val n = input.read(buf, total, want - total)
            if (n < 0) break
            total += n
        }
        return if (total == 0 && want > 0) -1 else total
    }

    fun durationMs(f: File): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(f.absolutePath)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            try {
                r.release()
            } catch (_: Exception) {
            }
        }
    }
}

object AudioFinalizer {
    /** PCM 을 m4a 로 저장(실패하면 wav). 반환: 파일 이름 */
    fun finalize(pcmFile: File, dir: File, sampleRate: Int, expectedMs: Long, log: (String) -> Unit): String {
        val m4a = File(dir, "audio.m4a")
        try {
            AacEncoder.encode(pcmFile, sampleRate, m4a)
            val d = AacEncoder.durationMs(m4a)
            if (d < expectedMs * 0.8) throw IOException("인코딩 길이 이상 (${d}ms / 예상 ${expectedMs}ms)")
            return m4a.name
        } catch (e: Exception) {
            log("AAC 인코딩 실패 → WAV 로 저장합니다: ${e.message}")
            m4a.delete()
            val wav = File(dir, "audio.wav")
            Wav.writeWavFromPcmFile(pcmFile, wav, sampleRate)
            return wav.name
        }
    }
}
