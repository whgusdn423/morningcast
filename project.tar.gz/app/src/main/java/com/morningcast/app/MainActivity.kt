package com.morningcast.app

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import org.json.JSONObject
import java.io.File
import java.util.Locale
import android.provider.Settings as SysSettings

/** 설정·상태 화면 */
class MainActivity : Activity() {

    private class SegViews(val key: String, val cb: CheckBox, val min: EditText, val inst: EditText, val src: EditText)

    private lateinit var s: Settings
    private val handler = Handler(Looper.getMainLooper())

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var voicesLoaded = false
    private var currentEnginePref = ""
    private var engineNames: List<String> = listOf("")
    private var voiceNames: List<String> = listOf("")
    private var previewPlayer: MediaPlayer? = null
    private var wasGenerating = false

    private var wakeH = 6
    private var wakeM = 30
    private var genH = 21
    private var genM = 0

    private val rateValues = listOf(0.8f, 0.9f, 1.0f, 1.1f, 1.2f, 1.3f)
    private val speedValues = listOf(0.8f, 0.9f, 1.0f, 1.1f, 1.2f, 1.3f, 1.5f)

    private lateinit var tvStatus: TextView
    private lateinit var tvProgress: TextView
    private lateinit var tvTotal: TextView
    private lateinit var tvPerms: TextView
    private lateinit var tvVersion: TextView
    private lateinit var btnGenerate: Button
    private lateinit var btnWakeTime: Button
    private lateinit var btnGenTime: Button
    private lateinit var swEnabled: Switch
    private lateinit var dayChecks: List<CheckBox>
    private lateinit var segViews: List<SegViews>
    private lateinit var cbPapers: CheckBox
    private lateinit var etIssns: EditText
    private lateinit var etListener: EditText
    private lateinit var rbDuo: RadioButton
    private lateinit var rbSolo: RadioButton
    private lateinit var etHost1: EditText
    private lateinit var etHost2: EditText
    private lateinit var rbGemini: RadioButton
    private lateinit var rbClaude: RadioButton
    private lateinit var layoutGemini: LinearLayout
    private lateinit var layoutClaude: LinearLayout
    private lateinit var etGeminiKey: EditText
    private lateinit var etGeminiModel: EditText
    private lateinit var etClaudeKey: EditText
    private lateinit var etClaudeModel: EditText
    private lateinit var cbWebSearch: CheckBox
    private lateinit var rbAndroidTts: RadioButton
    private lateinit var rbGeminiTts: RadioButton
    private lateinit var layoutAndroidTts: LinearLayout
    private lateinit var layoutGeminiTts: LinearLayout
    private lateinit var spEngine: Spinner
    private lateinit var spVoice1: Spinner
    private lateinit var spVoice2: Spinner
    private lateinit var spRate: Spinner
    private lateinit var etTtsModel: EditText
    private lateinit var spGVoice1: Spinner
    private lateinit var spGVoice2: Spinner
    private lateinit var cbAlarmStream: CheckBox
    private lateinit var cbFadeIn: CheckBox
    private lateinit var spSpeed: Spinner
    private lateinit var etKeep: EditText
    private lateinit var btnPermNotif: Button
    private lateinit var btnPermBattery: Button
    private lateinit var btnPermExact: Button
    private lateinit var btnPermFull: Button

    private val poller = object : Runnable {
        override fun run() {
            refreshProgress()
            handler.postDelayed(this, 1500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Ui.applyInsets(findViewById(R.id.root))
        Notifs.ensureChannels(this)
        s = Settings.load(this)
        bindViews()
        fillFromSettings(s)
        setupListeners()
        initTts(s.androidEngine)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        Scheduler.rescheduleAll(this)
        try {
            tvVersion.text = "버전 " + (packageManager.getPackageInfo(packageName, 0).versionName ?: "")
        } catch (_: Exception) {
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshPerms()
        handler.removeCallbacks(poller)
        handler.post(poller)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(poller)
        autoSaveIfChanged()
    }

    override fun onDestroy() {
        try {
            tts?.shutdown()
        } catch (_: Exception) {
        }
        try {
            previewPlayer?.release()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshPerms()
    }

    // ── 화면 연결 ───────────────────────────────────────────────────────

    private fun bindViews() {
        tvStatus = findViewById(R.id.tvStatus)
        tvProgress = findViewById(R.id.tvProgress)
        tvTotal = findViewById(R.id.tvTotal)
        tvPerms = findViewById(R.id.tvPerms)
        tvVersion = findViewById(R.id.tvVersion)
        btnGenerate = findViewById(R.id.btnGenerate)
        btnWakeTime = findViewById(R.id.btnWakeTime)
        btnGenTime = findViewById(R.id.btnGenTime)
        swEnabled = findViewById(R.id.swEnabled)
        dayChecks = listOf(
            findViewById(R.id.cbDay0), findViewById(R.id.cbDay1), findViewById(R.id.cbDay2),
            findViewById(R.id.cbDay3), findViewById(R.id.cbDay4), findViewById(R.id.cbDay5),
            findViewById(R.id.cbDay6)
        )
        segViews = listOf(
            SegViews("economy", findViewById(R.id.cbEco), findViewById(R.id.etEcoMin), findViewById(R.id.etEcoInst), findViewById(R.id.etEcoSrc)),
            SegViews("education", findViewById(R.id.cbEdu), findViewById(R.id.etEduMin), findViewById(R.id.etEduInst), findViewById(R.id.etEduSrc)),
            SegViews("world", findViewById(R.id.cbWorld), findViewById(R.id.etWorldMin), findViewById(R.id.etWorldInst), findViewById(R.id.etWorldSrc))
        )
        cbPapers = findViewById(R.id.cbPapers)
        etIssns = findViewById(R.id.etIssns)
        etListener = findViewById(R.id.etListener)
        rbDuo = findViewById(R.id.rbDuo)
        rbSolo = findViewById(R.id.rbSolo)
        etHost1 = findViewById(R.id.etHost1)
        etHost2 = findViewById(R.id.etHost2)
        rbGemini = findViewById(R.id.rbGemini)
        rbClaude = findViewById(R.id.rbClaude)
        layoutGemini = findViewById(R.id.layoutGemini)
        layoutClaude = findViewById(R.id.layoutClaude)
        etGeminiKey = findViewById(R.id.etGeminiKey)
        etGeminiModel = findViewById(R.id.etGeminiModel)
        etClaudeKey = findViewById(R.id.etClaudeKey)
        etClaudeModel = findViewById(R.id.etClaudeModel)
        cbWebSearch = findViewById(R.id.cbWebSearch)
        rbAndroidTts = findViewById(R.id.rbAndroidTts)
        rbGeminiTts = findViewById(R.id.rbGeminiTts)
        layoutAndroidTts = findViewById(R.id.layoutAndroidTts)
        layoutGeminiTts = findViewById(R.id.layoutGeminiTts)
        spEngine = findViewById(R.id.spEngine)
        spVoice1 = findViewById(R.id.spVoice1)
        spVoice2 = findViewById(R.id.spVoice2)
        spRate = findViewById(R.id.spRate)
        etTtsModel = findViewById(R.id.etTtsModel)
        spGVoice1 = findViewById(R.id.spGVoice1)
        spGVoice2 = findViewById(R.id.spGVoice2)
        cbAlarmStream = findViewById(R.id.cbAlarmStream)
        cbFadeIn = findViewById(R.id.cbFadeIn)
        spSpeed = findViewById(R.id.spSpeed)
        etKeep = findViewById(R.id.etKeep)
        btnPermNotif = findViewById(R.id.btnPermNotif)
        btnPermBattery = findViewById(R.id.btnPermBattery)
        btnPermExact = findViewById(R.id.btnPermExact)
        btnPermFull = findViewById(R.id.btnPermFull)
    }

    private fun fillFromSettings(st: Settings) {
        swEnabled.isChecked = st.enabled
        wakeH = st.wakeHour; wakeM = st.wakeMinute; genH = st.genHour; genM = st.genMinute
        updateTimeButtons()
        for (i in 0..6) dayChecks[i].isChecked = ((st.days shr i) and 1) == 1
        for (sv in segViews) {
            val seg = st.segment(sv.key) ?: continue
            sv.cb.isChecked = seg.enabled
            sv.min.setText(seg.minutes.toString())
            sv.inst.setText(seg.instruction)
            sv.src.setText(seg.sources)
        }
        cbPapers.isChecked = st.includePapers
        etIssns.setText(st.journalIssns)
        etListener.setText(st.listener)
        if (st.style == "solo") rbSolo.isChecked = true else rbDuo.isChecked = true
        etHost1.setText(st.host1)
        etHost2.setText(st.host2)
        if (st.scriptProvider == "claude") rbClaude.isChecked = true else rbGemini.isChecked = true
        etGeminiKey.setText(st.geminiKey)
        etGeminiModel.setText(st.geminiModel)
        etClaudeKey.setText(st.claudeKey)
        etClaudeModel.setText(st.claudeModel)
        cbWebSearch.isChecked = st.useWebSearch
        if (st.ttsProvider == "gemini") rbGeminiTts.isChecked = true else rbAndroidTts.isChecked = true
        setSpinner(spRate, rateValues.map { "${it}배" }, nearestIndex(rateValues, st.speechRate))
        etTtsModel.setText(st.geminiTtsModel)
        val gLabels = GeminiTtsSynth.VOICES.map { "${it.first} — ${it.second}" }
        setSpinner(spGVoice1, gLabels, GeminiTtsSynth.VOICES.indexOfFirst { it.first == st.geminiVoice1 })
        setSpinner(spGVoice2, gLabels, GeminiTtsSynth.VOICES.indexOfFirst { it.first == st.geminiVoice2 })
        cbAlarmStream.isChecked = st.useAlarmStream
        cbFadeIn.isChecked = st.fadeIn
        setSpinner(spSpeed, speedValues.map { "${it}배속" }, nearestIndex(speedValues, st.playbackSpeed))
        etKeep.setText(st.keepEpisodes.toString())
        if (!voicesLoaded) {
            setSpinner(spEngine, listOf("불러오는 중…"), 0)
            setSpinner(spVoice1, listOf("불러오는 중…"), 0)
            setSpinner(spVoice2, listOf("불러오는 중…"), 0)
        }
        updateProviderVisibility()
        updateTtsVisibility()
        updateTotal()
    }

    private fun setupListeners() {
        findViewById<Button>(R.id.btnSave).setOnClickListener { saveSettings(true) }
        btnGenerate.setOnClickListener { generateNow() }
        findViewById<Button>(R.id.btnPlayLatest).setOnClickListener {
            if (EpisodeStore.latest(this) == null) {
                Ui.toast(this, "아직 만든 에피소드가 없습니다. 먼저 '지금 만들기'를 눌러 주세요.")
            } else {
                PlaybackService.playEpisode(this, null)
                startActivity(Intent(this, PlayerActivity::class.java))
            }
        }
        findViewById<Button>(R.id.btnEpisodes).setOnClickListener {
            startActivity(Intent(this, EpisodesActivity::class.java))
        }
        findViewById<Button>(R.id.btnPlayer).setOnClickListener {
            startActivity(Intent(this, PlayerActivity::class.java))
        }
        findViewById<Button>(R.id.btnTestAlarm).setOnClickListener {
            saveSettings(false)
            val at = Scheduler.scheduleTestPlayback(this, 60_000L)
            val extra = if (EpisodeStore.latest(this) == null) "\n(에피소드가 없어서 기본 알람음이 울립니다)" else ""
            alert("알람 시험", "${Scheduler.fmt(at)}에 알람이 울립니다. 화면을 끄고 기다려 보세요.$extra")
        }
        btnWakeTime.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                wakeH = h; wakeM = m; updateTimeButtons()
            }, wakeH, wakeM, true).show()
        }
        btnGenTime.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                genH = h; genM = m; updateTimeButtons()
            }, genH, genM, true).show()
        }
        findViewById<RadioGroup>(R.id.rgProvider).setOnCheckedChangeListener { _, _ -> updateProviderVisibility() }
        findViewById<RadioGroup>(R.id.rgTts).setOnCheckedChangeListener { _, _ -> updateTtsVisibility() }
        findViewById<Button>(R.id.btnGeminiModels).setOnClickListener { listModels("gemini-text") }
        findViewById<Button>(R.id.btnTtsModels).setOnClickListener { listModels("gemini-tts") }
        findViewById<Button>(R.id.btnClaudeModels).setOnClickListener { listModels("claude") }
        findViewById<Button>(R.id.btnTestAi).setOnClickListener { testAi() }
        findViewById<Button>(R.id.btnTestTts).setOnClickListener { testGeminiTts() }
        findViewById<Button>(R.id.btnPreview1).setOnClickListener { preview(1) }
        findViewById<Button>(R.id.btnPreview2).setOnClickListener { preview(2) }
        findViewById<Button>(R.id.btnResetSegments).setOnClickListener { resetSegments() }
        findViewById<Button>(R.id.btnLog).setOnClickListener { TextViewerActivity.openLog(this) }
        spEngine.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!voicesLoaded) return
                val sel = engineNames.getOrElse(position) { "" }
                if (sel != currentEnginePref) {
                    voicesLoaded = false
                    initTts(sel)
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(e: Editable?) = updateTotal()
        }
        for (sv in segViews) {
            sv.min.addTextChangedListener(watcher)
            sv.cb.setOnCheckedChangeListener { _, _ -> updateTotal() }
        }
        btnPermNotif.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            } else {
                openSettings(Intent(SysSettings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(SysSettings.EXTRA_APP_PACKAGE, packageName))
            }
        }
        btnPermBattery.setOnClickListener {
            try {
                startActivity(Intent(SysSettings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                openSettings(Intent(SysSettings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        btnPermExact.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 31) {
                openSettings(Intent(SysSettings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            } else {
                Ui.toast(this, "이 휴대폰은 따로 허용할 필요가 없습니다.")
            }
        }
        btnPermFull.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 34) {
                openSettings(Intent(SysSettings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
            } else {
                Ui.toast(this, "이 휴대폰은 따로 허용할 필요가 없습니다.")
            }
        }
    }

    // ── 설정 읽기/저장 ─────────────────────────────────────────────────

    private fun readUi(): Settings {
        val base = Settings.load(this)
        val n = Settings.fromJson(base.toJson())
        n.enabled = swEnabled.isChecked
        n.wakeHour = wakeH; n.wakeMinute = wakeM; n.genHour = genH; n.genMinute = genM
        var days = 0
        for (i in 0..6) if (dayChecks[i].isChecked) days = days or (1 shl i)
        n.days = days
        for (sv in segViews) {
            val seg = n.segment(sv.key) ?: continue
            seg.enabled = sv.cb.isChecked
            seg.minutes = sv.min.text.toString().trim().toIntOrNull()?.coerceIn(1, 40) ?: seg.minutes
            seg.instruction = sv.inst.text.toString().trim()
            seg.sources = sv.src.text.toString().trim()
        }
        n.includePapers = cbPapers.isChecked
        n.journalIssns = etIssns.text.toString().trim()
        n.listener = etListener.text.toString().trim()
        n.style = if (rbSolo.isChecked) "solo" else "duo"
        n.host1 = etHost1.text.toString().trim().ifEmpty { "지수" }
        n.host2 = etHost2.text.toString().trim().ifEmpty { "민호" }
        if (n.host1 == n.host2) n.host2 = n.host2 + "2"
        n.scriptProvider = if (rbClaude.isChecked) "claude" else "gemini"
        n.geminiKey = etGeminiKey.text.toString().trim()
        n.geminiModel = etGeminiModel.text.toString().trim().ifEmpty { Settings.DEFAULT_GEMINI_MODEL }
        n.claudeKey = etClaudeKey.text.toString().trim()
        n.claudeModel = etClaudeModel.text.toString().trim().ifEmpty { Settings.DEFAULT_CLAUDE_MODEL }
        n.useWebSearch = cbWebSearch.isChecked
        n.ttsProvider = if (rbGeminiTts.isChecked) "gemini" else "android"
        if (voicesLoaded) {
            n.androidEngine = engineNames.getOrElse(spEngine.selectedItemPosition) { "" }
            n.androidVoice1 = voiceNames.getOrElse(spVoice1.selectedItemPosition) { "" }
            n.androidVoice2 = voiceNames.getOrElse(spVoice2.selectedItemPosition) { "" }
        }
        n.speechRate = rateValues.getOrElse(spRate.selectedItemPosition) { 1.0f }
        n.geminiTtsModel = etTtsModel.text.toString().trim().ifEmpty { Settings.DEFAULT_GEMINI_TTS_MODEL }
        n.geminiVoice1 = GeminiTtsSynth.VOICES.getOrElse(spGVoice1.selectedItemPosition) { GeminiTtsSynth.VOICES[0] }.first
        n.geminiVoice2 = GeminiTtsSynth.VOICES.getOrElse(spGVoice2.selectedItemPosition) { GeminiTtsSynth.VOICES[1] }.first
        n.useAlarmStream = cbAlarmStream.isChecked
        n.fadeIn = cbFadeIn.isChecked
        n.playbackSpeed = speedValues.getOrElse(spSpeed.selectedItemPosition) { 1.0f }
        n.keepEpisodes = etKeep.text.toString().trim().toIntOrNull()?.coerceIn(1, 60) ?: 5
        return n
    }

    private fun saveSettings(showMessage: Boolean) {
        val n = readUi()
        Settings.save(this, n)
        s = n
        AppState(this).attempts = 0
        Scheduler.rescheduleAll(this)
        refreshStatus()
        if (showMessage) {
            val warn = StringBuilder()
            if (n.enabled && n.days == 0) warn.append("\n· 요일이 하나도 선택되지 않았습니다.")
            val key = if (n.scriptProvider == "claude") n.claudeKey else n.geminiKey
            if (key.isBlank()) warn.append("\n· AI API 키가 비어 있어 자동 생성이 되지 않습니다.")
            if (n.totalMinutes() > 45) warn.append("\n· 전체 분량이 길어 생성 시간이 오래 걸리고 한도에 걸릴 수 있습니다.")
            val next = AppState(this).nextPlayAt
            val msg = (if (next > 0) "다음 재생: ${Scheduler.fmt(next)}" else "예약된 재생이 없습니다.") + warn
            alert("저장했습니다", msg)
        }
    }

    private fun autoSaveIfChanged() {
        try {
            val n = readUi()
            if (n.toJson().toString() != Settings.load(this).toJson().toString()) {
                saveSettings(false)
                Ui.toast(this, "변경 내용을 자동 저장했습니다")
            }
        } catch (e: Exception) {
            AppLog.error(this, "자동 저장 실패", e)
        }
    }

    private fun resetSegments() {
        AlertDialog.Builder(this)
            .setMessage("세 코너의 지침·뉴스 출처·학술지 목록을 처음 값으로 되돌릴까요?")
            .setPositiveButton("되돌리기") { _, _ ->
                val d = Settings.defaultSegments()
                for (sv in segViews) {
                    val seg = d.firstOrNull { it.key == sv.key } ?: continue
                    sv.inst.setText(seg.instruction)
                    sv.src.setText(seg.sources)
                }
                etIssns.setText(Settings.DEFAULT_ISSNS)
            }
            .setNegativeButton("취소", null)
            .show()
    }

    // ── 상태 표시 ─────────────────────────────────────────────────────

    private fun refreshStatus() {
        val st = AppState(this)
        val cur = Settings.load(this)
        val sb = StringBuilder()
        if (!cur.enabled) {
            sb.append("자동 재생: 꺼짐\n")
        } else {
            sb.append("다음 재생: ").append(Scheduler.fmt(st.nextPlayAt)).append('\n')
            val gen = when {
                st.nextGenAt > 0 -> Scheduler.fmt(st.nextGenAt)
                st.nextPlayAt > 0 && EpisodeStore.hasFreshEpisodeFor(this, st.nextPlayAt, Scheduler.generationTimeFor(cur, st.nextPlayAt)) -> "이미 준비됨"
                else -> "예약 없음"
            }
            sb.append("다음 생성: ").append(gen).append('\n')
        }
        if (st.lastGenAt > 0) {
            sb.append("최근 생성: ").append(Scheduler.fmt(st.lastGenAt)).append(if (st.lastGenOk) " ✅ " else " ⚠️ ")
                .append(st.lastGenMsg).append('\n')
        }
        if (st.lastPlayMsg.isNotEmpty()) sb.append("최근 재생: ").append(st.lastPlayMsg).append('\n')
        val eps = EpisodeStore.list(this)
        sb.append("보관 중인 에피소드: ").append(eps.size).append("개")
        tvStatus.text = sb.toString()
        refreshProgress()
    }

    private fun refreshProgress() {
        val running = GenerationService.isRunning
        if (running) {
            tvProgress.visibility = View.VISIBLE
            tvProgress.text = "⏳ 만드는 중: ${GenerationService.progress.ifEmpty { "준비 중" }}"
            btnGenerate.isEnabled = false
        } else {
            tvProgress.visibility = View.GONE
            btnGenerate.isEnabled = true
        }
        if (wasGenerating && !running) refreshStatus()
        wasGenerating = running
    }

    private fun refreshPerms() {
        val nm = getSystemService(NotificationManager::class.java)
        val notifOk = nm?.areNotificationsEnabled() ?: true
        val am = getSystemService(AlarmManager::class.java)
        val exactOk = am == null || Scheduler.canExact(am)
        val pm = getSystemService(PowerManager::class.java)
        val batteryOk = pm?.isIgnoringBatteryOptimizations(packageName) ?: false
        val fullOk = if (Build.VERSION.SDK_INT >= 34) (nm?.canUseFullScreenIntent() ?: true) else true
        tvPerms.text = "알림: ${mark(notifOk)}\n정확한 알람: ${mark(exactOk)}\n" +
            "배터리 최적화 제외: ${mark(batteryOk)}\n전체 화면 알림(잠금화면에 재생 화면): ${mark(fullOk)}"
        btnPermNotif.visibility = if (notifOk) View.GONE else View.VISIBLE
        btnPermExact.visibility = if (exactOk) View.GONE else View.VISIBLE
        btnPermBattery.visibility = if (batteryOk) View.GONE else View.VISIBLE
        btnPermFull.visibility = if (fullOk) View.GONE else View.VISIBLE
    }

    private fun mark(ok: Boolean) = if (ok) "✅ 허용됨" else "❌ 필요"

    private fun updateTimeButtons() {
        btnWakeTime.text = String.format("%02d:%02d", wakeH, wakeM)
        btnGenTime.text = String.format("%02d:%02d", genH, genM)
    }

    private fun updateTotal() {
        var total = 0
        for (sv in segViews) if (sv.cb.isChecked) total += sv.min.text.toString().trim().toIntOrNull() ?: 0
        tvTotal.text = "켜진 코너 합계: 약 ${total}분 (분량은 대략적이며 AI에 따라 ±20% 달라질 수 있어요)"
    }

    private fun updateProviderVisibility() {
        val claude = rbClaude.isChecked
        layoutClaude.visibility = if (claude) View.VISIBLE else View.GONE
        layoutGemini.visibility = if (claude && !rbGeminiTts.isChecked) View.GONE else View.VISIBLE
    }

    private fun updateTtsVisibility() {
        val g = rbGeminiTts.isChecked
        layoutGeminiTts.visibility = if (g) View.VISIBLE else View.GONE
        layoutAndroidTts.visibility = if (g) View.GONE else View.VISIBLE
        updateProviderVisibility()
    }

    // ── 휴대폰 음성(TTS) 목록 ─────────────────────────────────────────

    private fun initTts(enginePref: String) {
        try {
            tts?.shutdown()
        } catch (_: Exception) {
        }
        ttsReady = false
        val engine = TtsHelper.pickEngine(this, enginePref)
        val listener = TextToSpeech.OnInitListener { status -> runOnUiThread { onTtsInit(status, enginePref) } }
        tts = try {
            if (engine != null) TextToSpeech(this, listener, engine) else TextToSpeech(this, listener)
        } catch (e: Exception) {
            null
        }
    }

    private fun onTtsInit(status: Int, enginePref: String) {
        val t = tts ?: return
        currentEnginePref = enginePref
        if (status != TextToSpeech.SUCCESS) {
            setSpinner(spEngine, listOf("엔진을 불러오지 못함"), 0)
            Ui.toast(this, "휴대폰 음성 엔진을 불러오지 못했습니다.")
            return
        }
        ttsReady = true
        try {
            t.setLanguage(Locale.KOREAN)
        } catch (_: Exception) {
        }
        val engines = try {
            t.engines
        } catch (e: Exception) {
            emptyList()
        }
        engineNames = listOf("") + engines.map { it.name }
        setSpinner(
            spEngine, listOf("자동 (Google 우선)") + engines.map { "${it.label} (${it.name})" },
            engineNames.indexOf(enginePref).coerceAtLeast(0)
        )
        val voices = TtsHelper.koreanVoices(t)
        voiceNames = listOf("") + voices.map { it.name }
        val labels = voices.map { TtsHelper.voiceLabel(it) }
        val saved = Settings.load(this)
        setSpinner(spVoice1, listOf("기본 목소리") + labels, voiceNames.indexOf(saved.androidVoice1).coerceAtLeast(0))
        setSpinner(spVoice2, listOf("자동 선택 (다른 목소리)") + labels, voiceNames.indexOf(saved.androidVoice2).coerceAtLeast(0))
        voicesLoaded = true
        if (voices.isEmpty()) Ui.toast(this, "한국어 음성이 없습니다. 휴대폰 설정에서 한국어 음성 데이터를 받아 주세요.")
    }

    private fun preview(which: Int) {
        val t = tts
        if (t == null || !ttsReady || !voicesLoaded) {
            Ui.toast(this, "음성 엔진을 준비하는 중입니다.")
            return
        }
        val voices = TtsHelper.koreanVoices(t)
        val n1 = voiceNames.getOrElse(spVoice1.selectedItemPosition) { "" }
        val n2 = voiceNames.getOrElse(spVoice2.selectedItemPosition) { "" }
        val v1 = voices.firstOrNull { it.name == n1 } ?: t.defaultVoice
        val v = if (which == 1) v1 else voices.firstOrNull { it.name == n2 } ?: voices.firstOrNull { it.name != v1?.name }
        try {
            t.setLanguage(Locale.KOREAN)
            if (v != null) t.setVoice(v)
            t.setPitch(if (which == 2 && v == null) 0.82f else 1.0f)
            t.setSpeechRate(rateValues.getOrElse(spRate.selectedItemPosition) { 1.0f })
            val host = if (which == 1) etHost1.text.toString() else etHost2.text.toString()
            val text = if (which == 1) {
                "좋은 아침입니다. 저는 ${host}입니다. 오늘의 경제 소식부터 전해 드릴게요."
            } else {
                "저는 ${host}입니다. 어려운 내용은 쉽게 풀어서 설명해 드리겠습니다."
            }
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "preview")
        } catch (e: Exception) {
            Ui.toast(this, "미리 듣기 실패: ${e.message}")
        }
    }

    // ── AI 시험·모델 목록 ─────────────────────────────────────────────

    private fun generateNow() {
        saveSettings(false)
        val n = Settings.load(this)
        val key = if (n.scriptProvider == "claude") n.claudeKey else n.geminiKey
        if (key.isBlank()) {
            alert("API 키가 필요합니다", "AI 연결 칸에 API 키를 넣고 다시 눌러 주세요. 키 만드는 방법은 사용 설명서를 참고하세요.")
            return
        }
        if (GenerationService.isRunning) {
            Ui.toast(this, "이미 만드는 중입니다.")
            return
        }
        GenerationService.start(this, true)
        alert(
            "만들기 시작",
            "약 5~15분 걸립니다. 다른 앱을 써도 되고 화면을 꺼도 됩니다.\n진행 상황은 이 화면 위쪽과 알림에서 볼 수 있어요.\n" +
                "완성되면 '최근 것 듣기'로 바로 들을 수 있습니다."
        )
        refreshProgress()
    }

    private fun testAi() {
        val n = readUi()
        val dialog = waitDialog("AI에 연결해 보는 중… (보통 10~30초)")
        Thread {
            val sb = StringBuilder()
            try {
                val client = Llm.create(this, n, quick = true)
                val r = client.generate(
                    "당신은 친절한 한국어 아침 라디오 진행자입니다.",
                    "청취자에게 한국어로 짧은 아침 인사를 한 문장으로 해 주세요.",
                    false
                )
                sb.append("✅ ").append(client.label).append(" 연결 성공\n\n").append(r.text.trim().take(300))
                if (client is GeminiClient && client.usedModel != n.geminiModel.trim().removePrefix("models/").ifEmpty { Settings.DEFAULT_GEMINI_MODEL }) {
                    sb.append("\n\n※ 설정한 모델이 지금 붐벼서 대체 모델(").append(client.usedModel)
                        .append(")로 연결됐어요. 팟캐스트를 만들 때도 이렇게 자동으로 바꿔 씁니다.")
                }
                if (n.useWebSearch) {
                    val r2 = client.generate(
                        "검색한 내용을 한국어 한 문장으로 요약하세요.",
                        "최근 한국 경제 뉴스 하나를 검색해서 한 문장으로 알려 주세요.",
                        true
                    )
                    sb.append("\n\n웹 검색: ").append(
                        if (r2.usedSearch) "✅ 사용 가능" else "❌ 사용 불가 (Gemini 무료 등급이면 정상입니다. 수집한 뉴스만으로 만들어요)"
                    )
                }
            } catch (e: Exception) {
                sb.append("❌ 실패\n").append(e.message ?: e.toString())
            }
            runOnUiThread {
                dismissSafely(dialog)
                alert("AI 연결 시험", sb.toString())
            }
        }.start()
    }

    private fun testGeminiTts() {
        val n = readUi()
        if (n.geminiKey.isBlank()) {
            Ui.toast(this, "Gemini API 키를 먼저 입력해 주세요.")
            return
        }
        val dialog = waitDialog("Gemini 음성을 만드는 중…")
        Thread {
            try {
                val synth = GeminiTtsSynth(this, n)
                val turns = if (n.style == "duo") {
                    listOf(
                        Utterance(0, "좋은 아침입니다. 모닝캐스트 ${n.host1}입니다.", 0),
                        Utterance(1, "${n.host2}입니다. 오늘도 알찬 소식을 준비했습니다.", 0)
                    )
                } else {
                    listOf(Utterance(0, "좋은 아침입니다. 모닝캐스트 음성 시험입니다.", 0))
                }
                val pcm = synth.requestAudio(turns)
                val f = File(cacheDir, "tts_test.wav")
                f.writeBytes(Wav.toWavBytes(pcm))
                runOnUiThread {
                    dismissSafely(dialog)
                    playPreviewFile(f)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    dismissSafely(dialog)
                    alert("Gemini 음성 시험 실패", e.message ?: e.toString())
                }
            }
        }.start()
    }

    private fun playPreviewFile(f: File) {
        try {
            previewPlayer?.release()
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            mp.setDataSource(f.absolutePath)
            mp.prepare()
            mp.start()
            previewPlayer = mp
        } catch (e: Exception) {
            Ui.toast(this, "재생 실패: ${e.message}")
        }
    }

    private fun listModels(kind: String) {
        val key = (if (kind == "claude") etClaudeKey else etGeminiKey).text.toString().trim()
        if (key.isEmpty()) {
            Ui.toast(this, "먼저 API 키를 입력해 주세요.")
            return
        }
        val dialog = waitDialog("모델 목록을 불러오는 중…")
        Thread {
            try {
                val names = if (kind == "claude") fetchClaudeModels(key) else fetchGeminiModels(key, kind == "gemini-tts")
                runOnUiThread {
                    dismissSafely(dialog)
                    if (names.isEmpty()) {
                        Ui.toast(this, "모델을 찾지 못했습니다.")
                    } else {
                        AlertDialog.Builder(this)
                            .setTitle("모델 선택")
                            .setItems(names.toTypedArray()) { _, which ->
                                val target = when (kind) {
                                    "claude" -> etClaudeModel
                                    "gemini-tts" -> etTtsModel
                                    else -> etGeminiModel
                                }
                                target.setText(names[which])
                            }
                            .setNegativeButton("닫기", null)
                            .show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    dismissSafely(dialog)
                    alert("목록을 불러오지 못했습니다", e.message ?: e.toString())
                }
            }
        }.start()
    }

    private fun fetchGeminiModels(key: String, ttsOnly: Boolean): List<String> {
        val resp = Http.get(
            "https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000",
            mapOf("x-goog-api-key" to key)
        )
        if (resp.code != 200) throw Exception(Llm.parseGeminiError(resp).summary)
        val arr = JSONObject(resp.text).optJSONArray("models") ?: return emptyList()
        val skip = listOf("image", "live", "embedding", "native-audio", "transcribe", "robotics", "veo", "lyria", "omni", "translate")
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val m = arr.optJSONObject(i) ?: continue
            val name = m.optString("name").removePrefix("models/")
            val methods = m.optJSONArray("supportedGenerationMethods")?.toString() ?: ""
            if (!methods.contains("generateContent")) continue
            val isTts = name.contains("tts")
            if (ttsOnly != isTts) continue
            if (!ttsOnly && skip.any { name.contains(it) }) continue
            out.add(name)
        }
        return out.sortedDescending()
    }

    private fun fetchClaudeModels(key: String): List<String> {
        val resp = Http.get(
            "https://api.anthropic.com/v1/models?limit=100",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01")
        )
        if (resp.code != 200) throw Exception("HTTP ${resp.code}: ${resp.text.take(200)}")
        val arr = JSONObject(resp.text).optJSONArray("data") ?: return emptyList()
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val id = arr.optJSONObject(i)?.optString("id") ?: ""
            if (id.isNotEmpty()) out.add(id)
        }
        return out
    }

    // ── 도우미 ────────────────────────────────────────────────────────

    private fun setSpinner(sp: Spinner, items: List<String>, sel: Int) {
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        sp.setSelection(sel.coerceIn(0, maxOf(0, items.size - 1)))
    }

    private fun nearestIndex(values: List<Float>, v: Float): Int {
        var best = 0
        for (i in values.indices) if (Math.abs(values[i] - v) < Math.abs(values[best] - v)) best = i
        return best
    }

    private fun alert(title: String, msg: String) {
        if (isFinishing) return
        AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("확인", null).show()
    }

    private fun waitDialog(msg: String): AlertDialog =
        AlertDialog.Builder(this).setMessage(msg).setCancelable(true).show()

    private fun dismissSafely(d: AlertDialog) {
        try {
            if (d.isShowing) d.dismiss()
        } catch (_: Exception) {
        }
    }

    private fun openSettings(i: Intent) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            try {
                startActivity(Intent(SysSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                Ui.toast(this, "설정 화면을 열 수 없습니다.")
            }
        }
    }
}
