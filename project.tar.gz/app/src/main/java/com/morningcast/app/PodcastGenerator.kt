package com.morningcast.app

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GenerationResult(val episode: Episode, val warnings: List<String>)

/** 자료 수집 → 코너별 대본 → 음성 합성 → 파일 저장 전체 과정 */
class PodcastGenerator(
    private val ctx: Context,
    private val manual: Boolean,
    private val progress: (String) -> Unit
) {

    fun run(): GenerationResult {
        val s = Settings.load(ctx)
        val now = System.currentTimeMillis()
        var playAt = Scheduler.targetPlayTime(s, now)
        // 낮에 '지금 만들기'를 누른 경우: 오늘 밤 예약 생성이 내일 것을 다시 만들므로, 이번 것은 '오늘' 방송분으로 표시
        if (manual && playAt > now && Scheduler.generationTimeFor(s, playAt) > now) playAt = now
        val targetKey = Scheduler.dateKey(playAt)
        val dateLabel = SimpleDateFormat("M월 d일 EEEE", Locale.KOREAN).format(Date(playAt))
        val segs = s.segments.filter { it.enabled && it.minutes > 0 }
        if (segs.isEmpty()) throw ConfigException("켜져 있는 코너가 없습니다. 설정에서 코너를 하나 이상 켜 주세요.")
        val client = Llm.create(ctx, s)
        if (s.ttsProvider == "gemini" && s.geminiKey.isBlank()) {
            throw ConfigException("Gemini 고품질 음성을 쓰려면 Gemini API 키가 필요합니다.")
        }
        AppLog.log(ctx, "생성 시작: $dateLabel 방송용 · ${client.label} · 음성=${s.ttsProvider}")

        val writer = ScriptWriter(ctx, s, client)
        val recent = EpisodeStore.recentCovered(ctx, 4)
        val coveredDois = EpisodeStore.loadCoveredDois(ctx)
        val scripts = ArrayList<SegmentScript>()
        val failed = ArrayList<String>()
        val warnings = ArrayList<String>()

        for ((i, seg) in segs.withIndex()) {
            val tag = "[${i + 1}/${segs.size}] ${seg.title}"
            progress("$tag 자료 모으는 중")
            val pack = Materials.collect(ctx, s, seg, coveredDois)
            AppLog.log(ctx, "$tag 자료: 뉴스 ${pack.newsCount}건, 논문 ${pack.paperCount}편")
            progress("$tag 대본 쓰는 중 (AI)")
            try {
                scripts.add(writer.write(seg, pack, dateLabel, recent[seg.key] ?: emptyList(), i, segs.size))
            } catch (e: AuthException) {
                throw e
            } catch (e: ConfigException) {
                throw e
            } catch (e: QuotaException) {
                AppLog.error(ctx, "$tag 한도 초과", e)
                failed.add(seg.title)
                warnings.add("${seg.title}: ${e.message}")
                for (rest in segs.drop(i + 1)) failed.add(rest.title)
                break
            } catch (e: Exception) {
                AppLog.error(ctx, "$tag 대본 실패", e)
                failed.add(seg.title)
                warnings.add("${seg.title}: ${e.message}")
            }
            if (i < segs.size - 1) Llm.sleep(3000)
        }
        if (scripts.isEmpty()) {
            throw LlmException("대본을 하나도 만들지 못했습니다. ${warnings.joinToString(" / ")}")
        }
        if (s.useWebSearch && !writer.searchAllowed) warnings.add("웹 검색을 쓸 수 없어 수집한 자료만으로 만들었습니다")

        val utts = Assembler.build(s, dateLabel, scripts, failed)
        val pcmFile = File(ctx.cacheDir, "episode.pcm")
        val starts = HashMap<Int, Long>()
        var ttsLabel = "휴대폰 음성"
        var durationMs: Long
        if (s.ttsProvider == "gemini") {
            try {
                progress("고품질 음성 만드는 중")
                durationMs = synthGemini(s, utts, pcmFile, starts)
                ttsLabel = "Gemini 음성 (${s.geminiTtsModel})"
            } catch (e: Exception) {
                AppLog.error(ctx, "Gemini 음성 실패 → 휴대폰 음성으로 대체", e)
                warnings.add("Gemini 음성 실패로 휴대폰 음성을 사용했습니다 (${e.message})")
                starts.clear()
                progress("휴대폰 음성으로 다시 만드는 중")
                durationMs = synthAndroid(s, utts, pcmFile, starts)
            }
        } else {
            progress("음성 만드는 중")
            durationMs = synthAndroid(s, utts, pcmFile, starts)
        }

        progress("오디오 파일 저장 중")
        val dir = EpisodeStore.newEpisodeDir(ctx)
        val title = "$dateLabel 모닝캐스트"
        val created = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREA).format(Date())
        val info = "만든 시각: $created · 대본: ${client.label} · 음성: $ttsLabel"
        val audioName = AudioFinalizer.finalize(pcmFile, dir, 24000, durationMs) { msg -> AppLog.log(ctx, msg) }
        pcmFile.delete()
        File(ctx.cacheDir, "tts").deleteRecursively()

        File(dir, "script.txt").writeText(Assembler.scriptText(s, title, info, utts, scripts))
        val segTitles = scripts.map { it.segment.title }
        val segStarts = scripts.indices.map { starts[it] ?: 0L }
        val covered = HashMap<String, List<String>>()
        for (sc in scripts) covered[sc.segment.key] = sc.covered
        val ep = EpisodeStore.writeMeta(
            dir, targetKey, title, audioName, durationMs, segTitles, segStarts, failed, info, covered
        )
        EpisodeStore.addCoveredDois(ctx, scripts.flatMap { sc -> sc.covered.flatMap { EpisodeStore.extractDois(it) } })
        EpisodeStore.prune(ctx, s.keepEpisodes)
        AppLog.log(ctx, "생성 완료: $title, ${durationMs / 60000}분 ${durationMs / 1000 % 60}초, 파일 $audioName")
        return GenerationResult(ep, warnings)
    }

    private fun synthAndroid(s: Settings, utts: List<Utterance>, pcmFile: File, starts: MutableMap<Int, Long>): Long {
        PcmWriter(pcmFile).use { w ->
            AndroidTtsSynth(ctx, s).synthesize(utts, w, starts, progress)
            return w.positionMs
        }
    }

    private fun synthGemini(s: Settings, utts: List<Utterance>, pcmFile: File, starts: MutableMap<Int, Long>): Long {
        PcmWriter(pcmFile).use { w ->
            GeminiTtsSynth(ctx, s).synthesize(utts, w, starts, progress)
            return w.positionMs
        }
    }
}
