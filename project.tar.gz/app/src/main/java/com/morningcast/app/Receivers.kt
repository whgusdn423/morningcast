package com.morningcast.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** 알람이 울리면 재생 또는 생성 서비스를 시작합니다. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val ctx = context.applicationContext
        when (intent.action) {
            Scheduler.ACTION_PLAY -> {
                AppLog.log(ctx, "재생 알람이 울렸습니다")
                PlaybackService.startScheduled(ctx, false)
                Scheduler.rescheduleAll(ctx)
            }
            Scheduler.ACTION_PLAY_TEST -> {
                AppLog.log(ctx, "테스트 알람이 울렸습니다")
                PlaybackService.startScheduled(ctx, true)
            }
            Scheduler.ACTION_GENERATE -> {
                AppLog.log(ctx, "생성 알람이 울렸습니다")
                GenerationService.start(ctx, false)
            }
        }
    }
}

/** 재부팅·앱 업데이트·시간 변경 시 알람을 다시 예약합니다. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AppLog.log(context, "시스템 이벤트(${intent.action}) → 알람 다시 예약")
        Scheduler.rescheduleAll(context.applicationContext)
    }
}
