package com.morningcast.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

open class LlmException(msg: String) : Exception(msg)
/** API 키 문제 — 재시도해도 소용없음 */
class AuthException(msg: String) : LlmException(msg)
/** 설정(모델 이름, 키 누락, 잔액 부족 등) 문제 */
class ConfigException(msg: String) : LlmException(msg)
/** 일일 사용 한도 초과 */
class QuotaException(msg: String) : LlmException(msg)
/** 웹 검색 도구를 쓸 수 없는 계정/등급 */
class SearchUnavailableException(msg: String) : LlmException(msg)

class LlmResult(val text: String, val sources: List<Source>, val usedSearch: Boolean, val note: String)

interface LlmClient {
    val label: String
    fun generate(system: String, user: String, useSearch: Boolean): LlmResult
}

class ApiError(
    val code: Int,
    val status: String,
    val message: String,
    val retryDelaySec: Int?,
    val perDay: Boolean,
    val quotaIds: String = ""
) {
    val summary: String get() = ("HTTP $code $status ${message.take(200)}" + if (quotaIds.isNotEmpty()) " [quota: $quotaIds]" else "").trim()
}

object Llm {
    fun create(ctx: Context, s: Settings, quick: Boolean = false): LlmClient {
        return if (s.scriptProvider == "claude") {
            if (s.claudeKey.isBlank()) throw ConfigException("Claude API 키를 입력해 주세요.")
            ClaudeClient(ctx, s.claudeKey.trim(), s.claudeModel.trim().ifEmpty { Settings.DEFAULT_CLAUDE_MODEL })
        } else {
            if (s.geminiKey.isBlank()) throw ConfigException("Gemini API 키를 입력해 주세요.")
            GeminiClient(ctx, s.geminiKey.trim(), s.geminiModel.trim().ifEmpty { Settings.DEFAULT_GEMINI_MODEL }, quick)
        }
    }

    fun sleep(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
        }
    }

    /** "37s", "1.5s" → 초 */
    fun parseSeconds(v: String?): Int? {
        if (v.isNullOrBlank()) return null
        val num = v.trim().removeSuffix("s").toDoubleOrNull() ?: return null
        return Math.ceil(num).toInt().coerceIn(1, 600)
    }

    fun parseGeminiError(resp: HttpResponse): ApiError {
        return try {
            val e = JSONObject(resp.text).getJSONObject("error")
            val msg = e.optString("message")
            val status = e.optString("status")
            var retry: Int? = null
            var perDay = false
            val ids = ArrayList<String>()
            val details = e.optJSONArray("details")
            if (details != null) {
                for (i in 0 until details.length()) {
                    val d = details.optJSONObject(i) ?: continue
                    val type = d.optString("@type")
                    if (type.endsWith("RetryInfo")) retry = parseSeconds(d.optString("retryDelay"))
                    if (type.endsWith("QuotaFailure")) {
                        val v = d.optJSONArray("violations")
                        if (v != null) {
                            for (j in 0 until v.length()) {
                                val q = v.optJSONObject(j) ?: continue
                                val id = q.optString("quotaId") + " " + q.optString("quotaMetric")
                                ids.add(q.optString("quotaId").ifEmpty { q.optString("quotaMetric") } + (if (q.has("quotaValue")) "=" + q.optString("quotaValue") else ""))
                                if (id.contains("PerDay", true) || id.contains("per_day", true)) perDay = true
                            }
                        }
                    }
                }
            }
            if (msg.contains("per day", true) || msg.contains("daily", true)) perDay = true
            ApiError(resp.code, status, msg, retry, perDay, ids.joinToString(", "))
        } catch (ex: Exception) {
            ApiError(resp.code, "", resp.text.take(300), null, false)
        }
    }

    fun looksSearchRelated(msg: String): Boolean {
        val m = msg.lowercase()
        return m.contains("search") || m.contains("grounding") || m.contains("tool")
    }
}

/** 모델이 과부하(503)·한도(429)·없음(404)이라 다음 대체 모델로 넘어가야 할 때 */
class ModelBusyException(msg: String) : LlmException(msg)

/** Google Gemini (generateContent REST) — 바쁘면 대체 모델로 자동 전환 */
class GeminiClient(
    private val ctx: Context,
    private val apiKey: String,
    private val model: String,
    private val quick: Boolean = false
) : LlmClient {
    private val chain: List<String> =
        (listOf(model) + Settings.GEMINI_FALLBACK_MODELS).map { it.trim().removePrefix("models/") }.filter { it.isNotEmpty() }.distinct()
    @Volatile var usedModel: String = chain.first()
    override val label: String get() = "Gemini ($usedModel)"

    override fun generate(system: String, user: String, useSearch: Boolean): LlmResult {
        if (useSearch) {
            try {
                return callChain(system, user, true)
            } catch (e: SearchUnavailableException) {
                AppLog.log(ctx, "Gemini 웹 검색을 쓸 수 없어(무료 등급 등) 수집 자료만으로 작성합니다: ${e.message}")
                val r = callChain(system, user, false)
                return LlmResult(r.text, r.sources, false, "웹 검색 사용 불가")
            }
        }
        return callChain(system, user, false)
    }

    private fun callChain(system: String, user: String, search: Boolean): LlmResult {
        val errors = ArrayList<String>()
        var allDaily = true
        for ((i, m) in chain.withIndex()) {
            try {
                val r = call(m, system, user, search)
                usedModel = m
                if (i > 0) AppLog.log(ctx, "기본 모델이 바빠서 대체 모델 $m 로 작성했습니다.")
                return r
            } catch (e: ModelBusyException) {
                errors.add("• $m: ${e.message}")
                if (!(e.message ?: "").contains("하루")) allDaily = false
                AppLog.log(ctx, "Gemini $m 사용 불가, 다음 모델 시도: ${e.message}")
            }
        }
        val head = if (allDaily) "Gemini 무료 하루 한도를 모두 썼습니다. 내일 다시 시도되거나 결제를 등록하면 늘어납니다."
        else "Gemini 서버가 지금 붐비거나 요청 한도에 걸렸습니다. 몇 분 뒤 다시 시도해 주세요."
        val msg = head + "\n" + errors.joinToString("\n")
        // 모든 모델이 막혔으면 다음 코너도 막힐 가능성이 높으므로 이번 생성을 멈추고 나중에 재시도(요청 낭비 방지)
        throw QuotaException(msg)
    }

    internal fun buildBody(system: String, user: String, search: Boolean): JSONObject {
        val body = JSONObject()
        body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        body.put(
            "contents",
            JSONArray().put(
                JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", user)))
            )
        )
        body.put("generationConfig", JSONObject().put("temperature", 0.7))
        if (search) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        return body
    }

    private fun call(m: String, system: String, user: String, search: Boolean): LlmResult {
        val isLast = m == chain.last()
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent"
        val json = buildBody(system, user, search).toString()
        val timeout = if (quick) 45_000 else 300_000
        var attempt = 0
        while (true) {
            attempt++
            val resp = try {
                Http.postJson(url, mapOf("x-goog-api-key" to apiKey), json, timeout)
            } catch (e: IOException) {
                if (!quick && attempt < 3) {
                    AppLog.log(ctx, "Gemini 네트워크 오류, 재시도($attempt): ${e.message}")
                    Llm.sleep(10_000L * attempt)
                    continue
                }
                throw LlmException("네트워크 오류: ${e.message ?: e.javaClass.simpleName} (인터넷 연결을 확인해 주세요)")
            }
            if (resp.code == 200) return parse(resp.text, search)
            val err = Llm.parseGeminiError(resp)
            AppLog.log(ctx, "Gemini($m) 오류: ${err.summary}")
            if (search && (resp.code == 400 || resp.code == 403 || resp.code == 429) && Llm.looksSearchRelated(err.message)) {
                throw SearchUnavailableException(err.summary)
            }
            when {
                resp.code == 401 || resp.code == 403 || err.message.contains("API key not valid", true) ||
                    err.message.contains("API_KEY_INVALID", true) ->
                    throw AuthException("Gemini API 키가 올바르지 않거나 권한이 없습니다. 키를 다시 복사해 붙여 넣어 보세요. (${err.message.take(160)})")
                resp.code == 404 ->
                    throw ModelBusyException("모델을 찾을 수 없음")
                resp.code == 429 -> {
                    if (err.perDay) throw ModelBusyException("하루 한도 초과")
                    val wait = err.retryDelaySec ?: 20
                    if (!quick && isLast && attempt < 2 && wait <= 40) {
                        Llm.sleep((wait + 2) * 1000L)
                        continue
                    }
                    throw ModelBusyException("요청이 너무 잦음(분당 한도)")
                }
                resp.code >= 500 -> {
                    if (!quick && attempt < 2) {
                        Llm.sleep(8_000L)
                        continue
                    }
                    throw ModelBusyException("서버 과부하(HTTP ${resp.code})")
                }
                else -> throw LlmException("Gemini 오류 ${err.summary}")
            }
        }
    }

    internal fun parse(text: String, search: Boolean): LlmResult {
        val o = JSONObject(text)
        val cands = o.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val block = o.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
            throw LlmException("Gemini가 응답을 만들지 않았습니다 $block".trim())
        }
        val c = cands.getJSONObject(0)
        val sb = StringBuilder()
        val parts = c.optJSONObject("content")?.optJSONArray("parts")
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val p = parts.optJSONObject(i) ?: continue
                if (p.optBoolean("thought", false)) continue
                sb.append(p.optString("text", ""))
            }
        }
        val finish = c.optString("finishReason")
        val sources = ArrayList<Source>()
        val chunks = c.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
        if (chunks != null) {
            for (i in 0 until chunks.length()) {
                val w = chunks.optJSONObject(i)?.optJSONObject("web") ?: continue
                val uri = w.optString("uri")
                if (uri.isNotEmpty()) sources.add(Source(w.optString("title", "웹 검색"), uri))
            }
        }
        if (sb.isBlank()) throw LlmException("Gemini 응답이 비어 있습니다 (finishReason=$finish)")
        return LlmResult(sb.toString(), sources, search, if (finish == "MAX_TOKENS") "출력 길이 제한에 걸림" else "")
    }
}

/** Anthropic Claude (Messages API) */
class ClaudeClient(private val ctx: Context, private val apiKey: String, private val model: String) : LlmClient {
    override val label: String get() = "Claude ($model)"

    override fun generate(system: String, user: String, useSearch: Boolean): LlmResult {
        if (useSearch) {
            try {
                return call(system, user, true)
            } catch (e: SearchUnavailableException) {
                AppLog.log(ctx, "Claude 웹 검색을 쓸 수 없어 수집 자료만으로 작성합니다: ${e.message}")
                val r = call(system, user, false)
                return LlmResult(r.text, r.sources, false, "웹 검색 사용 불가")
            }
        }
        return call(system, user, false)
    }

    private fun call(system: String, user: String, search: Boolean): LlmResult {
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", user))
        val texts = StringBuilder()
        val sources = ArrayList<Source>()
        var rounds = 0
        while (true) {
            rounds++
            val body = buildBody(system, messages, search)
            val o = JSONObject(post(body.toString(), search).text)
            val content = o.optJSONArray("content") ?: JSONArray()
            absorb(content, texts, sources)
            val stop = o.optString("stop_reason")
            if (stop == "pause_turn" && rounds < 5) {
                messages.put(JSONObject().put("role", "assistant").put("content", content))
                continue
            }
            if (stop == "refusal") throw LlmException("Claude가 요청을 거절했습니다.")
            if (texts.isBlank()) throw LlmException("Claude 응답이 비어 있습니다 (stop_reason=$stop)")
            val uniq = sources.distinctBy { it.url }
            return LlmResult(texts.toString(), uniq, search, if (stop == "max_tokens") "출력 길이 제한에 걸림" else "")
        }
    }

    internal fun buildBody(system: String, messages: JSONArray, search: Boolean): JSONObject {
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 16000)
            .put("system", system)
            .put("messages", messages)
        if (search) {
            val tool = JSONObject()
                .put("type", "web_search_20250305")
                .put("name", "web_search")
                .put("max_uses", 6)
                .put("user_location", JSONObject().put("type", "approximate").put("country", "KR").put("timezone", "Asia/Seoul"))
            body.put("tools", JSONArray().put(tool))
        }
        return body
    }

    companion object {
        /** 응답 content 블록에서 본문 텍스트와 출처를 모읍니다. */
        fun absorb(content: JSONArray, texts: StringBuilder, sources: MutableList<Source>) {
            for (i in 0 until content.length()) {
                val b = content.optJSONObject(i) ?: continue
                when (b.optString("type")) {
                    "text" -> {
                        texts.append(b.optString("text"))
                        val cits = b.optJSONArray("citations")
                        if (cits != null) {
                            for (j in 0 until cits.length()) {
                                val c = cits.optJSONObject(j) ?: continue
                                val u = c.optString("url")
                                if (u.isNotEmpty()) sources.add(Source(c.optString("title", u), u))
                            }
                        }
                    }
                    "web_search_tool_result" -> {
                        val arr = b.optJSONArray("content")
                        if (arr != null) {
                            for (j in 0 until arr.length()) {
                                val r = arr.optJSONObject(j) ?: continue
                                val u = r.optString("url")
                                if (u.isNotEmpty()) sources.add(Source(r.optString("title", u), u))
                            }
                        }
                    }
                }
            }
        }
    }

    private fun post(json: String, search: Boolean): HttpResponse {
        val headers = mapOf("x-api-key" to apiKey, "anthropic-version" to "2023-06-01")
        var attempt = 0
        while (true) {
            attempt++
            val resp = try {
                Http.postJson("https://api.anthropic.com/v1/messages", headers, json, 600_000)
            } catch (e: IOException) {
                if (attempt < 3) {
                    Llm.sleep(10_000L * attempt)
                    continue
                }
                throw LlmException("네트워크 오류: ${e.message}")
            }
            if (resp.code == 200) return resp
            var type = ""
            var msg = resp.text.take(300)
            try {
                val e = JSONObject(resp.text).optJSONObject("error")
                if (e != null) {
                    type = e.optString("type")
                    msg = e.optString("message", msg)
                }
            } catch (_: Exception) {
            }
            AppLog.log(ctx, "Claude 오류 HTTP ${resp.code} $type $msg")
            if (search && (resp.code == 400 || resp.code == 403) && Llm.looksSearchRelated(msg)) {
                throw SearchUnavailableException(msg)
            }
            when {
                resp.code == 401 -> throw AuthException("Claude API 키가 올바르지 않습니다.")
                resp.code == 403 -> throw AuthException("Claude API 권한 오류: ${msg.take(150)}")
                resp.code == 404 -> throw ConfigException("Claude 모델 '$model'을 찾을 수 없습니다. 설정에서 모델 이름을 확인해 주세요.")
                resp.code == 400 && msg.contains("credit", true) ->
                    throw ConfigException("Claude 크레딧 잔액이 부족합니다. Claude Console 에서 충전해 주세요.")
                resp.code == 429 || resp.code == 529 || resp.code >= 500 -> {
                    if (attempt < 5) {
                        val ra = Llm.parseSeconds(resp.header("retry-after")) ?: (20 * attempt)
                        Llm.sleep(ra * 1000L + 1000L)
                        continue
                    }
                    throw LlmException("Claude 서버가 혼잡합니다 (HTTP ${resp.code})")
                }
                else -> throw LlmException("Claude 오류 HTTP ${resp.code}: ${msg.take(200)}")
            }
        }
    }
}
