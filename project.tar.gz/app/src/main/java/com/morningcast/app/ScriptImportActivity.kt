package com.morningcast.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import java.io.File

/** 붙여 넣은(또는 공유받은) 대본을 음성 파일로 만드는 화면 */
class ScriptImportActivity : Activity() {

    companion object {
        private const val CLAUDE_PKG = "com.anthropic.claude"
        private const val PREFS = "script_import"

        fun open(ctx: Context) {
            ctx.startActivity(Intent(ctx, ScriptImportActivity::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var etTopic: EditText
    private lateinit var etMinutes: EditText
    private lateinit var etTitle: EditText
    private lateinit var etScript: EditText
    private lateinit var tvStats: TextView
    private lateinit var tvJob: TextView
    private lateinit var btnMake: Button
    private lateinit var btnListen: Button
    private lateinit var rbGemini: RadioButton
    private var watching = false
    private var lastShownResult: String? = null

    private val statsRunnable = Runnable { updateStats() }
    private val poll = object : Runnable {
        override fun run() {
            refreshJob()
            handler.postDelayed(this, 1000)
        }
    }

    private fun draftFile() = File(filesDir, "import_draft.txt")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_import)
        Ui.applyInsets(findViewById(R.id.root))
        etTopic = findViewById(R.id.etTopic)
        etMinutes = findViewById(R.id.etMinutes)
        etTitle = findViewById(R.id.etTitle)
        etScript = findViewById(R.id.etScript)
        tvStats = findViewById(R.id.tvStats)
        tvJob = findViewById(R.id.tvJob)
        btnMake = findViewById(R.id.btnMake)
        btnListen = findViewById(R.id.btnListen)
        rbGemini = findViewById(R.id.rbVoiceGemini)

        val p = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        etTopic.setText(p.getString("topic", "") ?: "")
        etMinutes.setText(p.getInt("minutes", 40).toString())
        etTitle.setText(p.getString("title", "") ?: "")
        if (p.getString("voice", "android") == "gemini") rbGemini.isChecked = true
        try {
            if (draftFile().exists()) etScript.setText(draftFile().readText())
        } catch (_: Exception) {
        }

        etScript.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(statsRunnable)
                handler.postDelayed(statsRunnable, 400)
            }
        })

        findViewById<Button>(R.id.btnCopyPrompt).setOnClickListener { copyPrompt() }
        findViewById<Button>(R.id.btnOpenClaude).setOnClickListener { openClaude() }
        findViewById<Button>(R.id.btnPaste).setOnClickListener { pasteFromClipboard() }
        findViewById<Button>(R.id.btnPreview).setOnClickListener { preview() }
        findViewById<Button>(R.id.btnClearScript).setOnClickListener {
            if (etScript.text.isNullOrBlank()) return@setOnClickListener
            AlertDialog.Builder(this)
                .setMessage("붙여 넣은 대본을 모두 지울까요?")
                .setPositiveButton("지우기") { _, _ ->
                    etScript.setText("")
                    etTitle.setText("")
                    saveDraft()
                }
                .setNegativeButton("취소", null)
                .show()
        }
        btnMake.setOnClickListener { make() }
        btnListen.setOnClickListener {
            val id = GenerationService.lastScriptEpisodeId ?: return@setOnClickListener
            PlaybackService.playEpisode(this, id, 0L)
            startActivity(Intent(this, PlayerActivity::class.java))
        }
        findViewById<Button>(R.id.btnLibrary).setOnClickListener {
            startActivity(Intent(this, EpisodesActivity::class.java))
        }

        updateStats()
        handleIncoming(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            handleIncoming(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(poll)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(poll)
        saveDraft()
    }

    private fun saveDraft() {
        try {
            draftFile().writeText(etScript.text?.toString() ?: "")
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("topic", etTopic.text?.toString() ?: "")
                .putInt("minutes", minutes())
                .putString("title", etTitle.text?.toString() ?: "")
                .putString("voice", if (rbGemini.isChecked) "gemini" else "android")
                .apply()
        } catch (_: Exception) {
        }
    }

    private fun minutes(): Int = (etMinutes.text?.toString()?.trim()?.toIntOrNull() ?: 40).coerceIn(5, 90)

    // ── 공유·텍스트 선택 메뉴로 들어온 대본 ─────────────────────────────

    private fun handleIncoming(i: Intent?) {
        if (i == null) return
        val text: String? = when (i.action) {
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT) ?: readStream(i)
            Intent.ACTION_PROCESS_TEXT -> i.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            else -> null
        }
        // 같은 공유를 화면 회전 등으로 다시 처리하지 않도록
        i.setAction(Intent.ACTION_MAIN)
        if (text.isNullOrBlank()) {
            if (text != null) Ui.toast(this, "받은 글이 비어 있습니다.")
            return
        }
        val subject = i.getStringExtra(Intent.EXTRA_SUBJECT)
        if (!subject.isNullOrBlank() && etTitle.text.isNullOrBlank()) etTitle.setText(subject.take(60))
        addText(text, askIfExisting = true)
    }

    private fun readStream(i: Intent): String? {
        return try {
            @Suppress("DEPRECATION")
            val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
                i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                i.getParcelableExtra(Intent.EXTRA_STREAM)
            }
            if (uri == null) null else contentResolver.openInputStream(uri)?.use { s ->
                val bytes = s.readBytes()
                if (bytes.size > 2_000_000) null else String(bytes, Charsets.UTF_8)
            }
        } catch (e: Exception) {
            AppLog.error(this, "공유받은 파일을 읽지 못했습니다", e)
            null
        }
    }

    private fun addText(text: String, askIfExisting: Boolean) {
        val cur = etScript.text?.toString() ?: ""
        if (cur.isBlank()) {
            etScript.setText(text.trim())
            afterAdd(text)
            return
        }
        if (!askIfExisting) {
            appendText(text)
            return
        }
        AlertDialog.Builder(this)
            .setTitle("이미 붙여 넣은 대본이 있어요")
            .setMessage("받은 글(${"%,d".format(text.length)}자)을 어떻게 할까요?")
            .setPositiveButton("뒤에 이어 붙이기") { _, _ -> appendText(text) }
            .setNeutralButton("새로 바꾸기") { _, _ ->
                etScript.setText(text.trim())
                etTitle.setText("")
                afterAdd(text)
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun appendText(text: String) {
        val cur = etScript.text?.toString()?.trimEnd() ?: ""
        etScript.setText(cur + "\n\n" + text.trim())
        afterAdd(text)
    }

    private fun afterAdd(text: String) {
        etScript.setSelection(etScript.text?.length ?: 0)
        saveDraft()
        updateStats()
        Ui.toast(this, "${"%,d".format(text.trim().length)}자를 넣었어요.")
    }

    private fun pasteFromClipboard() {
        val cm = getSystemService(ClipboardManager::class.java)
        val clip = try {
            cm?.primaryClip
        } catch (_: Exception) {
            null
        }
        val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this)?.toString() else null
        if (text.isNullOrBlank()) {
            Ui.toast(this, "복사된 글이 없습니다. Claude 답변의 '복사' 버튼을 먼저 눌러 주세요.")
            return
        }
        addText(text, askIfExisting = false)
    }

    // ── 요청문 / Claude 열기 ──────────────────────────────────────

    private fun copyPrompt() {
        val s = Settings.load(this)
        val prompt = ScriptPrompt.build(etTopic.text?.toString() ?: "", minutes(), s.host1, s.host2)
        val cm = getSystemService(ClipboardManager::class.java)
        cm?.setPrimaryClip(ClipData.newPlainText("팟캐스트 대본 요청", prompt))
        saveDraft()
        if (etTopic.text.isNullOrBlank()) {
            Ui.toast(this, "요청문을 복사했어요. 주제 칸이 비어 있어서, Claude에 붙여 넣은 뒤 첫 줄에 주제를 적어 주세요.")
        } else {
            Ui.toast(this, "요청문을 복사했어요. 'Claude 열기'를 눌러 붙여 넣으세요.")
        }
    }

    private fun openClaude() {
        val launch = try {
            packageManager.getLaunchIntentForPackage(CLAUDE_PKG)
        } catch (_: Exception) {
            null
        }
        try {
            if (launch != null) {
                startActivity(launch)
            } else {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://claude.ai/new")))
            }
        } catch (e: Exception) {
            Ui.toast(this, "Claude를 열 수 없습니다: ${e.message}")
        }
    }

    // ── 미리 보기 / 통계 ───────────────────────────────────────────

    private fun updateStats() {
        val text = etScript.text?.toString() ?: ""
        if (text.isBlank()) {
            tvStats.text = "대본을 붙여 넣으면 글자 수와 예상 길이가 여기에 나옵니다."
            return
        }
        val parsed = ScriptParser.parse(text, etTitle.text?.toString() ?: "")
        val rate = Settings.load(this).speechRate
        val who = if (parsed.speakers.size >= 2) "두 목소리(${parsed.speakers.joinToString(", ")})"
        else "한 목소리 (\"이름: 대사\" 형식이면 두 목소리로 읽어요)"
        val sb = StringBuilder()
        sb.append("읽을 글자 ${"%,d".format(parsed.spokenChars)}자 · 예상 약 ${parsed.estimatedMinutes(rate)}분\n")
        sb.append(who)
        if (parsed.chapters.isNotEmpty()) sb.append(" · 소제목 ${parsed.chapters.size}개")
        if (parsed.title.isNotEmpty()) sb.append("\n제목: ").append(parsed.title)
        tvStats.text = sb.toString()
    }

    private fun preview() {
        val text = etScript.text?.toString() ?: ""
        if (text.isBlank()) {
            Ui.toast(this, "먼저 대본을 붙여 넣어 주세요.")
            return
        }
        val parsed = ScriptParser.parse(text, etTitle.text?.toString() ?: "")
        val f = File(cacheDir, "import_preview.txt")
        f.writeText(
            "실제로 읽을 내용입니다. 빠지면 안 되는 부분이 빠졌는지 확인해 보세요.\n" +
                "(표·링크·이모지·괄호 지시문·AI 인사말은 빼고 읽습니다)\n\n" + parsed.cleanText
        )
        TextViewerActivity.open(this, parsed.title.ifEmpty { "읽을 내용 미리 보기" }, f.absolutePath)
    }

    // ── 만들기 ────────────────────────────────────────────────────

    private fun make() {
        val text = etScript.text?.toString() ?: ""
        val parsed = ScriptParser.parse(text, etTitle.text?.toString() ?: "")
        if (parsed.spokenChars < 20) {
            Ui.toast(this, "읽을 내용이 너무 적습니다. 대본을 붙여 넣어 주세요.")
            return
        }
        if (GenerationService.isRunning) {
            Ui.toast(this, if (GenerationService.scriptMode) "이미 만드는 중입니다." else "아침 방송을 만드는 중이에요. 끝난 뒤에 다시 눌러 주세요.")
            return
        }
        val voice = if (rbGemini.isChecked) "gemini" else "android"
        if (voice == "gemini" && parsed.spokenChars > 7000) {
            AlertDialog.Builder(this)
                .setTitle("Gemini 음성 한도 주의")
                .setMessage(
                    "대본이 ${"%,d".format(parsed.spokenChars)}자로 깁니다. Gemini 무료 음성은 하루 요청 수가 적어서 중간에 막힐 수 있어요. " +
                        "막히면 남은 부분은 자동으로 휴대폰 음성으로 다시 만듭니다.\n\n휴대폰 음성으로 바꿔서 만들까요?"
                )
                .setPositiveButton("휴대폰 음성으로") { _, _ ->
                    findViewById<RadioButton>(R.id.rbVoicePhone).isChecked = true
                    start(text, "android")
                }
                .setNeutralButton("Gemini로 계속") { _, _ -> start(text, "gemini") }
                .setNegativeButton("취소", null)
                .show()
            return
        }
        start(text, voice)
    }

    private fun start(text: String, voice: String) {
        saveDraft()
        val job = File(filesDir, "import_job.txt")
        job.writeText(text)
        lastShownResult = null
        val ok = GenerationService.startScript(this, job.absolutePath, etTitle.text?.toString()?.trim() ?: "", voice)
        if (!ok) {
            Ui.toast(this, GenerationService.lastScriptError ?: "시작하지 못했습니다.")
            return
        }
        watching = true
        btnListen.visibility = View.GONE
        tvJob.visibility = View.VISIBLE
        tvJob.text = "준비 중…"
    }

    private fun refreshJob() {
        if (GenerationService.isRunning && GenerationService.scriptMode) {
            watching = true
            btnMake.isEnabled = false
            tvJob.visibility = View.VISIBLE
            tvJob.text = GenerationService.progress.ifEmpty { "만드는 중…" }
            return
        }
        btnMake.isEnabled = true
        if (!watching) return
        val id = GenerationService.lastScriptEpisodeId
        val err = GenerationService.lastScriptError
        if (id != null) {
            val ep = EpisodeStore.get(this, id)
            val mins = if (ep != null) (ep.durationMs + 30_000) / 60_000 else 0
            val note = GenerationService.lastScriptNote
            tvJob.text = "완성! ${ep?.title ?: ""} · 약 ${mins}분" + if (note.isEmpty()) "" else "\n참고: $note"
            btnListen.visibility = View.VISIBLE
            if (lastShownResult != id) {
                lastShownResult = id
                AlertDialog.Builder(this)
                    .setTitle("읽어 주기 완성")
                    .setMessage("약 ${mins}분짜리 음성을 만들었어요. 에피소드 목록에도 들어 있어서 언제든 이어 들을 수 있어요.")
                    .setPositiveButton("지금 듣기") { _, _ -> btnListen.performClick() }
                    .setNeutralButton("대본 비우기") { _, _ ->
                        etScript.setText("")
                        etTitle.setText("")
                        saveDraft()
                    }
                    .setNegativeButton("나중에", null)
                    .show()
            }
        } else if (err != null) {
            tvJob.text = "실패: $err"
        }
    }
}
