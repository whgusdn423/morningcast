package com.morningcast.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** 코너(경제/교육/국제정세) 설정 */
class Segment(
    val key: String,
    var title: String,
    var enabled: Boolean,
    var minutes: Int,
    var instruction: String,
    var sources: String
) {
    fun toJson(): JSONObject = JSONObject()
        .put("key", key)
        .put("title", title)
        .put("enabled", enabled)
        .put("minutes", minutes)
        .put("instruction", instruction)
        .put("sources", sources)
}

/** 사용자 설정 전체. SharedPreferences 에 JSON 한 덩어리로 저장합니다. */
class Settings {
    var enabled = true
    var wakeHour = 6
    var wakeMinute = 30
    /** 요일 비트마스크: (Calendar.DAY_OF_WEEK - 1) 번째 비트. 일=0, 월=1 … 토=6 */
    var days = DEFAULT_DAYS
    var genHour = 21
    var genMinute = 0

    var scriptProvider = "gemini"   // gemini | claude
    var geminiKey = ""
    var geminiModel = DEFAULT_GEMINI_MODEL
    var claudeKey = ""
    var claudeModel = DEFAULT_CLAUDE_MODEL
    var useWebSearch = false

    var style = "duo"               // duo(2인 대화) | solo(1인)
    var host1 = "지수"
    var host2 = "민호"
    var listener = "중고등학교 수학 교사"

    var ttsProvider = "android"     // android | gemini
    var androidEngine = ""
    var androidVoice1 = ""
    var androidVoice2 = ""
    var speechRate = 1.0f
    var geminiTtsModel = DEFAULT_GEMINI_TTS_MODEL
    var geminiVoice1 = "Kore"
    var geminiVoice2 = "Charon"

    var useAlarmStream = true
    var fadeIn = true
    var playbackSpeed = 1.0f
    var keepEpisodes = 5

    var includePapers = true
    var journalIssns = DEFAULT_ISSNS

    var segments: MutableList<Segment> = defaultSegments()

    fun segment(key: String): Segment? = segments.firstOrNull { it.key == key }

    fun totalMinutes(): Int = segments.filter { it.enabled }.sumOf { it.minutes }

    fun toJson(): JSONObject {
        val arr = JSONArray()
        for (sg in segments) arr.put(sg.toJson())
        return JSONObject()
            .put("enabled", enabled)
            .put("wakeHour", wakeHour)
            .put("wakeMinute", wakeMinute)
            .put("days", days)
            .put("genHour", genHour)
            .put("genMinute", genMinute)
            .put("scriptProvider", scriptProvider)
            .put("geminiKey", geminiKey)
            .put("geminiModel", geminiModel)
            .put("claudeKey", claudeKey)
            .put("claudeModel", claudeModel)
            .put("useWebSearch", useWebSearch)
            .put("style", style)
            .put("host1", host1)
            .put("host2", host2)
            .put("listener", listener)
            .put("ttsProvider", ttsProvider)
            .put("androidEngine", androidEngine)
            .put("androidVoice1", androidVoice1)
            .put("androidVoice2", androidVoice2)
            .put("speechRate", speechRate.toDouble())
            .put("geminiTtsModel", geminiTtsModel)
            .put("geminiVoice1", geminiVoice1)
            .put("geminiVoice2", geminiVoice2)
            .put("useAlarmStream", useAlarmStream)
            .put("fadeIn", fadeIn)
            .put("playbackSpeed", playbackSpeed.toDouble())
            .put("keepEpisodes", keepEpisodes)
            .put("includePapers", includePapers)
            .put("journalIssns", journalIssns)
            .put("segments", arr)
    }

    companion object {
        /** 월~금 */
        const val DEFAULT_DAYS = 0b0111110
        const val DEFAULT_GEMINI_MODEL = "gemini-flash-latest"
        /** 기본 모델이 붐비거나(503) 한도(429)에 걸리면 차례로 시도. 무료 한도가 넉넉한 Flash-Lite 계열 */
        val GEMINI_FALLBACK_MODELS = listOf("gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-2.5-flash-lite")
        const val DEFAULT_CLAUDE_MODEL = "claude-sonnet-5-5"
        const val DEFAULT_GEMINI_TTS_MODEL = "gemini-3.8-flash-tts"

        /** 최신 수학교육 논문을 가져올 학술지 ISSN (Crossref 에서 확인한 값) */
        const val DEFAULT_ISSNS =
            "0013-1954, 1863-9690, 0021-8251, 1571-0068, 1386-4416, 1098-6065, 0732-3123, 1033-2170, 1479-4802, 0020-739X"

        const val ECON_INST =
            "최근 24시간의 국내외 경제 뉴스 가운데 중요한 소식 4~6개를 골라 전해 주세요. " +
                "금리·환율·주가·물가·부동산 같은 지표의 변화, 정부 정책, 주요 기업 소식을 다루고, " +
                "각 소식이 가계와 생활에 어떤 의미인지 한두 문장으로 쉽게 해설해 주세요."
        const val EDU_INST =
            "앞부분에서는 [최신 수학교육 논문] 목록에서 수업에 시사점이 큰 연구 2~3편을 골라 " +
                "연구 질문, 연구 방법, 핵심 결과, 교실 수업에 주는 시사점 순서로 쉽게 소개해 주세요. " +
                "학술지 이름과 발표 시기를 밝혀 주세요. 초록이 없는 논문은 제목에서 알 수 있는 범위만 말하고 내용을 지어내지 마세요. " +
                "뒷부분에서는 국내 교육 정책과 학교 현장 소식 2~3개를 전해 주세요."
        const val WORLD_INST =
            "최근 24~48시간의 주요 국제 뉴스 4~5개(미국, 중국, 일본, 유럽, 중동, 한반도 정세 등)를 골라 " +
                "사건의 개요와 배경, 앞으로 지켜볼 점, 한국에 미칠 영향을 짧게 해설해 주세요."

        const val ECON_SRC =
            "https://news.google.com/rss/headlines/section/topic/BUSINESS?hl=ko&gl=KR&ceid=KR:ko\n" +
                "https://www.segye.com/Articles/RSSList/segye_economy.xml"
        const val EDU_SRC = "교육부\n교육정책\n수학교육"
        const val WORLD_SRC =
            "https://news.google.com/rss/headlines/section/topic/WORLD?hl=ko&gl=KR&ceid=KR:ko\n" +
                "https://www.segye.com/Articles/RSSList/segye_international.xml"

        fun defaultSegments(): MutableList<Segment> = mutableListOf(
            Segment("economy", "경제", true, 10, ECON_INST, ECON_SRC),
            Segment("education", "교육", true, 10, EDU_INST, EDU_SRC),
            Segment("world", "국제정세", true, 10, WORLD_INST, WORLD_SRC)
        )

        private const val PREFS = "settings"
        private const val KEY = "json"

        fun load(ctx: Context): Settings {
            val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
                ?: return Settings()
            return try {
                fromJson(JSONObject(raw))
            } catch (e: Exception) {
                Settings()
            }
        }

        fun save(ctx: Context, s: Settings) {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY, s.toJson().toString())
                .apply()
        }

        fun fromJson(o: JSONObject): Settings {
            val s = Settings()
            s.enabled = o.optBoolean("enabled", s.enabled)
            s.wakeHour = o.optInt("wakeHour", s.wakeHour).coerceIn(0, 23)
            s.wakeMinute = o.optInt("wakeMinute", s.wakeMinute).coerceIn(0, 59)
            s.days = o.optInt("days", s.days) and 0x7F
            s.genHour = o.optInt("genHour", s.genHour).coerceIn(0, 23)
            s.genMinute = o.optInt("genMinute", s.genMinute).coerceIn(0, 59)
            s.scriptProvider = o.optString("scriptProvider", s.scriptProvider)
            s.geminiKey = o.optString("geminiKey", s.geminiKey)
            s.geminiModel = o.optString("geminiModel", s.geminiModel)
            s.claudeKey = o.optString("claudeKey", s.claudeKey)
            s.claudeModel = o.optString("claudeModel", s.claudeModel)
            s.useWebSearch = o.optBoolean("useWebSearch", s.useWebSearch)
            s.style = o.optString("style", s.style)
            s.host1 = o.optString("host1", s.host1)
            s.host2 = o.optString("host2", s.host2)
            s.listener = o.optString("listener", s.listener)
            s.ttsProvider = o.optString("ttsProvider", s.ttsProvider)
            s.androidEngine = o.optString("androidEngine", s.androidEngine)
            s.androidVoice1 = o.optString("androidVoice1", s.androidVoice1)
            s.androidVoice2 = o.optString("androidVoice2", s.androidVoice2)
            s.speechRate = o.optDouble("speechRate", s.speechRate.toDouble()).toFloat().coerceIn(0.5f, 2.0f)
            s.geminiTtsModel = o.optString("geminiTtsModel", s.geminiTtsModel)
            s.geminiVoice1 = o.optString("geminiVoice1", s.geminiVoice1)
            s.geminiVoice2 = o.optString("geminiVoice2", s.geminiVoice2)
            s.useAlarmStream = o.optBoolean("useAlarmStream", s.useAlarmStream)
            s.fadeIn = o.optBoolean("fadeIn", s.fadeIn)
            s.playbackSpeed = o.optDouble("playbackSpeed", s.playbackSpeed.toDouble()).toFloat().coerceIn(0.5f, 2.0f)
            s.keepEpisodes = o.optInt("keepEpisodes", s.keepEpisodes).coerceIn(1, 60)
            s.includePapers = o.optBoolean("includePapers", s.includePapers)
            s.journalIssns = o.optString("journalIssns", s.journalIssns)

            val defaults = defaultSegments()
            val arr = o.optJSONArray("segments")
            val loaded = ArrayList<Segment>()
            for (d in defaults) {
                var found: JSONObject? = null
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val so = arr.optJSONObject(i) ?: continue
                        if (so.optString("key") == d.key) {
                            found = so
                            break
                        }
                    }
                }
                if (found == null) {
                    loaded.add(d)
                } else {
                    loaded.add(
                        Segment(
                            d.key,
                            found.optString("title", d.title),
                            found.optBoolean("enabled", d.enabled),
                            found.optInt("minutes", d.minutes).coerceIn(1, 40),
                            found.optString("instruction", d.instruction),
                            found.optString("sources", d.sources)
                        )
                    )
                }
            }
            s.segments = loaded
            return s
        }
    }
}

/** 실행 상태(다음 알람 시각, 마지막 생성 결과 등) */
class AppState(ctx: Context) {
    private val p = ctx.getSharedPreferences("state", Context.MODE_PRIVATE)

    var nextPlayAt: Long
        get() = p.getLong("nextPlayAt", 0L)
        set(v) {
            p.edit().putLong("nextPlayAt", v).apply()
        }
    var nextGenAt: Long
        get() = p.getLong("nextGenAt", 0L)
        set(v) {
            p.edit().putLong("nextGenAt", v).apply()
        }
    var lastGenAt: Long
        get() = p.getLong("lastGenAt", 0L)
        set(v) {
            p.edit().putLong("lastGenAt", v).apply()
        }
    var lastGenOk: Boolean
        get() = p.getBoolean("lastGenOk", false)
        set(v) {
            p.edit().putBoolean("lastGenOk", v).apply()
        }
    var lastGenMsg: String
        get() = p.getString("lastGenMsg", "") ?: ""
        set(v) {
            p.edit().putString("lastGenMsg", v).apply()
        }
    var attemptTarget: String
        get() = p.getString("attemptTarget", "") ?: ""
        set(v) {
            p.edit().putString("attemptTarget", v).apply()
        }
    var attempts: Int
        get() = p.getInt("attempts", 0)
        set(v) {
            p.edit().putInt("attempts", v).apply()
        }
    var lastAttemptAt: Long
        get() = p.getLong("lastAttemptAt", 0L)
        set(v) {
            p.edit().putLong("lastAttemptAt", v).apply()
        }
    var lastPlayMsg: String
        get() = p.getString("lastPlayMsg", "") ?: ""
        set(v) {
            p.edit().putString("lastPlayMsg", v).apply()
        }
}
