package com.morningcast.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Source(val title: String, val url: String)

class Episode(
    val id: String,
    val dir: File,
    val targetDate: String,
    val createdAt: Long,
    val title: String,
    val audioName: String,
    val durationMs: Long,
    val segmentTitles: List<String>,
    val segmentStarts: List<Long>,
    val failed: List<String>,
    val info: String,
    val kind: String = KIND_MORNING
) {
    companion object {
        const val KIND_MORNING = "morning"
        const val KIND_SCRIPT = "script"
    }

    val isScript: Boolean get() = kind == KIND_SCRIPT
    val audioFile: File get() = File(dir, audioName)
    val scriptFile: File get() = File(dir, "script.txt")

    /** 재생 위치가 속한 코너 번호 (-1 = 오프닝) */
    fun segmentAt(posMs: Long): Int {
        var idx = -1
        for (i in segmentStarts.indices) if (posMs >= segmentStarts[i]) idx = i
        return idx
    }

    fun segmentLabel(posMs: Long): String {
        val i = segmentAt(posMs)
        return if (i < 0 || i >= segmentTitles.size) (if (isScript) "시작" else "오프닝") else segmentTitles[i]
    }
}

/** 에피소드 저장소: files/episodes/<id>/ 에 audio + script.txt + meta.json */
object EpisodeStore {
    private const val DAY = 24 * 3600_000L

    fun root(ctx: Context): File {
        val f = File(ctx.filesDir, "episodes")
        if (!f.exists()) f.mkdirs()
        return f
    }

    fun list(ctx: Context): List<Episode> {
        val dirs = root(ctx).listFiles() ?: return emptyList()
        return dirs.mapNotNull { load(it) }.sortedByDescending { it.createdAt }
    }

    fun load(dir: File): Episode? = try {
        val meta = File(dir, "meta.json")
        if (!meta.exists()) null else parse(dir, JSONObject(meta.readText()))
    } catch (e: Exception) {
        null
    }

    fun get(ctx: Context, id: String): Episode? = load(File(root(ctx), id))

    /** 가장 최근 아침 방송 (읽어 주기 에피소드 제외) */
    fun latest(ctx: Context): Episode? = list(ctx).firstOrNull { !it.isScript && it.audioFile.exists() }

    fun hasFreshEpisodeFor(ctx: Context, playAt: Long, genAt: Long): Boolean {
        val key = Scheduler.dateKey(playAt)
        return list(ctx).any {
            !it.isScript && it.targetDate == key && it.createdAt >= genAt - 2 * 3600_000L && it.audioFile.exists()
        }
    }

    /** 예약 재생 때 고를 에피소드: 오늘 날짜용 → 없으면 24시간 이내 생성분 */
    fun pickForPlayback(ctx: Context, now: Long): Episode? {
        val today = Scheduler.dateKey(now)
        val all = list(ctx).filter { !it.isScript && it.audioFile.exists() }
        return all.firstOrNull { it.targetDate == today } ?: all.firstOrNull { now - it.createdAt < DAY }
    }

    fun newEpisodeDir(ctx: Context): File {
        val id = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val d = File(root(ctx), id)
        d.mkdirs()
        return d
    }

    fun writeMeta(
        dir: File,
        targetDate: String,
        title: String,
        audioName: String,
        durationMs: Long,
        segTitles: List<String>,
        segStarts: List<Long>,
        failed: List<String>,
        info: String,
        covered: Map<String, List<String>>,
        kind: String = Episode.KIND_MORNING
    ): Episode {
        val o = JSONObject()
            .put("id", dir.name)
            .put("targetDate", targetDate)
            .put("createdAt", System.currentTimeMillis())
            .put("title", title)
            .put("audio", audioName)
            .put("durationMs", durationMs)
            .put("segmentTitles", JSONArray(segTitles))
            .put("segmentStarts", JSONArray(segStarts))
            .put("failed", JSONArray(failed))
            .put("info", info)
            .put("kind", kind)
        val cov = JSONObject()
        for ((k, v) in covered) cov.put(k, JSONArray(v))
        o.put("covered", cov)
        File(dir, "meta.json").writeText(o.toString())
        return parse(dir, o)
    }

    private fun parse(dir: File, o: JSONObject): Episode {
        val titles = ArrayList<String>()
        val ta = o.optJSONArray("segmentTitles")
        if (ta != null) for (i in 0 until ta.length()) titles.add(ta.optString(i))
        val starts = ArrayList<Long>()
        val sa = o.optJSONArray("segmentStarts")
        if (sa != null) for (i in 0 until sa.length()) starts.add(sa.optLong(i))
        val failed = ArrayList<String>()
        val fa = o.optJSONArray("failed")
        if (fa != null) for (i in 0 until fa.length()) failed.add(fa.optString(i))
        return Episode(
            id = o.optString("id", dir.name),
            dir = dir,
            targetDate = o.optString("targetDate"),
            createdAt = o.optLong("createdAt"),
            title = o.optString("title", dir.name),
            audioName = o.optString("audio", "audio.m4a"),
            durationMs = o.optLong("durationMs"),
            segmentTitles = titles,
            segmentStarts = starts,
            failed = failed,
            info = o.optString("info"),
            kind = o.optString("kind", Episode.KIND_MORNING)
        )
    }

    fun delete(ep: Episode) {
        ep.dir.deleteRecursively()
    }

    /** 아침 방송만 개수 제한 (읽어 주기 에피소드는 따로 관리) */
    fun prune(ctx: Context, keep: Int) = pruneKind(ctx, Episode.KIND_MORNING, keep)

    fun pruneKind(ctx: Context, kind: String, keep: Int) {
        val all = list(ctx).filter { it.kind == kind }
        if (all.size <= keep) return
        for (ep in all.drop(keep)) delete(ep)
    }

    // ── 이어 듣기 위치 ───────────────────────────────────────────────

    private fun posPrefs(ctx: Context) = ctx.getSharedPreferences("positions", Context.MODE_PRIVATE)

    fun savePosition(ctx: Context, id: String, posMs: Long) {
        try {
            posPrefs(ctx).edit().putLong(id, posMs).apply()
        } catch (_: Exception) {
        }
    }

    fun loadPosition(ctx: Context, id: String): Long = try {
        posPrefs(ctx).getLong(id, 0L)
    } catch (_: Exception) {
        0L
    }

    /** 이어 들을 위치 (끝 무렵이거나 처음 몇 초면 0) */
    fun resumePosition(ctx: Context, ep: Episode): Long {
        val p = loadPosition(ctx, ep.id)
        return if (p < 10_000L || p > ep.durationMs - 20_000L) 0L else p
    }

    /** 최근 며칠 동안 다룬 항목(코너별) — 같은 소식 반복을 줄이기 위해 프롬프트에 넣습니다. */
    fun recentCovered(ctx: Context, days: Int): Map<String, List<String>> {
        val since = System.currentTimeMillis() - days * DAY
        val map = HashMap<String, MutableList<String>>()
        for (ep in list(ctx)) {
            if (ep.createdAt < since) continue
            try {
                val o = JSONObject(File(ep.dir, "meta.json").readText())
                val cov = o.optJSONObject("covered") ?: continue
                val keys = cov.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val arr = cov.optJSONArray(k) ?: continue
                    val list = map.getOrPut(k) { ArrayList() }
                    for (i in 0 until arr.length()) {
                        val item = arr.optString(i).trim()
                        if (item.isNotEmpty() && !list.contains(item)) list.add(item)
                    }
                }
            } catch (_: Exception) {
            }
        }
        return map
    }

    // ── 이미 소개한 논문 DOI 기록 (같은 논문 반복 방지) ─────────────────────────

    private fun doiFile(ctx: Context) = File(ctx.filesDir, "covered_dois.txt")

    fun loadCoveredDois(ctx: Context): Set<String> {
        val f = doiFile(ctx)
        if (!f.exists()) return emptySet()
        val cutoff = Scheduler.dateKey(System.currentTimeMillis() - 150 * DAY)
        val out = HashSet<String>()
        try {
            f.readLines().forEach { line ->
                val parts = line.split('\t')
                if (parts.size == 2 && parts[0] >= cutoff) out.add(parts[1].lowercase())
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun addCoveredDois(ctx: Context, dois: Collection<String>) {
        if (dois.isEmpty()) return
        val today = Scheduler.dateKey(System.currentTimeMillis())
        val f = doiFile(ctx)
        try {
            val sb = StringBuilder()
            for (d in dois) sb.append(today).append('\t').append(d.lowercase()).append('\n')
            f.appendText(sb.toString())
            val lines = f.readLines()
            if (lines.size > 1500) f.writeText(lines.takeLast(800).joinToString("\n") + "\n")
        } catch (_: Exception) {
        }
    }

    private val DOI_RE = Regex("10\\.\\d{4,9}/[^\\s|,;\"'<>]+")

    fun extractDois(text: String): List<String> =
        DOI_RE.findAll(text).map { it.value.trimEnd('.', ')', ']') }.toList()
}
