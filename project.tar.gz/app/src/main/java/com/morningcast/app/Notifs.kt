package com.morningcast.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object Notifs {
    const val CH_ALARM = "alarm"
    const val CH_PLAYBACK = "playback"
    const val CH_GEN = "generate"
    const val CH_STATUS = "status"

    const val ID_GEN = 10
    const val ID_PLAY = 11
    const val ID_STATUS = 12

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val alarm = NotificationChannel(CH_ALARM, "아침 브리핑 알람", NotificationManager.IMPORTANCE_HIGH)
        alarm.description = "설정한 시간에 팟캐스트 재생을 시작할 때 표시됩니다."
        alarm.setSound(null, null)
        alarm.enableVibration(false)
        alarm.lockscreenVisibility = Notification.VISIBILITY_PUBLIC

        val playback = NotificationChannel(CH_PLAYBACK, "재생 컨트롤", NotificationManager.IMPORTANCE_LOW)
        playback.setSound(null, null)
        playback.lockscreenVisibility = Notification.VISIBILITY_PUBLIC

        val gen = NotificationChannel(CH_GEN, "팟캐스트 만드는 중", NotificationManager.IMPORTANCE_LOW)
        gen.setSound(null, null)

        val status = NotificationChannel(CH_STATUS, "생성 결과 알림", NotificationManager.IMPORTANCE_DEFAULT)

        nm.createNotificationChannels(listOf(alarm, playback, gen, status))
    }

    fun mainPendingIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(
            ctx, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    fun activityPendingIntent(ctx: Context, target: Class<*>): PendingIntent {
        val i = Intent(ctx, target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(
            ctx, 7, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    fun progressNotification(ctx: Context, text: String, title: String = "모닝캐스트 만드는 중"): Notification {
        ensureChannels(ctx)
        return Notification.Builder(ctx, CH_GEN)
            .setSmallIcon(R.drawable.ic_stat_podcast)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(0, 0, true)
            .setContentIntent(mainPendingIntent(ctx))
            .build()
    }

    fun showStatus(ctx: Context, title: String, text: String, target: Class<*>? = null) {
        try {
            ensureChannels(ctx)
            val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
            if (!nm.areNotificationsEnabled()) return
            val n = Notification.Builder(ctx, CH_STATUS)
                .setSmallIcon(R.drawable.ic_stat_podcast)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(if (target == null) mainPendingIntent(ctx) else activityPendingIntent(ctx, target))
                .build()
            nm.notify(ID_STATUS, n)
        } catch (e: Exception) {
            AppLog.error(ctx, "알림 표시 실패", e)
        }
    }
}
