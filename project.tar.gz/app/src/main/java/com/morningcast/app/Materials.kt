package com.morningcast.app

import android.content.Context
import android.text.Html
import android.util.Xml
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

class NewsItem(val title: String, val source: String, val date: Long, val summary: String, val link: String)

class Paper(
    val journal: String,
    val title: String,
    val authors: String,
    val date: String,
    val doi: String,
    val abstract: String
)

class MaterialPack(val text: String, val sources: List<Source>, val newsCount: Int, val paperCount: Int) {
    val isEmpty: Boolean get() = newsCount == 0 && paperCount == 0
}

/**
 * 코너별 자료 수집:
 *  - 뉴스: RSS 주소 또는 검색어(→ Google 뉴스 RSS) 목록
 *  - 교육 코너: Crossref 에서 수학교육 학술지 최신 논문
 * 이렇게 모은 '사실 자료'를 AI 에게 주면, 무료 등급에서도 최신 내용을 다룰 수 있고 지어내는 내용도 줄어듭니다.
 */
object Materials {
    private const val HOUR = 3600_000L
    private const val PER_FEED = 15
    private const val MAX_NEWS = 28
    private const val NEWS_CHAR_BUDGET = 7000

    fun collect(ctx: Context, s: Settings, seg: Segment, coveredDois: Set<String>): MaterialPack {
        val isEdu = seg.key == "education"
        val maxAgeH = if (isEdu) 120 else 48
        val now = System.currentTimeMillis()
        val all = ArrayList<NewsItem>()
        val lines = seg.sources.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
        for (line in lines) {
            val url = if (line.startsWith("http://") || line.startsWith("https://")) {
                line
            } else {
                googleNewsSearchUrl(line, if (isEdu) 5 else 2)
            }
            try {
                val items = fetchFeed(url)
                AppLog.log(ctx, "RSS ${items.size}건: ${shortUrl(line)}")
                all.addAll(items.take(PER_FEED))
            } catch (e: Exception) {
                AppLog.log(ctx, "RSS 실패(${shortUrl(line)}): ${e.message}")
            }
        }
        // 중복 제거 + 최신순
        val seen = HashSet<String>()
        val unique = ArrayList<NewsItem>()
        for (item in all.sortedByDescending { n -> n.date }) {
            val key = normTitle(item.title)
            if (key.length < 4 || !seen.add(key)) continue
            unique.add(item)
        }
        var recent = unique.filter { it.date == 0L || now - it.date <= maxAgeH * HOUR }
        if (recent.size < 5) recent = unique
        val news = recent.take(MAX_NEWS)

        val papers = if (isEdu && s.includePapers) {
            try {
                fetchPapers(ctx, s.journalIssns, coveredDois)
            } catch (e: Exception) {
                AppLog.log(ctx, "논문 목록(Crossref) 실패: ${e.message}")
                emptyList()
            }
        } else {
            emptyList()
        }
        return build(news, papers)
    }

    private fun build(news: List<NewsItem>, papers: List<Paper>): MaterialPack {
        val sb = StringBuilder()
        val sources = ArrayList<Source>()
        if (news.isNotEmpty()) {
            sb.append("■ 뉴스 (최근 순)\n")
            val df = SimpleDateFormat("M/d HH:mm", Locale.KOREA)
            var used = 0
            for ((i, n) in news.withIndex()) {
                val head = StringBuilder()
                head.append(i + 1).append(". [")
                if (n.source.isNotEmpty()) head.append(n.source).append(" · ")
                head.append(if (n.date > 0) df.format(java.util.Date(n.date)) else "날짜 미상").append("] ")
                head.append(n.title).append('\n')
                val summary = n.summary.take(260)
                if (summary.isNotEmpty() && !n.title.contains(summary.take(20))) {
                    head.append("   요약: ").append(summary).append('\n')
                }
                if (used + head.length > NEWS_CHAR_BUDGET) break
                sb.append(head)
                used += head.length
                if (n.link.isNotEmpty()) sources.add(Source(n.title, n.link))
            }
            sb.append('\n')
        }
        if (papers.isNotEmpty()) {
            sb.append("■ 최신 수학교육 논문 (Crossref 학술지 목록)\n")
            for ((i, p) in papers.withIndex()) {
                sb.append(i + 1).append(". ").append(p.journal).append(" · ").append(p.date).append('\n')
                sb.append("   제목: ").append(p.title).append('\n')
                if (p.authors.isNotEmpty()) sb.append("   저자: ").append(p.authors).append('\n')
                sb.append("   DOI: ").append(p.doi).append('\n')
                if (p.abstract.isNotEmpty()) {
                    sb.append("   초록: ").append(p.abstract).append('\n')
                } else {
                    sb.append("   초록: (없음 — 제목 수준에서만 언급)\n")
                }
                sources.add(Source("${p.journal} — ${p.title}", "https://doi.org/${p.doi}"))
            }
        }
        if (sb.isEmpty()) sb.append("(수집된 자료가 없습니다)")
        return MaterialPack(sb.toString().trim(), sources, news.size, papers.size)
    }

    fun googleNewsSearchUrl(keyword: String, days: Int): String {
        val q = URLEncoder.encode("$keyword when:${days}d", "UTF-8")
        return "https://news.google.com/rss/search?q=$q&hl=ko&gl=KR&ceid=KR:ko"
    }

    private fun shortUrl(u: String): String = if (u.length > 60) u.take(57) + "…" else u

    private fun normTitle(t: String): String {
        val base = t.substringBeforeLast(" - ").ifEmpty { t }
        return base.replace(Regex("[\\s\\p{Punct}“”‘’·…]+"), "").lowercase()
    }

    // ── RSS / Atom ───────────────────────────────────────────────────────────

    fun fetchFeed(url: String): List<NewsItem> {
        val resp = Http.get(
            url,
            mapOf("Accept" to "application/rss+xml, application/atom+xml, application/xml, text/xml, */*")
        )
        if (resp.code != 200) throw Exception("HTTP ${resp.code}")
        return parseFeed(resp.body)
    }

    fun parseFeed(bytes: ByteArray): List<NewsItem> {
        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(ByteArrayInputStream(bytes), null)
        val out = ArrayList<NewsItem>()
        var inItem = false
        var title = ""
        var link = ""
        var desc = ""
        var date = ""
        var source = ""
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                val name = (parser.name ?: "").lowercase()
                if (name == "item" || name == "entry") {
                    inItem = true
                    title = ""; link = ""; desc = ""; date = ""; source = ""
                } else if (inItem) {
                    when (name) {
                        "title" -> title = readAllText(parser)
                        "link" -> {
                            val href = parser.getAttributeValue(null, "href")
                            if (href != null) {
                                val rel = parser.getAttributeValue(null, "rel")
                                if (link.isEmpty() && (rel == null || rel == "alternate")) link = href
                            } else {
                                val t = readAllText(parser).trim()
                                if (link.isEmpty()) link = t
                            }
                        }
                        "description", "summary" -> {
                            val t = readAllText(parser)
                            if (desc.isEmpty()) desc = t
                        }
                        "content", "content:encoded" -> {
                            val t = readAllText(parser)
                            if (desc.isEmpty()) desc = t
                        }
                        "pubdate", "published", "updated", "dc:date" -> {
                            val t = readAllText(parser)
                            if (date.isEmpty()) date = t
                        }
                        "source" -> source = readAllText(parser)
                    }
                }
            } else if (event == XmlPullParser.END_TAG) {
                val name = (parser.name ?: "").lowercase()
                if ((name == "item" || name == "entry") && inItem) {
                    inItem = false
                    val cleanTitle = cleanText(title)
                    if (cleanTitle.isNotEmpty()) {
                        var src = cleanText(source)
                        var shownTitle = cleanTitle
                        val dash = cleanTitle.lastIndexOf(" - ")
                        if (dash > 0 && cleanTitle.length - dash < 30) {
                            if (src.isEmpty()) src = cleanTitle.substring(dash + 3).trim()
                            shownTitle = cleanTitle.substring(0, dash).trim()
                        }
                        out.add(NewsItem(shownTitle, src, parseDate(date), cleanText(desc), link.trim()))
                    }
                }
            }
            event = parser.next()
        }
        return out
    }

    /** 현재 START_TAG 의 안쪽 텍스트를 모두 읽고 해당 END_TAG 까지 이동합니다(중첩 태그 허용). */
    private fun readAllText(p: XmlPullParser): String {
        val sb = StringBuilder()
        var depth = 1
        while (depth > 0) {
            when (p.next()) {
                XmlPullParser.START_TAG -> depth++
                XmlPullParser.END_TAG -> depth--
                XmlPullParser.TEXT -> sb.append(p.text ?: "")
                XmlPullParser.END_DOCUMENT -> return sb.toString()
            }
        }
        return sb.toString()
    }

    /** HTML 태그·엔티티 제거 + 공백 정리 */
    fun cleanText(raw: String): String {
        if (raw.isBlank()) return ""
        val noHtml = if (raw.contains('<') || raw.contains('&')) {
            Html.fromHtml(raw, Html.FROM_HTML_MODE_LEGACY).toString()
        } else {
            raw
        }
        return noHtml.replace('￼', ' ').replace(' ', ' ').replace(Regex("\\s+"), " ").trim()
    }

    private val DATE_PATTERNS = listOf(
        "EEE, dd MMM yyyy HH:mm:ss Z",
        "EEE, d MMM yyyy HH:mm:ss Z",
        "EEE, dd MMM yyyy HH:mm:ss zzz",
        "EEE, dd MMM yyyy HH:mm Z",
        "dd MMM yyyy HH:mm:ss Z",
        "yyyy-MM-dd'T'HH:mm:ssXXX",
        "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
        "yyyy-MM-dd HH:mm:ss",
        "yyyy-MM-dd"
    )

    fun parseDate(raw: String): Long {
        if (raw.isBlank()) return 0L
        var s = raw.trim().replace(Regex(",(?=\\S)"), ", ").replace(Regex("\\s+"), " ")
        if (s.endsWith("Z") && s.contains('T')) s = s.dropLast(1) + "+00:00"
        for (p in DATE_PATTERNS) {
            try {
                val f = SimpleDateFormat(p, Locale.ENGLISH)
                if (!p.contains('Z') && !p.contains('X') && !p.contains('z')) f.timeZone = TimeZone.getTimeZone("Asia/Seoul")
                val d = f.parse(s)
                if (d != null) return d.time
            } catch (_: Exception) {
            }
        }
        return 0L
    }

    // ── Crossref: 수학교육 학술지 최신 논문 ───────────────────────────────────

    fun fetchPapers(ctx: Context, issnText: String, covered: Set<String>): List<Paper> {
        val issns = issnText.split(',', ' ', '\n', ';').map { it.trim() }
            .filter { it.matches(Regex("\\d{4}-\\d{3}[\\dXx]")) }
        if (issns.isEmpty()) return emptyList()
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -40)
        val from = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
        val filter = issns.joinToString(",") { "issn:$it" } + ",from-pub-date:$from,type:journal-article"
        val url = "https://api.crossref.org/works?filter=$filter&sort=published&order=desc&rows=50" +
            "&select=DOI,title,container-title,author,published,abstract"
        val resp = Http.get(url, mapOf("Accept" to "application/json"), 30_000)
        if (resp.code != 200) throw Exception("HTTP ${resp.code}")
        val papers = parseCrossref(resp.text, covered)
        AppLog.log(ctx, "Crossref 논문 ${papers.size}편 (초록 있음 ${papers.count { it.abstract.isNotEmpty() }})")
        return papers
    }

    fun parseCrossref(text: String, covered: Set<String>): List<Paper> {
        val items = JSONObject(text).optJSONObject("message")?.optJSONArray("items")
            ?: return emptyList()
        val withAbs = ArrayList<Paper>()
        val noAbs = ArrayList<Paper>()
        for (i in 0 until items.length()) {
            val w = items.optJSONObject(i) ?: continue
            val doi = w.optString("DOI")
            if (doi.isEmpty() || covered.contains(doi.lowercase())) continue
            val title = cleanText(w.optJSONArray("title")?.optString(0) ?: "")
            if (title.isEmpty()) continue
            val journal = w.optJSONArray("container-title")?.optString(0) ?: ""
            val authorsArr = w.optJSONArray("author")
            val names = ArrayList<String>()
            if (authorsArr != null) {
                for (j in 0 until minOf(authorsArr.length(), 3)) {
                    val a = authorsArr.optJSONObject(j) ?: continue
                    val n = listOf(a.optString("given"), a.optString("family")).filter { x -> x.isNotEmpty() }
                        .joinToString(" ").ifEmpty { a.optString("name") }
                    if (n.isNotEmpty()) names.add(n)
                }
                if (authorsArr.length() > 3) names.add("외")
            }
            val dp = w.optJSONObject("published")?.optJSONArray("date-parts")?.optJSONArray(0)
            val date = if (dp != null) {
                (0 until dp.length()).joinToString("-") { k -> dp.optInt(k).toString().padStart(2, '0') }
            } else {
                ""
            }
            val abs = cleanAbstract(w.optString("abstract"))
            val p = Paper(journal, title, names.joinToString(", "), date, doi, abs.take(900))
            if (abs.length > 80) withAbs.add(p) else noAbs.add(p)
        }
        return withAbs.take(7) + noAbs.take(5)
    }

    private fun cleanAbstract(jats: String): String {
        if (jats.isBlank()) return ""
        val noTitle = jats.replace(Regex("<jats:title>.*?</jats:title>", RegexOption.DOT_MATCHES_ALL), " ")
        val stripped = noTitle.replace(Regex("<[^>]+>"), " ")
        return cleanText(stripped)
    }
}
