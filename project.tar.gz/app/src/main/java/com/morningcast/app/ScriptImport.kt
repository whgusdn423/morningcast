package com.morningcast.app

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 붙여 넣은 대본(Claude 등에서 받은 글)을 말하기 단위로 바꿉니다.
 * - "지수: …", "**민호:** …" 처럼 이름이 붙은 줄 → 두 목소리
 * - "## 1부. 제목", "**2부: 제목**" → 소제목(효과음 + '다음 코너'로 건너뛰기)
 * - 표·목록 기호·링크·이모지·(웃음) 같은 지시문·AI 인사말은 빼고 읽음
 */
object ScriptParser {

    class Parsed(
        val title: String,
        val utts: List<Utterance>,
        val chapters: List<String>,
        val speakers: List<String>,
        val spokenChars: Int,
        val cleanText: String
    ) {
        /** 휴대폰 음성 기준 대략적인 길이(분) */
        fun estimatedMinutes(rate: Float = 1.0f): Int =
            Math.round(spokenChars / (ScriptWriter.CHARS_PER_MIN * rate.coerceIn(0.5f, 2f))).coerceAtLeast(if (spokenChars > 0) 1 else 0)
    }

    private const val NAME = "[가-힣A-Za-z][가-힣A-Za-z ]{0,9}"
    private val SPEAKER_RE = Regex("^\\s*(?:[-•]\\s*)?[*_]{0,2}\\s*\\[?($NAME)]?\\s*[*_]{0,2}\\s*[:：]\\s*[*_]{0,2}\\s*(.*)$")
    private val MD_HEADING_RE = Regex("^\\s*(#{1,6})\\s*(.+?)\\s*#*\\s*$")
    private val BOLD_LINE_RE = Regex("^\\s*(\\*\\*|__)(.{1,60}?)(\\*\\*|__)\\s*$")
    private val PART_RE = Regex("^\\s*[\\[(【]?\\s*(제?\\s*\\d{1,2}\\s*부|PART\\s*\\d+|Part\\s*\\d+|오프닝|인트로|클로징|마무리|에필로그|프롤로그)\\s*[\\])】]?\\s*([.:：\\-–—)]\\s*.*)?$")
    private val TITLE_RE = Regex("^\\s*(제목|타이틀|Title)\\s*[:：]\\s*(.+)$", RegexOption.IGNORE_CASE)
    private val SEPARATOR_RE = Regex("^\\s*([-*_=━─~·•]\\s*){3,}$")
    private val FENCE_RE = Regex("^\\s*```.*$")
    private val TABLE_RE = Regex("^\\s*\\|.*\\|\\s*$")
    private val DIRECTION_LINE_RE = Regex("^\\s*[*_]*\\s*[(\\[【][^)\\]】]{0,40}[)\\]】]\\s*[*_]*\\s*$")
    private val INLINE_DIRECTION_RE = Regex("[(\\[](?:[^)\\]]{0,12})?(웃음|웃으며|웃는|미소|박수|잠시|침묵|한숨|음악|효과음|BGM|bgm|사운드|멈춤|강조|놀라며|감탄)(?:[^)\\]]{0,12})?[)\\]]")
    private val META_RE = Regex("(이어서|계속|다음\\s*부분|나머지).{0,20}(드릴까요|할까요|쓸까요|원하시면|말씀해)|대본(을|입니다|이에요|을 작성)|요청하신|작성해\\s*드렸|도움이 되(었|셨)으면|^네[,!. ]|^물론")

    /** 사람 이름처럼 보이지 않는 말머리(오탐 방지) */
    private val NOT_NAMES = setOf(
        "참고", "핵심", "요약", "정리", "주의", "예시", "예", "결론", "질문", "답", "답변", "포인트", "팁", "주제", "배경",
        "제목", "부제", "출처", "링크", "주의사항", "목표", "효과음", "음악", "BGM", "Note", "Tip", "참고자료", "사례", "정의"
    )

    fun parse(raw: String, titleHint: String = ""): Parsed {
        val lines = raw.replace("\r\n", "\n").replace(' ', ' ').split('\n')

        // 1) 화자 후보: 3번 이상 등장하는 이름만 인정 (짧은 대본은 2번)
        val counts = LinkedHashMap<String, Int>()
        for (l in lines) {
            if (isHeading(l) != null) continue
            val m = SPEAKER_RE.find(l) ?: continue
            val name = m.groupValues[1].trim()
            if (!plausibleName(name)) continue
            counts[name] = (counts[name] ?: 0) + 1
        }
        val minCount = if (lines.size < 25) 2 else 3
        val speakers = counts.filter { it.value >= minCount }.keys.toList()
        val duo = speakers.size >= 2   // 이름이 하나뿐이면 한 목소리로 읽고 이름표만 뗌

        var title = ""
        val chapters = ArrayList<String>()
        val out = ArrayList<Utterance>()
        val clean = StringBuilder()
        var seg = -1
        var speaker = 0
        var curName = ""
        var started = false     // 첫 대사가 나오기 전의 AI 인사말은 버림
        val buf = StringBuilder()
        var spoken = 0

        fun flush() {
            val t = tidy(buf.toString())
            buf.setLength(0)
            if (t.isEmpty()) return
            for (p in Speech.split(t, 1200)) {
                out.add(Utterance(speaker, p, seg, pauseAfterMs = if (duo) 300 else 450))
                spoken += p.length
            }
            if (duo) clean.append(curName).append(": ")
            clean.append(t).append("\n")
        }

        for (rawLine in lines) {
            val line = rawLine.trimEnd()
            if (line.isBlank()) {
                if (!duo) flush()   // 한 목소리: 문단마다 끊어 읽기
                continue
            }
            if (FENCE_RE.matches(line) || SEPARATOR_RE.matches(line) || TABLE_RE.matches(line)) continue
            val tm = TITLE_RE.find(line)
            if (tm != null && title.isEmpty() && !started) {
                title = tidy(tm.groupValues[2])
                continue
            }
            val heading = isHeading(line)
            if (heading != null) {
                val h = tidy(heading.second)
                if (h.isEmpty()) continue
                if (heading.first == 1 && title.isEmpty() && !started && chapters.isEmpty()) {
                    title = h
                    continue
                }
                flush()
                chapters.add(h)
                seg = chapters.size - 1
                out.add(Utterance(0, "", seg, chime = true, pauseAfterMs = 0))
                clean.append("\n━━━━ ").append(h).append(" ━━━━\n")
                if (!duo) started = true
                continue
            }
            if (DIRECTION_LINE_RE.matches(line)) continue

            if (duo) {
                val m = SPEAKER_RE.find(line)
                val name = m?.groupValues?.get(1)?.trim()
                if (m != null && name != null && speakers.contains(name)) {
                    flush()
                    started = true
                    curName = name
                    speaker = speakers.indexOf(name) % 2
                    buf.append(m.groupValues[2])
                } else {
                    // 이름 없는 줄: 대사 이어짐. 첫 대사 전이거나 AI 안내문이면 버림
                    if (!started || META_RE.containsMatchIn(line.trim())) continue
                    buf.append(' ').append(line.trim())
                }
            } else {
                if (!started && META_RE.containsMatchIn(line.trim())) continue
                if (META_RE.containsMatchIn(line.trim()) && line.trim().endsWith("?")) continue
                started = true
                val m = SPEAKER_RE.find(line)
                val body = if (m != null && speakers.contains(m.groupValues[1].trim())) m.groupValues[2] else line.trim()
                buf.append(' ').append(body)
            }
        }
        flush()

        if (title.isEmpty()) title = titleHint.trim()
        val usedSpeakers = if (duo) speakers.take(2) else emptyList()
        return Parsed(title, out, chapters, usedSpeakers, spoken, clean.toString().trim())
    }

    /** (레벨, 제목) — 소제목 줄이 아니면 null */
    private fun isHeading(line: String): Pair<Int, String>? {
        MD_HEADING_RE.find(line)?.let { return Pair(it.groupValues[1].length, it.groupValues[2]) }
        val b = BOLD_LINE_RE.find(line)
        if (b != null) {
            val inner = b.groupValues[2].trim()
            // "**지수:**" 처럼 이름표만 굵게 한 줄은 소제목이 아님
            if (!inner.endsWith(":") && !inner.endsWith("：")) return Pair(2, inner)
        }
        if (line.length <= 50 && PART_RE.matches(line) && !line.trim().endsWith("?")) {
            return Pair(2, line.trim().trim('[', ']', '(', ')', '【', '】'))
        }
        return null
    }

    private fun plausibleName(n: String): Boolean {
        if (n.isEmpty() || n.length > 10) return false
        if (NOT_NAMES.contains(n)) return false
        if (n.count { it == ' ' } > 1) return false
        return true
    }

    /** 한 대사 정리: 마크다운·링크·이모지·지시문 제거 */
    private fun tidy(s: String): String {
        var t = INLINE_DIRECTION_RE.replace(s, " ")
        t = t.replace(Regex("\\*([^*\\n]{1,80})\\*"), "$1")   // *기울임*
        t = Speech.sanitize(t)
        t = t.replace('\n', ' ').replace(Regex("\\s{2,}"), " ").trim()
        return t
    }
}

/** 붙여 넣은 대본 → 음성 파일(에피소드) */
class ScriptEpisodeBuilder(
    private val ctx: Context,
    private val text: String,
    private val titleHint: String,
    private val voice: String,          // "android" | "gemini"
    private val progress: (String) -> Unit
) {
    class Result(val episode: Episode, val warnings: List<String>)

    fun run(): Result {
        val parsed = ScriptParser.parse(text, titleHint)
        if (parsed.utts.none { !it.chime }) throw ConfigException("읽을 내용이 없습니다. 대본을 붙여 넣었는지 확인해 주세요.")
        val s = Settings.load(ctx)
        // 이 대본에 맞게 목소리 구성만 바꿈(저장하지 않음)
        s.style = if (parsed.speakers.size >= 2) "duo" else "solo"
        val warnings = ArrayList<String>()
        val title = parsed.title.ifEmpty {
            "읽어 주기 · " + SimpleDateFormat("M월 d일 HH:mm", Locale.KOREAN).format(Date())
        }
        AppLog.log(
            ctx, "대본 읽어 주기 시작: $title · ${parsed.spokenChars}자 · 진행자 ${parsed.speakers.size}명 · 소제목 ${parsed.chapters.size}개 · 음성=$voice"
        )

        val pcmFile = File(ctx.cacheDir, "script_episode.pcm")
        val starts = HashMap<Int, Long>()
        var ttsLabel = "휴대폰 음성"
        var durationMs: Long
        if (voice == "gemini" && s.geminiKey.isNotBlank()) {
            try {
                progress("고품질 음성 만드는 중")
                durationMs = synth(GeminiTtsSynth(ctx, s)::synthesize, parsed.utts, pcmFile, starts)
                ttsLabel = "Gemini 음성 (${s.geminiTtsModel})"
            } catch (e: Exception) {
                AppLog.error(ctx, "Gemini 음성 실패 → 휴대폰 음성으로 대체", e)
                warnings.add("Gemini 음성 실패로 휴대폰 음성을 사용했습니다 (${e.message})")
                starts.clear()
                progress("휴대폰 음성으로 다시 만드는 중")
                durationMs = synth(AndroidTtsSynth(ctx, s)::synthesize, parsed.utts, pcmFile, starts)
            }
        } else {
            if (voice == "gemini") warnings.add("Gemini API 키가 없어 휴대폰 음성으로 만들었습니다")
            progress("음성 만드는 중")
            durationMs = synth(AndroidTtsSynth(ctx, s)::synthesize, parsed.utts, pcmFile, starts)
        }

        progress("오디오 파일 저장 중")
        val dir = EpisodeStore.newEpisodeDir(ctx)
        val created = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREA).format(Date())
        val who = if (parsed.speakers.size >= 2) "진행자 ${parsed.speakers.joinToString(", ")}" else "한 목소리"
        val info = "만든 시각: $created · 붙여 넣은 대본 · $who · 음성: $ttsLabel"
        val audioName = AudioFinalizer.finalize(pcmFile, dir, 24000, durationMs) { msg -> AppLog.log(ctx, msg) }
        pcmFile.delete()
        File(ctx.cacheDir, "tts").deleteRecursively()
        File(dir, "script.txt").writeText("$title\n$info\n\n${parsed.cleanText}\n")
        val segStarts = parsed.chapters.indices.map { starts[it] ?: 0L }
        val ep = EpisodeStore.writeMeta(
            dir, "", title, audioName, durationMs, parsed.chapters, segStarts, emptyList(), info, emptyMap(),
            kind = Episode.KIND_SCRIPT
        )
        EpisodeStore.pruneKind(ctx, Episode.KIND_SCRIPT, 40)
        AppLog.log(ctx, "대본 읽어 주기 완료: $title, ${durationMs / 60000}분 ${durationMs / 1000 % 60}초")
        return Result(ep, warnings)
    }

    private fun synth(
        f: (List<Utterance>, PcmWriter, MutableMap<Int, Long>, (String) -> Unit) -> Unit,
        utts: List<Utterance>,
        pcmFile: File,
        starts: MutableMap<Int, Long>
    ): Long {
        PcmWriter(pcmFile).use { w ->
            f(utts, w, starts, progress)
            return w.positionMs
        }
    }
}

/** Claude 등에 붙여 넣을 요청문 */
object ScriptPrompt {
    fun build(topic: String, minutes: Int, host1: String, host2: String): String {
        val m = minutes.coerceIn(5, 90)
        val chars = m * ScriptWriter.CHARS_PER_MIN
        val t = topic.trim().ifEmpty { "(여기에 주제를 적어 주세요)" }
        val h1 = host1.trim().ifEmpty { "지수" }
        val h2 = host2.trim().ifEmpty { "민호" }
        val parts = when {
            m <= 15 -> 2
            m <= 30 -> 3
            else -> 4
        }
        return """
주제: $t

위 주제로, 운전하면서 귀로만 듣는 ${m}분 분량의 한국어 지식 팟캐스트 대본을 써 줘.

[진행]
- 진행자 두 명: $h1(호기심 많은 진행자. 청취자 입장에서 질문하고 중간중간 정리), $h2(이 분야를 잘 아는 전문가)
- 모든 대사는 줄 맨 앞에 "$h1:" 또는 "$h2:"를 붙여 줘.
- 흐름이 크게 바뀌는 곳에는 "## 1부. 소제목"처럼 소제목 줄을 넣어 줘 (전체 ${parts}부 정도).

[내용]
- 왜 흥미로운지(도입) → 핵심 개념 → 구체적인 사례와 이야기 → 흔한 오해 → 최근 동향이나 논쟁 → 오늘 내용 세 줄 정리
- 사실에 근거해서 쓰고, 확실하지 않은 내용은 그렇다고 말해 줘.
- 한 사람이 너무 길게 말하지 않게, 자연스럽게 주고받는 대화로.

[귀로 듣기 좋게]
- 표, 목록 기호, 링크, 이모지, (웃음) 같은 괄호 지시문은 쓰지 마.
- 영어 약어나 전문 용어는 처음 나올 때 쉬운 우리말로 풀어 줘.
- 그림이나 화면을 봐야 이해되는 설명은 말로 풀어서.

[분량]
- 전체 약 ${"%,d".format(chars)}자.
- 한 번에 다 쓰기 어려우면 1부부터 나눠서 쓰고, 내가 "계속"이라고 하면 이어서 써 줘.
- 대본 앞뒤에 설명이나 인사말은 붙이지 말고 대본만 써 줘.
""".trim()
    }
}
