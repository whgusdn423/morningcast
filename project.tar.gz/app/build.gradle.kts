plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// GitHub Actions에서 빌드할 때마다 버전 번호가 1씩 올라가도록 실행 번호를 사용합니다.
val buildNumber: Int = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toIntOrNull() ?: 1

android {
    namespace = "com.morningcast.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.morningcast.app"
        minSdk = 26
        targetSdk = 35
        versionCode = buildNumber
        versionName = "1.0.$buildNumber"
    }

    signingConfigs {
        create("release") {
            // 개인용 서명 키(같은 키로 서명해야 덮어쓰기 업데이트가 됩니다)
            storeFile = file("morningcast.jks")
            storeType = "pkcs12"
            storePassword = "morningcast"
            keyAlias = "morningcast"
            keyPassword = "morningcast"
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
        getByName("debug") {
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    // 외부 라이브러리를 쓰지 않습니다. (안드로이드 기본 기능 + Kotlin 표준 라이브러리만 사용)
}
